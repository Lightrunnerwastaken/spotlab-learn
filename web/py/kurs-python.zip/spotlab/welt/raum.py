"""Ein Zimmer als Geometrie: Waende, Bloecke, Boeden, Tags.

Reine Standardbibliothek. Das ist kein Zufall, sondern der Grund, warum die GUI
dieses Modul importieren darf: es zieht weder Qt noch bosdyn noch numpy herein,
und die Regel "kein spotlab.backends unterhalb von gui/" bleibt unberuehrt.

Einheiten wie in der Schueler-API: Meter und GRAD, links positiv. Wer
`spot.move(turn=90)` kennt, liest eine Raumdatei ohne Umrechnung.

Fassung 2 (06.09.2026): Waende sind Linien mit Dicke und Hoehe je Raum, Bloecke
sind drehbare Kaesten mit Hoehe, Tags haben eine Haengehoehe. Die alte
Schreibweise `hindernisse = [{rechteck=...}]` wird weiter gelesen; gespeichert
wird immer die neue.

Fassung 3 (06.09.2026): Hoehe. Waende, Bloecke und Tags haben ein `z` (ihre
Unterkante ueber dem Grundboden), und es gibt `Boden`: ein begehbares Rechteck
als Podest, Rampe oder Treppe. Der Start bleibt (x, y, grad) -- seine Hoehe
folgt aus dem Boden darunter (`welt/hoehe.py::boden_bei`). Ein Raum ohne Hoehe
sieht gespeichert genau so aus wie in Fassung 2.

Fassung 4 (07.09.2026): Gelaende. Ein Raum kann ein Hoehenraster als Grund
tragen (`welt/gelaende.py`); die Raumdatei verweist unter `[gelaende]` auf die
Binaerdatei daneben. Ohne Gelaende bleibt die Datei Fassung 3.
"""

import math
import tomllib
from dataclasses import dataclass
from pathlib import Path

from spotlab.errors import SpotlabError

VORLAGEN = Path(__file__).parent / "vorlagen"
EIGENE_ORDNER = "raeume"

# Vorgaben der Geometrie in 3D. Die Vorlagen kennen keine Hoehen -- das sind
# ANNAHMEN: eine Uebungswand von 1 m reicht der Puppe, Bloecke tischhoch, Tags
# auf Kniehoehe (so steht es auch in backends/base.py::richtung).
WAND_DICKE_M = 0.06
WAND_HOEHE_M = 1.0
BLOCK_HOEHE_M = 0.75
TAG_HOEHE_M = 0.30
RAND_M = 0.5           # Rand der Huelle, wenn `groesse` fehlt

# DIE Regel fuer Hoehe: ein Hindernis ist ein Hoehensprung ueber MAX_STUFE_M.
# Kollision (Koerperband, Klippen), das 2D-Gitter und das Tiefengitter der Puppe
# (spotsim/local_grid.py, dieselbe Zahl, geprueft in tests/test_naht_spotsim.py)
# formulieren nur sie. Eine Normstufe von 17 cm liegt darunter, eine Tischkante
# von 75 cm darueber. STUFE_VORGABE_M ist die Steigung, mit der die
# Rekonstruktion Stufen zaehlt -- eine Annahme, sie steht im Bericht.
MAX_STUFE_M = 0.25
STUFE_VORGABE_M = 0.17


def _ecken(x, y, breite, tiefe, drehung):
    """Die vier Ecken eines gedrehten Rechtecks, gegen den Uhrzeigersinn ab links-unten."""
    c = math.cos(math.radians(drehung))
    s = math.sin(math.radians(drehung))
    hb, ht = breite / 2, tiefe / 2
    return tuple(
        (x + lx * c - ly * s, y + lx * s + ly * c)
        for lx, ly in ((-hb, -ht), (hb, -ht), (hb, ht), (-hb, ht))
    )


def _lokal(x, y, drehung, px, py):
    """Ein Weltpunkt im Rahmen eines gedrehten Rechtecks (Mitte = Ursprung)."""
    c = math.cos(math.radians(-drehung))
    s = math.sin(math.radians(-drehung))
    dx, dy = px - x, py - y
    return dx * c - dy * s, dx * s + dy * c


@dataclass(frozen=True)
class Wand:
    """Eine Linie; Dicke und Hoehe gelten je Raum. `z` ist die Unterkante."""

    x1: float
    y1: float
    x2: float
    y2: float
    z: float = 0.0

    def __iter__(self):
        # Vier Werte, wie alle Aufrufer entpacken; die Hoehe fragt man einzeln.
        return iter((self.x1, self.y1, self.x2, self.y2))

    @property
    def laenge(self):
        return math.hypot(self.x2 - self.x1, self.y2 - self.y1)

    @property
    def mitte(self):
        return ((self.x1 + self.x2) / 2, (self.y1 + self.y2) / 2)

    @property
    def winkel(self):
        """Richtung von (x1, y1) nach (x2, y2) in Grad."""
        return math.degrees(math.atan2(self.y2 - self.y1, self.x2 - self.x1))


@dataclass(frozen=True)
class Block:
    """Ein Kasten: Mitte, Groesse, Drehung um die Hochachse, Unterkante `z`."""

    name: str
    x: float
    y: float
    breite: float        # entlang der eigenen x-Achse
    tiefe: float
    hoehe: float = BLOCK_HOEHE_M
    drehung: float = 0.0  # Grad, links positiv
    z: float = 0.0

    def ecken(self):
        """Die vier Ecken im Weltframe, gegen den Uhrzeigersinn ab links-unten."""
        return _ecken(self.x, self.y, self.breite, self.tiefe, self.drehung)

    def lokal(self, px, py):
        """Ein Weltpunkt im Rahmen des Blocks (Mitte = Ursprung, x entlang der Breite)."""
        return _lokal(self.x, self.y, self.drehung, px, py)


@dataclass(frozen=True)
class Sperrzone:
    """Ein verbotenes Rechteck auf dem Boden -- eine REGEL, keine Geometrie.

    Gedreht wie ein Block, aber ohne Hoehe: die Gefahren, um die es geht, sind
    Flaechen (Glasfront, Treppenabgang, teures Geraet). Hinter einer Glasfront
    ist der Boden auf jeder Hoehe verboten.

    Eine Zone steht in keinem Hindernisgitter, wirft keinen Schatten und
    veraendert das Gelaende nicht. Das ist ihr ganzer Zweck: sie haelt dort, wo
    der SENSOR frei sagt -- Glas loest keine Tiefenkamera und kein Gitter.
    `grund` ist der Text, den ein Mensch spaeter im Protokoll liest.
    """

    name: str
    x: float
    y: float
    breite: float        # entlang der eigenen x-Achse
    tiefe: float
    drehung: float = 0.0  # Grad, links positiv
    grund: str = ""

    def ecken(self):
        return _ecken(self.x, self.y, self.breite, self.tiefe, self.drehung)

    def lokal(self, px, py):
        return _lokal(self.x, self.y, self.drehung, px, py)


@dataclass(frozen=True)
class Kartenbezug:
    """Wie der Raum zur GraphNav-Karte steht, aus der er rekonstruiert wurde.

    `rekonstruiere` dreht den Raum (haeufigste Wandrichtung auf die x-Achse),
    schiebt die Huelle nach (0, 0) und zieht den tiefsten Boden auf z = 0. Ohne
    diese drei Zahlen weiss ein Lauf am echten Roboter nicht, WO IM RAUM er
    steht -- und eine Sperrzone waere dort wertlos.

        raum_x, raum_y = drehe(seed_x, seed_y, dreh) + versatz
        raum_z         = seed_z - z_min
    """

    name: str
    dreh: float = 0.0
    versatz_x: float = 0.0
    versatz_y: float = 0.0
    z_min: float = 0.0


@dataclass(frozen=True)
class Boden:
    """Ein begehbares Rechteck: Podest, Rampe oder Treppe.

    Um die Hochachse gedreht wie ein Block. Entlang der EIGENEN x-Achse steigt
    er von `z` (Kante bei -breite/2) auf `z + anstieg` (Kante bei +breite/2).
    Ohne Anstieg ein Podest, mit Anstieg eine Rampe, mit Anstieg und Stufen
    eine Treppe -- ein Element, drei Erscheinungen, damit Kollision, Gitter,
    Editor und Puppe eine Formulierung teilen.
    """

    name: str
    x: float
    y: float
    breite: float        # entlang der Anstiegsrichtung
    tiefe: float
    z: float = 0.0
    anstieg: float = 0.0
    stufen: int = 0
    drehung: float = 0.0

    def ecken(self):
        return _ecken(self.x, self.y, self.breite, self.tiefe, self.drehung)

    def lokal(self, px, py):
        return _lokal(self.x, self.y, self.drehung, px, py)

    def hoehe_lokal(self, lx):
        """Bodenhoehe an lokaler x-Position -- glatt, auch bei Stufen (der Koerper gleitet)."""
        if self.breite <= 0:
            return self.z
        anteil = min(1.0, max(0.0, lx / self.breite + 0.5))
        return self.z + self.anstieg * anteil

    def stufe_lokal(self, lx):
        """Bodenhoehe als Trittflaeche: die Stufe, auf der lx liegt (ohne Stufen: die Flaeche)."""
        if self.stufen <= 0 or self.breite <= 0:
            return self.hoehe_lokal(lx)
        anteil = min(1.0, max(0.0, lx / self.breite + 0.5))
        nummer = min(self.stufen - 1, int(anteil * self.stufen))
        return self.z + self.anstieg * (nummer + 1) / self.stufen

    @property
    def art(self):
        if self.anstieg == 0.0:
            return "podest"
        return "treppe" if self.stufen > 0 else "rampe"

    @property
    def neigung_grad(self):
        """Neigung der (glatten) Flaeche in Grad; 0 fuer ein Podest."""
        if self.anstieg == 0.0 or self.breite <= 0:
            return 0.0
        return math.degrees(math.atan2(self.anstieg, self.breite))

    @property
    def z_oben(self):
        return self.z + self.anstieg


@dataclass(frozen=True)
class RaumTag:
    id: int
    x: float
    y: float
    grad: float          # Blickrichtung des Tags
    hoehe: float = TAG_HOEHE_M   # Haengehoehe ueber dem Boden, auf dem er steht
    z: float = 0.0               # der Tag haengt bei z + hoehe


@dataclass(frozen=True)
class Raum:
    name: str
    beschreibung: str
    start: tuple         # (x, y, grad)
    waende: tuple = ()   # Wand, ...
    bloecke: tuple = ()  # Block, ...
    tags: tuple = ()     # RaumTag, ...
    groesse: tuple | None = None   # (breite, hoehe) oder None -> Huelle
    wand_dicke: float = WAND_DICKE_M
    wand_hoehe: float = WAND_HOEHE_M
    boeden: tuple = ()   # Boden, ...
    gelaende: object = None   # welt/gelaende.py::Gelaende oder None
    sperrzonen: tuple = ()    # Sperrzone, ... (Fassung 5)
    karte: object = None      # Kartenbezug oder None (Fassung 5)

    def __post_init__(self):
        # Tupel aus Tests und alten Aufrufern werden Waende; Listen werden Tupel.
        object.__setattr__(self, "waende", tuple(
            w if isinstance(w, Wand) else Wand(*(float(v) for v in w)) for w in self.waende
        ))
        object.__setattr__(self, "bloecke", tuple(self.bloecke))
        object.__setattr__(self, "tags", tuple(self.tags))
        object.__setattr__(self, "boeden", tuple(self.boeden))
        object.__setattr__(self, "sperrzonen", tuple(self.sperrzonen))
        object.__setattr__(self, "start", tuple(float(v) for v in self.start))
        if self.groesse is not None:
            object.__setattr__(self, "groesse", tuple(float(v) for v in self.groesse))


def aus_karte(raum, x, y, grad=None):
    """Einen Punkt (und optional eine Blickrichtung) aus dem Seed-Rahmen der
    GraphNav-Karte in den Raumrahmen holen.

    Ohne `raum.karte` gibt es keine Beziehung, und Raten waere gefaehrlich: eine
    Sperrzone an der falschen Stelle ist schlimmer als keine. Dann `None`.
    """
    k = raum.karte
    if k is None:
        return None
    bogen = math.radians(k.dreh)
    c, s = math.cos(bogen), math.sin(bogen)
    rx, ry = x * c - y * s, x * s + y * c
    punkt = (rx + k.versatz_x, ry + k.versatz_y)
    return punkt if grad is None else (punkt[0], punkt[1], (grad + k.dreh) % 360.0)


def nach_karte(raum, x, y, grad=None):
    """Die Gegenrichtung: aus dem Raumrahmen zurueck in den Seed-Rahmen."""
    k = raum.karte
    if k is None:
        return None
    bogen = math.radians(-k.dreh)
    c, s = math.cos(bogen), math.sin(bogen)
    dx, dy = x - k.versatz_x, y - k.versatz_y
    punkt = (dx * c - dy * s, dx * s + dy * c)
    return punkt if grad is None else (punkt[0], punkt[1], (grad - k.dreh) % 360.0)


def huelle(raum):
    """(x_min, y_min, x_max, y_max): die Zeichenflaeche.

    Mit `groesse` das Rechteck ab dem Ursprung wie bisher; ohne die Bounding-Box
    aller Elemente plus RAND_M -- eine rekonstruierte Karte hat keine Groesse.
    """
    if raum.groesse is not None:
        return (0.0, 0.0, raum.groesse[0], raum.groesse[1])
    punkte = [(raum.start[0], raum.start[1])]
    for wand in raum.waende:
        punkte += [(wand.x1, wand.y1), (wand.x2, wand.y2)]
    for block in raum.bloecke:
        punkte += list(block.ecken())
    for boden in raum.boeden:
        punkte += list(boden.ecken())
    for zone in raum.sperrzonen:
        punkte += list(zone.ecken())
    punkte += [(t.x, t.y) for t in raum.tags]
    if raum.gelaende is not None:
        from spotlab.welt import gelaende as _gelaende

        u = _gelaende.umriss(raum.gelaende)
        if u is not None:
            punkte += [(u[0], u[1]), (u[2], u[3])]
    xs = [p[0] for p in punkte]
    ys = [p[1] for p in punkte]
    return (min(xs) - RAND_M, min(ys) - RAND_M, max(xs) + RAND_M, max(ys) + RAND_M)


def vorlagen():
    """Die mitgelieferten Raeume, ohne Endung."""
    return sorted(p.stem for p in VORLAGEN.glob("*.toml"))


def eigene_raeume(workspace):
    """Die Raeume unter <arbeitsordner>/raeume, ohne Endung."""
    if not workspace:
        return []
    ordner = Path(workspace) / EIGENE_ORDNER
    if not ordner.is_dir():
        return []
    return sorted(p.stem for p in ordner.glob("*.toml"))


def raum_pfad(workspace, name):
    """Wo ein eigener Raum dieses Namens liegt (oder liegen wird)."""
    return Path(workspace) / EIGENE_ORDNER / f"{name}.toml"


def _pfad(name, workspace):
    if workspace:
        eigen = raum_pfad(workspace, name)
        if eigen.is_file():
            return eigen
    mitgeliefert = VORLAGEN / f"{name}.toml"
    if mitgeliefert.is_file():
        return mitgeliefert
    vorhanden = ", ".join(vorlagen())
    raise SpotlabError(
        f"Den Raum '{name}' gibt es nicht. Vorhanden: {vorhanden}. "
        f"Eigene Raeume liegen unter <arbeitsordner>/raeume/<name>.toml."
    )


def _feld(daten, name, pfad, wo="unter [raum]"):
    if name not in daten:
        raise SpotlabError(f"In {pfad.name} fehlt das Feld '{name}' {wo}.")
    return daten[name]


def _waende(daten, pfad):
    waende = []
    for wand in daten.get("waende", []):
        werte = [float(w) for w in wand]
        if len(werte) not in (4, 5):
            raise SpotlabError(
                f"In {pfad.name} hat eine Wand {len(werte)} Werte -- erwartet sind "
                f"[x1, y1, x2, y2] oder [x1, y1, x2, y2, z]."
            )
        waende.append(Wand(*werte))
    return tuple(waende)


def _bloecke(daten, roh, pfad):
    bloecke = []
    # Alte Schreibweise: achsparallele Rechtecke, tischhoch.
    for h in daten.get("hindernisse", []):
        x, y, breite, hoehe = (float(v) for v in h["rechteck"])
        bloecke.append(Block(
            name=str(h.get("name", "Hindernis")),
            # Auf 4 Stellen gerundet, wie `raum_speichern` schreibt -- sonst ist ein
            # geladener und wieder gespeicherter Raum nicht mehr derselbe.
            x=round(x + breite / 2, 4), y=round(y + hoehe / 2, 4), breite=breite, tiefe=hoehe,
            hoehe=BLOCK_HOEHE_M, drehung=0.0,
        ))
    for b in roh.get("block", []):
        mitte = _feld(b, "mitte", pfad, "bei einem [[block]]")
        groesse = _feld(b, "groesse", pfad, "bei einem [[block]]")
        bloecke.append(Block(
            name=str(b.get("name", "Block")),
            x=float(mitte[0]), y=float(mitte[1]),
            breite=float(groesse[0]), tiefe=float(groesse[1]),
            hoehe=float(groesse[2]) if len(groesse) > 2 else BLOCK_HOEHE_M,
            drehung=float(b.get("drehung", 0.0)),
            z=float(b.get("z", 0.0)),
        ))
    return tuple(bloecke)


def _boeden(roh, pfad):
    boeden = []
    for b in roh.get("boden", []):
        mitte = _feld(b, "mitte", pfad, "bei einem [[boden]]")
        groesse = _feld(b, "groesse", pfad, "bei einem [[boden]]")
        boeden.append(Boden(
            name=str(b.get("name", "Boden")),
            x=float(mitte[0]), y=float(mitte[1]),
            breite=float(groesse[0]), tiefe=float(groesse[1]),
            z=float(b.get("z", 0.0)), anstieg=float(b.get("anstieg", 0.0)),
            stufen=int(b.get("stufen", 0)), drehung=float(b.get("drehung", 0.0)),
        ))
    return tuple(boeden)


def _sperrzonen(roh, pfad):
    zonen = []
    for z in roh.get("sperrzone", []):
        mitte = _feld(z, "mitte", pfad, "bei einer [[sperrzone]]")
        groesse = _feld(z, "groesse", pfad, "bei einer [[sperrzone]]")
        zonen.append(Sperrzone(
            name=str(z.get("name", "Sperrzone")),
            x=float(mitte[0]), y=float(mitte[1]),
            breite=float(groesse[0]), tiefe=float(groesse[1]),
            drehung=float(z.get("drehung", 0.0)), grund=str(z.get("grund", "")),
        ))
    return tuple(zonen)


def _kartenbezug(roh):
    k = roh.get("karte")
    if not k:
        return None
    versatz = k.get("versatz", (0.0, 0.0))
    return Kartenbezug(
        name=str(k.get("name", "")), dreh=float(k.get("dreh", 0.0)),
        versatz_x=float(versatz[0]), versatz_y=float(versatz[1]),
        z_min=float(k.get("z_min", 0.0)),
    )


def raum_laden_pfad(pfad):
    """Einen Raum aus einer Datei laden -- Fassung 1 bis 5."""
    pfad = Path(pfad)
    try:
        roh = tomllib.loads(pfad.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as fehler:
        raise SpotlabError(f"{pfad.name} ist kein gueltiges TOML: {fehler}") from fehler

    daten = roh.get("raum")
    if not isinstance(daten, dict):
        raise SpotlabError(f"In {pfad.name} fehlt der Abschnitt [raum].")

    tags = tuple(
        RaumTag(id=int(t["id"]), x=float(t["pose"][0]), y=float(t["pose"][1]),
                grad=float(t["pose"][2]), hoehe=float(t.get("hoehe", TAG_HOEHE_M)),
                z=float(t.get("z", 0.0)))
        for t in roh.get("tag", [])
    )
    groesse = daten.get("groesse")
    gelaende = None
    verweis = roh.get("gelaende")
    if isinstance(verweis, dict) and verweis.get("datei"):
        from spotlab.welt import gelaende as _gelaende

        gelaende = _gelaende.lies(pfad.parent / str(verweis["datei"]))
        if gelaende is None:
            raise SpotlabError(
                f"Die Gelände-Datei {verweis['datei']} zu {pfad.name} fehlt — den Raum neu "
                f"korrigieren oder den Abschnitt [gelaende] entfernen."
            )
    return Raum(
        name=str(_feld(daten, "name", pfad)),
        beschreibung=str(daten.get("beschreibung", "")),
        start=tuple(float(w) for w in _feld(daten, "start", pfad)),
        waende=_waende(daten, pfad),
        bloecke=_bloecke(daten, roh, pfad),
        tags=tags,
        groesse=tuple(float(w) for w in groesse) if groesse is not None else None,
        wand_dicke=float(daten.get("wand_dicke", WAND_DICKE_M)),
        wand_hoehe=float(daten.get("wand_hoehe", WAND_HOEHE_M)),
        boeden=_boeden(roh, pfad),
        sperrzonen=_sperrzonen(roh, pfad),
        karte=_kartenbezug(roh),
        gelaende=gelaende,
    )


def raum_laden(name, workspace=None):
    """Einen Raum laden. Der Arbeitsordner geht vor den Vorlagen."""
    return raum_laden_pfad(_pfad(name, workspace))


# ------------------------------------------------------------------ Speichern
#
# tomllib liest nur. Der Schreiber deckt genau das ab, was ein Raum braucht:
# Zeichenketten, Zahlen, Zahlenlisten, Tabellen-Arrays.


def _zahl(wert):
    text = f"{float(wert):.4f}".rstrip("0").rstrip(".")
    if text in ("", "-", "-0"):
        text = "0"
    return text if "." in text else text + ".0"


# Was in einer TOML-Zeichenkette nicht roh stehen darf. Ein eingefuegter Grund
# mit Zeilenumbruch machte die Raumdatei unladbar (23.09.2026) -- und
# ein Raum, der sich nicht mehr oeffnen laesst, ist verloren.
_MASKEN = {"\\": "\\\\", '"': '\\"', "\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f",
           "\r": "\\r"}


def _text(wert):
    aus = []
    for zeichen in str(wert):
        if zeichen in _MASKEN:
            aus.append(_MASKEN[zeichen])
        elif ord(zeichen) < 0x20 or ord(zeichen) == 0x7F:
            aus.append(f"\\u{ord(zeichen):04X}")
        else:
            aus.append(zeichen)
    return '"' + "".join(aus) + '"'


def _liste(werte):
    return "[" + ", ".join(_zahl(w) for w in werte) + "]"


def raum_speichern(raum, pfad):
    """Den Raum als TOML schreiben -- immer in der neuen Schreibweise.

    Hoehen stehen nur, wo sie nicht 0 sind, und `[[boden]]` nur, wenn es Boeden
    gibt: ein Raum ohne Hoehe bleibt Zeile fuer Zeile die Datei aus Fassung 2.
    `fassung` sagt, welcher Leser die Datei verstehen muss. Ein Gelaende steht
    als Verweis `[gelaende]` in der Datei und als Binaerdatei daneben
    (Fassung 4); ohne Gelaende wird eine liegengebliebene Binaerdatei geloescht.
    """
    from spotlab.welt import gelaende as _gelaende

    pfad = Path(pfad)
    mit_hoehe = bool(raum.boeden) or any(
        e.z != 0.0 for e in (*raum.waende, *raum.bloecke, *raum.tags)
    )
    mit_gelaende = raum.gelaende is not None
    mit_zonen = bool(raum.sperrzonen) or raum.karte is not None
    zeilen = [
        "[raum]",
        f"name         = {_text(raum.name)}",
    ]
    if mit_zonen:
        zeilen.append("fassung      = 5")
    elif mit_gelaende:
        zeilen.append("fassung      = 4")
    elif mit_hoehe:
        zeilen.append("fassung      = 3")
    zeilen += [
        f"beschreibung = {_text(raum.beschreibung)}",
        f"start        = {_liste(raum.start)}",
    ]
    if raum.groesse is not None:
        zeilen.append(f"groesse      = {_liste(raum.groesse)}")
    zeilen.append(f"wand_dicke   = {_zahl(raum.wand_dicke)}")
    zeilen.append(f"wand_hoehe   = {_zahl(raum.wand_hoehe)}")
    zeilen.append("waende = [")
    for wand in raum.waende:
        werte = (wand.x1, wand.y1, wand.x2, wand.y2) + ((wand.z,) if wand.z != 0.0 else ())
        zeilen.append(f"    {_liste(werte)},")
    zeilen.append("]")
    for block in raum.bloecke:
        zeilen += [
            "",
            "[[block]]",
            f"name    = {_text(block.name)}",
            f"mitte   = {_liste((block.x, block.y))}",
            f"groesse = {_liste((block.breite, block.tiefe, block.hoehe))}",
            f"drehung = {_zahl(block.drehung)}",
        ]
        if block.z != 0.0:
            zeilen.append(f"z       = {_zahl(block.z)}")
    for zone in raum.sperrzonen:
        zeilen += [
            "",
            "[[sperrzone]]",
            f"name    = {_text(zone.name)}",
            f"mitte   = {_liste((zone.x, zone.y))}",
            f"groesse = {_liste((zone.breite, zone.tiefe))}",
            f"drehung = {_zahl(zone.drehung)}",
            f"grund   = {_text(zone.grund)}",
        ]
    if raum.karte is not None:
        k = raum.karte
        zeilen += [
            "",
            "[karte]",
            f"name    = {_text(k.name)}",
            f"dreh    = {_zahl(k.dreh)}",
            f"versatz = {_liste((k.versatz_x, k.versatz_y))}",
            f"z_min   = {_zahl(k.z_min)}",
        ]
    for boden in raum.boeden:
        zeilen += [
            "",
            "[[boden]]",
            f"name    = {_text(boden.name)}",
            f"mitte   = {_liste((boden.x, boden.y))}",
            f"groesse = {_liste((boden.breite, boden.tiefe))}",
            f"z       = {_zahl(boden.z)}",
            f"anstieg = {_zahl(boden.anstieg)}",
            f"stufen  = {int(boden.stufen)}",
            f"drehung = {_zahl(boden.drehung)}",
        ]
    for tag in raum.tags:
        zeilen += [
            "",
            "[[tag]]",
            f"id    = {int(tag.id)}",
            f"pose  = {_liste((tag.x, tag.y, tag.grad))}",
            f"hoehe = {_zahl(tag.hoehe)}",
        ]
        if tag.z != 0.0:
            zeilen.append(f"z     = {_zahl(tag.z)}")
    if mit_gelaende:
        zeilen += ["", "[gelaende]", f"datei = {_text(_gelaende.pfad_zu(pfad).name)}"]
    pfad.parent.mkdir(parents=True, exist_ok=True)
    pfad.write_text("\n".join(zeilen) + "\n", encoding="utf-8", newline="\n")
    daneben = _gelaende.pfad_zu(pfad)
    if mit_gelaende:
        _gelaende.schreibe(daneben, raum.gelaende)
    elif daneben.exists():
        daneben.unlink()
