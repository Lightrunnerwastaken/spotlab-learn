"""Der Geschwindigkeitsdeckel als Protobuf — an genau einer Stelle.

Warum hier und nicht in `api/`: `RobotCommandBuilder.mobility_params()` kennt
gar keinen Parameter `vel_limit` (geprüft an bosdyn-client 5.0.1.2 — die
Signatur führt nur body_height, footprint_R_body, locomotion_hint, stair_hint,
external_force_params, stairs_mode). Das Feld muss direkt am Protobuf gesetzt
werden, und rohe Protobuf-Nachrichten gehören nach Projektregel nicht nach
`api/`. Also bauen die Backends sie, und `api/` reicht das Ergebnis nur durch —
dieselbe Naht wie bei `frame_tree_snapshot()`.

Warum an EINER Stelle: Autonome Fahrt (GraphNav `travel_params`) und
Zieltrajektorie (`move`) brauchen denselben Deckel. Zwei Formulierungen
desselben Grenzwerts wären zwei Gelegenheiten, ihn unterschiedlich falsch zu
schreiben — und die eine, die stimmt, verdeckte die andere.
"""

import math

from bosdyn.api import geometry_pb2, trajectory_pb2
from bosdyn.api.spot import robot_command_pb2 as spot_command_pb2
from bosdyn.geometry import EulerZXY


def se2_grenze(limits):
    """SE2VelocityLimit aus den Konfigurationsgrenzen.

    `min_vel` muss mitgesetzt werden, sonst bremst nur die Vorwärtsfahrt und der
    Roboter fährt rückwärts oder seitwärts ungedeckelt.
    """
    return geometry_pb2.SE2VelocityLimit(
        max_vel=geometry_pb2.SE2Velocity(
            linear=geometry_pb2.Vec2(x=limits.max_speed, y=limits.max_speed),
            angular=limits.max_turn_rate,
        ),
        min_vel=geometry_pb2.SE2Velocity(
            linear=geometry_pb2.Vec2(x=-limits.max_speed, y=-limits.max_speed),
            angular=-limits.max_turn_rate,
        ),
    )


TREPPENMODUS = {
    "auto": spot_command_pb2.MobilityParams.STAIRS_MODE_AUTO,
    "aus": spot_command_pb2.MobilityParams.STAIRS_MODE_OFF,
}


def koerperneigung(nick_grad):
    """`BodyControlParams`, die den Körper um `nick_grad` neigen — beim GEHEN.

    Das Feld ist `base_offset_rt_footprint`: die Lage des Körpers über dem
    Fussabdruck, und die wirkt während der Fahrt. Das naheliegende `body_pose`
    wäre falsch — laut Protokoll wirkt es NUR zusammen mit einem Stehkommando,
    und genau deshalb kann `spot.pose()` nur im Stand neigen.

    Vorzeichen wie überall im Projekt: Drehung um y nach der Rechte-Hand-Regel,
    **Nase hoch ist NEGATIV**. So liest `api/state.py::rpy_aus` den echten Spot,
    so rechnet MuJoCo, so liefert `welt/hoehe.py::nick_grad`.

    `rotation_setting` bleibt ungesetzt, also die Vorgabe: der Winkel gilt
    ZUSÄTZLICH zur Geländeneigung. Die Alternative (schwerkraftfest) verschlechtert
    laut Protokollkommentar die Leistung in schwierigem Gelände.
    """
    lage = geometry_pb2.SE3Pose(
        position=geometry_pb2.Vec3(),
        rotation=EulerZXY(pitch=math.radians(float(nick_grad))).to_quaternion(),
    )
    punkt = trajectory_pb2.SE3TrajectoryPoint(pose=lage)
    return spot_command_pb2.BodyControlParams(
        base_offset_rt_footprint=trajectory_pb2.SE3Trajectory(points=[punkt])
    )


def mit_grenze(limits, nick_grad=0.0):
    """MobilityParams, die NICHTS anderes tun als Deckel und Treppenmodus zu setzen.

    Bewusst ein nacktes Protobuf statt `RobotCommandBuilder.mobility_params()`:
    jenes setzt zusätzlich eine Körperhöhen-Trajektorie und einen
    Fortbewegungs-Hinweis, die hier niemand bestellt hat. Alles Ungesetzte
    entscheidet der Roboter selbst — das ist die Absicht. Kein `stair_hint`:
    das ist eine Angabe für einen konkreten Schritt, die der Roboter selbst
    besser weiss. `treppen` kommt aus `config.toml [limits]`, geprüft beim
    Laden; der Sim liest denselben Wert (Treppen sind bei "aus" Klippen).
    """
    params = spot_command_pb2.MobilityParams(
        vel_limit=se2_grenze(limits),
        stairs_mode=TREPPENMODUS[getattr(limits, "treppen", "auto")],
    )
    if nick_grad:
        params.body_control.CopyFrom(koerperneigung(nick_grad))
    return params
