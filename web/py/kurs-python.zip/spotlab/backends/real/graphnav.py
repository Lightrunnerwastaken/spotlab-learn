"""GraphNav am echten Roboter: hochladen, verorten, fahren.

Freie Funktionen auf einem robot-Objekt statt einer Klasse — dieser
Protokollteil ist optional (nur RealSpot erfüllt ihn) und hat keinen eigenen
Zustand ausser dem, was ohnehin auf dem Roboter liegt.

Hier liegt auch nav_status(): die Abbildung eines Protobuf-Status auf den
neutralen NavStatus ist Backend-Arbeit. In errors/ wäre sie ein Importzyklus.
"""

import shutil
from pathlib import Path

from bosdyn.api.graph_nav import graph_nav_pb2, map_pb2, nav_pb2
from bosdyn.client.graph_nav import GraphNavClient
from google.protobuf.message import DecodeError

from spotlab.backends import mobility
from spotlab.backends.base import NavStatus
from spotlab.errors import MapError, NotLocalized, translate
from spotlab.errors.graphnav import (
    FERTIG,
    LAEUFT,
    NAVIGATION_TEXTE,
    unbekannter_status,
)

FIDUCIAL_NEAREST = graph_nav_pb2.SetLocalizationRequest.FIDUCIAL_INIT_NEAREST


def nav_status(status_wert):
    """NavigationFeedbackResponse.Status → NavStatus mit deutschem Text."""
    text = NAVIGATION_TEXTE.get(status_wert)
    if text is None:
        return NavStatus(
            fertig=False, status=unbekannter_status(status_wert), gescheitert=True
        )
    if status_wert in FERTIG:
        return NavStatus(fertig=True, status=text, gescheitert=False)
    if status_wert in LAEUFT:
        return NavStatus(fertig=False, status=text, gescheitert=False)
    return NavStatus(fertig=False, status=text, gescheitert=True)


def _client(robot):
    return robot.ensure_client(GraphNavClient.default_service_name)


def clear_map(robot):
    _client(robot).clear_graph()


def upload_map(robot, kartenordner):
    """Karte aus dem Ordner auf den Roboter laden. Gibt den Graphen zurück.

    Fehlende Schnappschüsse werden nachgereicht: der Roboter meldet in
    unknown_*_snapshot_ids, was ihm fehlt. Sie vorsorglich alle zu schicken
    wäre teuer — jeder Wegpunkt bringt eine Punktwolke mit.
    """
    ordner = Path(kartenordner)
    graph = map_pb2.Graph()
    try:
        graph.ParseFromString((ordner / "graph").read_bytes())
    except OSError as fehler:
        raise MapError(f"Die Karte in {ordner} lässt sich nicht lesen.") from fehler

    client = _client(robot)
    _versuche(client.clear_graph)
    # Neue Anker nur, wenn die Karte keine hat -- wie `graph_nav_command_line.py` im SDK.
    # Bis zum 27.09.2026 immer: das Hochladen warf die optimierten Anker weg, und der
    # Roboter rechnete neue, waehrend `karte_verbessern.py` schon Schleifen suchte.
    antwort = _versuche(client.upload_graph, graph=graph,
                        generate_new_anchoring=not graph.anchoring.anchors)

    for kennung in antwort.unknown_waypoint_snapshot_ids:
        pfad = ordner / "waypoint_snapshots" / kennung
        if not pfad.exists():
            continue
        schnappschuss = map_pb2.WaypointSnapshot()
        schnappschuss.ParseFromString(pfad.read_bytes())
        client.upload_waypoint_snapshot(schnappschuss)

    for kennung in antwort.unknown_edge_snapshot_ids:
        pfad = ordner / "edge_snapshots" / kennung
        if not pfad.exists():
            continue
        schnappschuss = map_pb2.EdgeSnapshot()
        schnappschuss.ParseFromString(pfad.read_bytes())
        client.upload_edge_snapshot(schnappschuss)

    return graph


def process_map(robot, melde=None, fiducial=True, odometrie=True):
    """Die Karte AUF DEM ROBOTER nachbearbeiten. Gibt einen `Nachbearbeitung`-Bericht.

    Das Protokoll steht in `maps/nachbearbeitung.py` — dieselbe Formulierung,
    die auch die frische Aufnahme nachbearbeitet. Hier kommt nur der Client
    dazu. Der Dienst selbst braucht kein Lease; das Lease hing schon am
    Hochladen davor (`upload_map`).
    """
    from bosdyn.client.map_processing import MapProcessingServiceClient

    from spotlab.maps import nachbearbeitung

    try:
        client = robot.ensure_client(MapProcessingServiceClient.default_service_name)
    except Exception:
        client = None                   # aeltere Software: `nachbearbeiten` sagt es
    return nachbearbeitung.nachbearbeiten(client, melde, fiducial, odometrie)


def download_map(robot, kartenordner):
    """Die Karte vom Roboter in den Ordner holen. Gibt den neuen Graphen zurück.

    Geschrieben wird NEBENAN und erst am Schluss getauscht
    (`maps/store.py::ersetze_inhalt`): der Ordner ist die einzige Kopie der
    Aufnahme, und ein Abbruch mitten im Herunterladen liesse den Schüler ohne
    beides zurück.
    """
    from spotlab.maps.store import MITNEHMEN, aktualisiere_zahlen, ersetze_inhalt

    ordner = Path(kartenordner)
    neben = ordner.with_name(ordner.name + ".neu")
    shutil.rmtree(neben, ignore_errors=True)
    neben.mkdir(parents=True)
    _versuche(_client(robot).write_graph_and_snapshots, str(neben))
    graph = map_pb2.Graph()
    try:
        graph.ParseFromString((neben / "graph").read_bytes())
    except (OSError, DecodeError) as fehler:
        shutil.rmtree(neben, ignore_errors=True)
        raise MapError(
            "Die heruntergeladene Karte ist unlesbar — die gespeicherte bleibt, "
            "wie sie war."
        ) from fehler
    if not graph.waypoints:
        shutil.rmtree(neben, ignore_errors=True)
        raise MapError(
            "Die heruntergeladene Karte hat keine Wegpunkte — die gespeicherte "
            "bleibt, wie sie war."
        )
    # `karte.json` kommt nicht vom Roboter: sie zieht mit um, sonst verloere die Karte
    # Name und Aufnahmedatum (flurneu und flur2 bis zum 27.09.2026). Ebenso die
    # Gefahrenzonen der Karte (Agenten am Spot, Teil 3).
    for datei in MITNEHMEN:
        if (ordner / datei).exists():
            shutil.copy2(ordner / datei, neben / datei)
    ersetze_inhalt(ordner, neben)
    aktualisiere_zahlen(ordner, graph)
    return graph


def _uebersetze(fehler):
    """SDK-Fehler in deutschen Klartext — oder unveraendert weiterreichen.

    Ohne das kamen bei `upload_map`, `localize` und `navigate_step` rohe
    SDK-Ausnahmen bis zum Schueler durch. Und `CannotModifyMapDuringRecording`
    ist der haeufigste davon: wer eine Karte aufnimmt und gleichzeitig eine
    hochladen will, bekam einen englischen Klassennamen statt eines Hinweises.
    """
    from bosdyn.client.graph_nav import CannotModifyMapDuringRecordingError

    if isinstance(fehler, CannotModifyMapDuringRecordingError):
        return MapError(
            "Auf dem Roboter laeuft gerade eine Kartenaufnahme. Beende sie "
            "zuerst in der Kartenansicht, dann laesst sich eine Karte hochladen."
        )
    return translate(fehler)


def _versuche(aufruf, *args, **kw):
    """Einen GraphNav-Aufruf machen und seine Fehler uebersetzen."""
    try:
        return aufruf(*args, **kw)
    except Exception as fehler:
        uebersetzt = _uebersetze(fehler)
        if uebersetzt is not None:
            raise uebersetzt from fehler
        raise


def localize(robot):
    """Über das nächste sichtbare Fiducial verorten. Gibt die Wegpunkt-ID zurück."""
    client = _client(robot)
    _versuche(
        client.set_localization,
        initial_guess_localization=nav_pb2.Localization(),
        fiducial_init=FIDUCIAL_NEAREST,
    )
    kennung = _versuche(client.get_localization_state).localization.waypoint_id
    if not kennung:
        raise NotLocalized(
            "Der Spot konnte sich nicht verorten. Stell ihn so hin, dass ein "
            "Fiducial im Kamerabild ist, und versuche es noch einmal."
        )
    return kennung


def localization_pose(robot):
    """(x, y, grad) des Koerpers im SEED-Rahmen der Karte -- oder None.

    Derselbe Rahmen, in dem `maps/rekonstruktion.py` den Raum baut. Damit
    laesst sich fragen, wo im REKONSTRUIERTEN RAUM der Roboter gerade steht
    (`welt/raum.py::aus_karte`) -- die Voraussetzung fuer Sperrzonen am
    echten Roboter.

    `None`, solange nicht verortet ist: `waypoint_id` ist dann leer, und die
    Pose im Protobuf waere ein Ursprung, also eine erfundene Position. Wer
    Zonen will, muss `localize()` gerufen haben.
    """
    import math

    from bosdyn.client.math_helpers import SE3Pose

    zustand = _versuche(_client(robot).get_localization_state)
    ortung = zustand.localization
    if not ortung.waypoint_id:
        return None
    pose = SE3Pose.from_proto(ortung.seed_tform_body)
    return (float(pose.x), float(pose.y), math.degrees(pose.rot.to_yaw()) % 360.0)


def verortung(robot):
    """`Verortung` aus EINER Antwort des Dienstes — oder None, solange nicht verortet.

    Die Lage im Seed-Rahmen der Karte kommt aus `localization.seed_tform_body`, die im
    Rahmen „vision“ aus `robot_kinematics.transforms_snapshot` DERSELBEN Antwort — zwei
    Abfragen hintereinander gehörten zu zwei Augenblicken, und bei 0.5 m/s läge die Karte
    dann um den Weg dazwischen neben der Skizze. Das Urteil des Roboters, ob er die Umgebung
    in der Karte wiederfindet, steht in `lost_detector_state`.
    """
    from bosdyn.client.frame_helpers import BODY_FRAME_NAME, VISION_FRAME_NAME, get_a_tform_b
    from bosdyn.client.math_helpers import SE3Pose

    from spotlab.backends.base import Verortung

    antwort = _versuche(_client(robot).get_localization_state)
    ortung = antwort.localization
    if not ortung.waypoint_id:
        return None
    seed = SE3Pose.from_proto(ortung.seed_tform_body)
    vision = None
    try:
        v = get_a_tform_b(antwort.robot_kinematics.transforms_snapshot,
                          VISION_FRAME_NAME, BODY_FRAME_NAME)
        if v is not None:
            vision = (float(v.x), float(v.y), float(v.rot.to_yaw()))
    except Exception:
        vision = None               # kein „vision“ im Baum: nur die Einblendung fällt weg
    verloren = antwort.lost_detector_state
    return Verortung(
        wegpunkt=ortung.waypoint_id,
        seed=(float(seed.x), float(seed.y), float(seed.rot.to_yaw())),
        vision=vision,
        verloren=bool(verloren.is_lost),
        angenommen=int(verloren.total_num_accepted_localizations),
        abgelehnt=int(verloren.total_num_rejected_localizations),
    )


def localization(robot):
    """(Wegpunkt-ID, (dx, dy, grad)) -- wo der Körper relativ zu SEINEM Wegpunkt steht.

    Für die Zeichnung im Karten-Tab: die GUI setzt den Versatz an den Wegpunkt
    ihres Grundrisses (`maps/geometry.py::lage_im_grundriss`). Relativ zum
    Wegpunkt, nicht im Seed-Rahmen, denn ein Grundriss ohne Anker ist im Rahmen
    des ersten Wegpunkts gezeichnet. None, solange nicht verortet.
    """
    import math

    from bosdyn.client.math_helpers import SE3Pose

    ortung = _versuche(_client(robot).get_localization_state).localization
    if not ortung.waypoint_id:
        return None
    pose = SE3Pose.from_proto(ortung.waypoint_tform_body)
    return ortung.waypoint_id, (
        float(pose.x), float(pose.y), math.degrees(pose.rot.to_yaw()) % 360.0)


def travel_params(limits, max_distance=0.4, max_yaw=0.15):
    """TravelParams mit unserem Geschwindigkeitsdeckel.

    Ohne velocity_limit führe die autonome Fahrt schneller als die von Hand
    gesteuerte. Die Grenze selbst kommt aus `backends/mobility.py` — denselben
    Wert zweimal zu formulieren wären zwei Gelegenheiten, ihn unterschiedlich
    falsch zu schreiben. Genau das war er: der frühere Kommentar hier behauptete,
    der Deckel gelte „sonst nur für walk() und move()", während `move()` ihn in
    Wahrheit gar nicht anwandte.
    """
    return GraphNavClient.generate_travel_params(
        max_distance, max_yaw, mobility.se2_grenze(limits)
    )


def navigate_step(robot, waypoint_id, dauer_s, params, command_id=None):
    """Ein Navigationskommando absetzen. Gibt die Kommando-ID zurück.

    Navigationskommandos verfallen wie Geschwindigkeitskommandos; der Aufrufer
    ruft das hier in einer Schleife auf.
    """
    return _versuche(
        _client(robot).navigate_to,
        waypoint_id, dauer_s, travel_params=params, command_id=command_id,
    )


def navigation_status(robot, command_id):
    antwort = _versuche(_client(robot).navigation_feedback, command_id=command_id)
    return nav_status(antwort.status)
