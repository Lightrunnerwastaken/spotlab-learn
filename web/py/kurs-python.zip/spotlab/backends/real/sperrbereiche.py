"""Sperrbereiche im Roboter: Gefahrenzonen als No-Go-Regionen des World-Object-Dienstes.

Agenten am Spot, Teil 3. Die Zentrale meidet Gefahrenzonen schon selbst (Schranke und Wegsuche,
`workshop/gefahrenzonen.py`); dies ist die zweite Sicherung — Spot weicht ihnen dann auch von sich
aus aus, und sie wirken auf das Tablet, solange die Zentrale sie auffrischt.

Jede Zone wird ein `WorldObject` mit `nogo_region_properties.box`: ein Körperhindernis im Rahmen
„vision“, die Pose in der MITTE der Zone, `size` volle Breite × Tiefe. Mitte und volle Masse
stehen so im SDK-Beispiel `user_nogo_regions.py` (Hindernis 0 bei y = 0 mit 10 m Breite quer vor
dem Roboter); der Kommentar im Proto sagt es nicht ausdrücklich — am Gerät mit A46 bestätigen.
Die Lebensdauer (`object_lifetime`) ist der Totmann: stirbt die Zentrale, verfallen sie.
"""

import math

from spotlab.errors import SpotlabError

PRAEFIX = "spotlab-zone"


def objekt(zone, lebt_s, praefix=PRAEFIX):
    """Das `WorldObject` einer `welt.raum.Sperrzone` (im Rahmen „vision“)."""
    from bosdyn.api import geometry_pb2, world_object_pb2
    from bosdyn.client.frame_helpers import VISION_FRAME_NAME
    from bosdyn.client.math_helpers import Quat, SE3Pose
    from bosdyn.util import seconds_to_duration

    pose = SE3Pose(zone.x, zone.y, 0.0, Quat.from_yaw(math.radians(zone.drehung)))
    box = geometry_pb2.Box2WithFrame(
        box=geometry_pb2.Box2(size=geometry_pb2.Vec2(x=zone.breite, y=zone.tiefe)),
        frame_name=VISION_FRAME_NAME, frame_name_tform_box=pose.to_proto())
    return world_object_pb2.WorldObject(
        name=f"{praefix}-{zone.name}", object_lifetime=seconds_to_duration(lebt_s),
        nogo_region_properties=world_object_pb2.NoGoRegionProperties(box=box))


def _mutiere(client, anfrage, was):
    from bosdyn.api import world_object_pb2

    antwort = client.mutate_world_objects(anfrage)
    if antwort.status != world_object_pb2.MutateWorldObjectResponse.STATUS_OK:
        name = world_object_pb2.MutateWorldObjectResponse.Status.Name(antwort.status)
        raise SpotlabError(f"Sperrbereich {was} abgewiesen ({name}) — die Gefahrenzonen gelten "
                           f"weiter in spotlab, nur nicht im Roboter selbst.")
    return antwort


def setze(client, zonen, lebt_s):
    """Jede Zone als Sperrbereich anlegen. -> die Kennungen, die der Dienst vergeben hat."""
    from bosdyn.client.world_object import make_add_world_object_req

    return [_mutiere(client, make_add_world_object_req(objekt(z, lebt_s)), "setzen")
            .mutated_object_id for z in zonen]


def loesche(client, ids):
    """Die Sperrbereiche mit diesen Kennungen löschen — jeden einzeln, auch wenn einer scheitert.
    Eine unbekannte Kennung ist kein Fehler: der Bereich ist schon verfallen (Lebensdauer)."""
    from bosdyn.api import world_object_pb2
    from bosdyn.client.world_object import make_delete_world_object_req

    unbekannt = world_object_pb2.MutateWorldObjectResponse.STATUS_INVALID_MUTATION_ID
    fehler = []
    for kennung in ids:
        try:
            antwort = client.mutate_world_objects(
                make_delete_world_object_req(world_object_pb2.WorldObject(id=kennung)))
        except Exception as grund:
            fehler.append(str(grund))
            continue
        if antwort.status not in (world_object_pb2.MutateWorldObjectResponse.STATUS_OK, unbekannt):
            fehler.append(world_object_pb2.MutateWorldObjectResponse.Status.Name(antwort.status))
    if fehler:
        raise SpotlabError(f"Sperrbereich löschen abgewiesen ({', '.join(fehler)}) — er verfällt "
                           f"von selbst nach seiner Lebensdauer.")
