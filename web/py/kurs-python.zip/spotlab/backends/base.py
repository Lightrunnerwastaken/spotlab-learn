"""Was ein Backend können muss — und was es ehrlich zugeben muss, nicht zu können.

Verbindung, Lease und Not-Aus stehen bewusst NICHT im Protokoll: der spätere
Sim-Spot hat sie nicht und müsste sie sonst fälschen. Nach oben dringt
stattdessen die Fähigkeitsmenge.

`frame_tree_snapshot()` und `mobility_params()` liefern rohe Protobufs nach
oben. Das ist kein Bruch der Regel „api/ bleibt protobuf-frei", sondern ihr
Zweck: `api/` reicht diese Objekte nur an den `RobotCommandBuilder` durch und
liest sie nie. Gebaut werden sie dort, wo bosdyn ohnehin zu Hause ist.
"""

import enum
import math
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from spotlab.errors import UnsupportedCapability


class Capability(enum.Flag):
    NONE = 0
    LOCOMOTION = enum.auto()
    POSTURE = enum.auto()
    POWER = enum.auto()
    DEPTH_CAMERAS = enum.auto()
    GRAY_CAMERAS = enum.auto()
    COLOR_CAMERAS = enum.auto()
    LEASE = enum.auto()
    ESTOP = enum.auto()
    GRAPH_NAV = enum.auto()
    WORLD_OBJECTS = enum.auto()
    LOCAL_GRID = enum.auto()
    STAIRS = enum.auto()          # Treppen nennen: Lage, Richtung, Stufen (Stufe 13)
    NOGO_REGIONS = enum.auto()    # Sperrbereiche im Roboter setzen (Agenten am Spot, Teil 3)

    CAMERAS = DEPTH_CAMERAS | GRAY_CAMERAS | COLOR_CAMERAS


@dataclass(frozen=True)
class Feedback:
    """Rückmeldung zu einem laufenden Kommando, backend-unabhängig."""

    done: bool
    status: str  # deutscher Klartext, z. B. "steht", "unterwegs"
    rejected: bool = False


@dataclass(frozen=True)
class NavStatus:
    """Rückmeldung einer laufenden Navigation, backend-unabhängig.

    Dieselbe Naht wie Feedback: api/ bleibt dadurch protobuf-frei.
    """

    fertig: bool
    status: str  # deutscher Klartext
    gescheitert: bool = False


@dataclass(frozen=True)
class Verortung:
    """Wo Spot in einer geladenen Karte steht — und im Rahmen „vision“, aus DERSELBEN Antwort.

    Für die Steuerzentrale (Teil 3): aus beiden Lagen zusammen fällt die Karte deckungsgleich
    auf die Skizze. `seed`/`vision` sind (x, y, Gier in RAD); `vision` ist None, wenn der
    Rahmenbaum der Antwort keinen Rahmen „vision“ hat. `angenommen`/`abgelehnt` zählen die
    Abgleiche des Roboters seit dem Start (sein eigenes Urteil, `lost_detector_state`).
    """

    wegpunkt: str
    seed: tuple
    vision: tuple | None
    verloren: bool
    angenommen: int
    abgelehnt: int


def richtung(x, y):
    """Aus einer Position im Koerper-Frame: (Peilung in Grad, Distanz in Meter).

    Links positiv, wie bei `move(left=…)`. Die Distanz liegt in der Bodenebene:
    ein Tag haengt auf Kniehoehe, seine Hoehe interessiert beim Hinfahren
    niemanden.

    Steht hier und nicht in `api/world.py`, weil die Backends sie fuer die
    Umwandlung brauchen und `backends/` nie aus `api/` importiert.
    """
    return math.degrees(math.atan2(y, x)), math.hypot(x, y)


@dataclass(frozen=True)
class WorldObject:
    """Ein Objekt, das Spots Firmware gerade fuehrt — backend-unabhaengig.

    Dieselbe Naht wie Feedback und NavStatus: der Backend wandelt Protobufs hier
    hinein, damit api/ protobuf-frei bleibt.
    """

    name: str
    kind: str                # "apriltag" | "dock" | "door" | "image_coordinates" | …
    bearing: float           # Grad, links positiv, im Koerper-Frame
    distance: float          # Meter, in der Bodenebene
    world_xy: tuple | None   # Position im vision-Frame
    time: float              # Erfassungszeitpunkt, Zeitbasis wie zustand.jsonl


@dataclass(frozen=True)
class Tag(WorldObject):
    """Ein AprilTag — ein WorldObject mit aufgedruckter Nummer."""

    id: int
    filtered: bool           # geglaettete Pose (True) oder rohe Einzelmessung


@dataclass(frozen=True)
class TrackedEntity(WorldObject):
    """Etwas, das Spots Firmware als bewegtes Objekt VERFOLGT — auch Menschen.

    Der Tracker der Firmware, nicht unserer: er vergibt eine Nummer, hält sie
    über die Zeit, schätzt die Geschwindigkeit und sagt, für wie sicher er das
    Ding und seinen Typ hält. Ob ein Roboter das überhaupt liefert, hängt an
    seiner Software — `world_objects()` gibt dann einfach keine.
    """

    entity_id: int
    entity_type: str         # "person" | "3d_blob" | "forklift" | "spot" | "unknown"
    likelihood: float        # 0..1, wie sicher es dieses Ding überhaupt gibt
    person_likelihood: float  # 0..1, wie sicher es ein Mensch ist
    speed: float             # m/s, Betrag der geschätzten Geschwindigkeit
    observations: int        # wie oft die Firmware es schon gesehen hat


@dataclass(frozen=True)
class Staircase(WorldObject):
    """Eine Treppe -- ein WorldObject mit Richtung, Stufen und Achse.

    `bearing`/`distance` zeigen zur naechsten Kante (Fuss oder Kopf);
    `direction` sagt, wo der Roboter steht: "auf" am Fuss, "ab" am Kopf.
    `axis_bearing` ist die Peilung der Bergauf-Achse, links positiv --
    `spot.move(turn=treppe.axis_bearing)` stellt die Nase bergauf, und so
    (vorwaerts hoch, rueckwaerts runter) nimmt Spot jede Treppe.
    """

    direction: str           # "auf" | "ab"
    steps: int
    rise_m: float            # Gesamtanstieg, positiv
    axis_bearing: float      # Grad, links positiv, im Koerper-Frame


# Bis hierhin reicht der KOERPERSCHATTEN: die Frontkameras sind 30 Grad nach
# unten geneigt und stehen 0.53 m hoch, ihr Bild trifft den Boden erst rund
# 0.9 m vor dem Koerpermittelpunkt. Davor ist das Gitter UNBEKANNT -- und
# unbekannt gilt sonst als nicht frei. `free_distance` laesst Unbekanntes
# innerhalb dieser Strecke deshalb durchgehen; ein BEKANNTES Hindernis zaehlt
# dort sehr wohl (siehe Docstring). Mit einer Grenze von 0.6 m sprang die freie
# Strecke von Zyklus zu Zyklus zwischen 1.8 und 0.0 (gemessen 06.09.2026 im
# 3D-Uebungsraum), je nachdem, ob die erste Probe eine unbekannte Zelle traf.
FREI_AB_M = 0.9
# Bis hierhin misst sie hoechstens: unter der halben Gitterkante (1.92 m), damit
# jede Richtung gleich weit reicht — siehe free_distance.
FREI_BIS_M = 1.8


@dataclass(frozen=True)
class ObstacleGrid:
    """Spots Hindernisgitter: je Zelle der Abstand zum naechsten Hindernis.

    `known` traegt Spots eigene Aussage darueber, welche Zellen ueberhaupt
    beobachtet wurden. Ohne diese Maske laese man unbeobachtete Zellen als
    "frei" — genau der Optimismus, der einen Roboter in eine Wand faehrt.
    """

    cells: object            # np.ndarray, Meter je Zelle
    cell_size: float         # Kantenlaenge einer Zelle, Meter
    origin: tuple            # Weltkoordinate der Zelle [0, 0]
    time: float
    known: object = None     # np.ndarray bool, oder None = alles bekannt

    def _zelle(self, x, y):
        spalte = int(round((x - self.origin[0]) / self.cell_size))
        zeile = int(round((y - self.origin[1]) / self.cell_size))
        hoehe, breite = self.cells.shape
        if not (0 <= zeile < hoehe and 0 <= spalte < breite):
            return None
        return zeile, spalte

    def distance_at(self, x, y):
        """Meter bis zum naechsten Hindernis.

        None, wenn die Stelle ausserhalb des Gitters liegt ODER Spot sie nicht
        beobachtet hat. Eine fehlende Zahl ist ehrlicher als eine erfundene.
        """
        ort = self._zelle(x, y)
        if ort is None:
            return None
        zeile, spalte = ort
        if self.known is not None and not bool(self.known[zeile, spalte]):
            return None
        return float(self.cells[zeile, spalte])

    def is_free(self, x, y, margin=0.3):
        """Ist dort Platz? Unbekannt gilt als NICHT frei — Vorsicht vor Optimismus."""
        abstand = self.distance_at(x, y)
        return abstand is not None and abstand >= margin

    def free_distance(self, x, y, heading, max_distance=FREI_BIS_M, margin=0.3):
        """Wie viele Meter sind ab (x, y) in Richtung `heading` frei?

        `heading` in GRAD, im Rahmen des Gitters. Punkt und Blickrichtung
        muessen aus DEMSELBEN Rahmen kommen wie das Gitter: am echten Spot ist
        das „vision" -- `spot.look()` liefert `position` und `heading` dort.
        NICHT `spot.state.pose`: die ist „odom", und am echten Spot driften die
        beiden auseinander; der Strahl liefe dann neben dem Weg her (im
        Trockenlauf und in den Sims sind beide gleich, dort faellt es nicht auf).
        Abgetastet wird Zelle fuer Zelle ab dem Punkt.
        Naeher als FREI_AB_M zaehlt nur ein BEKANNTES Hindernis: dort liegt der
        Koerperschatten, in dem Spot nie etwas sieht, und ein Strahl, der
        deswegen 0.0 meldete, waere wertlos. Weiter draussen gilt Unbekanntes
        als nicht frei, wie in `is_free`. Nach einer Drehung auf der Stelle
        steht die Wand, die eben noch seitlich war, 0.4 m vor der Nase -- und
        die ist bekannt; sie zu ueberspringen hiesse hineinzulaufen (2D-
        Uebungsraum, 06.09.2026). Steht schon die erste Probe zu, ist nichts
        frei: 0.0. Ist bis `max_distance` alles frei, kommt genau das zurueck.

        Die Vorgabe FREI_BIS_M liegt UNTER der halben Gitterkante (1.92 m):
        das Gitter ist ein Quadrat, geradeaus endet es bei 1.9 m, diagonal
        erst bei 2.7 m. Mit einem hoeheren Deckel gewaenne eine Diagonale
        allein wegen der Gittergeometrie — gemessen am 06.09.2026: Spot drehte
        um 30 Grad von einer offenen Tuer weg.
        """
        richtung = math.radians(heading)
        cos, sin = math.cos(richtung), math.sin(richtung)
        schritt = max(float(self.cell_size), 0.01)
        abstand = schritt
        letzter_freier = 0.0
        while abstand <= max_distance:
            hindernis = self.distance_at(x + abstand * cos, y + abstand * sin)
            if hindernis is None:
                zu = abstand >= FREI_AB_M
            else:
                zu = hindernis < margin
            if zu:
                return letzter_freier
            letzter_freier = abstand
            abstand += schritt
        return float(max_distance)


@dataclass(frozen=True)
class SafetyStatus:
    lease_holder: str | None
    estop_level: str | None


@runtime_checkable
class SpotBackend(Protocol):
    def capabilities(self) -> Capability: ...
    def send_command(self, command, end_time_secs=None) -> str: ...
    def command_feedback(self, command_id) -> Feedback: ...
    def robot_state(self): ...
    def frame_tree_snapshot(self): ...
    def mobility_params(self, limits, nick_grad=0.0): ...
    def image_sources(self) -> list: ...
    def images(self, sources) -> list: ...
    def world_objects(self, kinds=None) -> list: ...
    def stairs(self) -> list: ...
    def local_grid(self): ...
    def power_on(self) -> None: ...
    def power_off(self, safe=True) -> None: ...
    @property
    def is_powered(self) -> bool: ...
    def safety_status(self) -> SafetyStatus: ...
    def close(self) -> None: ...


_EINZELN = (
    Capability.LOCOMOTION,
    Capability.POSTURE,
    Capability.POWER,
    Capability.DEPTH_CAMERAS,
    Capability.GRAY_CAMERAS,
    Capability.COLOR_CAMERAS,
    Capability.LEASE,
    Capability.ESTOP,
    Capability.STAIRS,
    Capability.GRAPH_NAV,
    Capability.WORLD_OBJECTS,
    Capability.LOCAL_GRID,
)


def require(backend, capability, wofuer):
    """Prüft eine Fähigkeit. Beim Alias CAMERAS genügt eine der drei Kameraarten.

    `faehigkeits_hinweis` darf ein Backend setzen, wenn die Aufzählung allein in
    die Irre führte. Die Nur-Lesen-Sitzung am echten Roboter ist der Fall, für
    den es gebaut ist: dort fehlt LOCOMOTION nicht, weil das Backend es nicht
    könnte, sondern weil DIESE Sitzung kein Lease hält — und die Meldung muss
    sagen, was zu tun ist, nicht nur, was fehlt (Projektregel).
    """
    vorhanden = backend.capabilities()
    if vorhanden & capability:
        return
    hinweis = getattr(backend, "faehigkeits_hinweis", "")
    raise UnsupportedCapability(
        f"Dieses Backend beherrscht '{wofuer}' nicht. Vorhanden: {_lesbar(vorhanden)}."
        + (f" {hinweis}" if hinweis else "")
    )


def _lesbar(faehigkeiten):
    namen = [glied.name.lower() for glied in _EINZELN if glied & faehigkeiten]
    return ", ".join(namen) if namen else "nichts"
