"""Ein Backend, das sich nach gemessenen Daten bewegt.

Die Naht ist dieselbe wie bei `DryRunBackend` und `RealSpot`: echte
`RobotCommand`-Protobufs herein, echte `RobotState`-Protobufs heraus. Alles
darüber — Aufzeichnung, Messfenster, Auswertung, GUI, Live-Ansicht — merkt
keinen Unterschied und ist unverändert getestet.

Der Unterschied zu `DryRunBackend`: dort steht der Zustand still. Hier bewegt
er sich, und zwar so, wie der echte Spot am 12.08.2026 gemessen wurde.

WAS DAS IST
    Eine Interpolation zwischen gemessenen Gangarten. Bei 0.36 m/s bewegen
    sich die Gelenke so, wie sie sich am echten Roboter bei 0.36 m/s bewegt
    haben. Und seit dem 23.09.2026 kommt das Tempo so, wie der echte Spot es
    auf ein walk()-Kommando liefert (`kalibrierung/tempoantwort.py`, 60
    kommandierte Laeufe): nach 0.1 s Latenz, aus dem Stand mit Anlauf, mit
    Anfahren und Auslaufen, im gemessenen Anteil des Sollwerts, und reines
    Drehen unter 0.125 rad/s bleibt stehen. Bis dahin galt: kommandiert IST
    erreicht, sofort -- ein Programm lief im Sim ohne Verzug und stand beim
    Loslassen im selben Takt.

WAS DAS NICHT IST
    Physik. Es gibt keine Massen, keine Kontaktkräfte, keinen Regler. Der
    Roboter kann hier nicht umfallen, nicht rutschen und nicht an einer Kante
    hängenbleiben. Ein Skript, das hier durchläuft, ist NICHT erprobt — es ist
    gegen eine Interpolation gelaufen.

    Deshalb steht `backend: "sim"` in `lauf.json`, deshalb sagt
    `hinweis_zur_gueltigkeit()` es im Klartext, und deshalb hat dieses Backend
    weder Kameras noch GraphNav: für beides gibt es keine Messung, und ein
    erfundenes Bild wäre schlimmer als gar keins.
"""

import itertools
import math
import threading
import time
from contextlib import nullcontext
from functools import wraps

from bosdyn.api import robot_command_pb2, robot_state_pb2
from bosdyn.client.frame_helpers import ODOM_FRAME_NAME
from google.protobuf import wrappers_pb2

from spotlab.backends import mobility
from spotlab.backends.base import (
    Capability,
    Feedback,
    ObstacleGrid,
    SafetyStatus,
    Staircase,
    Tag,
    richtung,
)
from spotlab.errors import CommandRejected, NotPowered, UnsupportedCapability
from spotlab.welt.kollision import MAX_SCHRITT_M

# Wie lange ein Fahrkommando gilt, wenn keine Endzeit mitkommt. Der echte Spot
# hält ohne Nachschub an; das muss hier genauso sein, sonst liefe ein Skript im
# Sim ewig weiter, das am Roboter nach einer Sekunde stehenbliebe.
NACHLAUF_S = 1.0

# Wann ein Ziel als erreicht gilt. Gependelt wird nicht: das Bremsprofil
# (`antwort.tempo`, v <= sqrt(2 b rest)) laeuft bis zum Rest 0, und der letzte
# Schritt ist in `_zum_ziel` auf den Rest gedeckelt (`abstand / dt`). Bis zum
# 23.09.2026 standen hier 2 cm und 0.03 rad (1.7 Grad): Spot hielt ANGEKOMMEN,
# sobald er so nahe war, noch mitten im Bremsen -- `move(forward=0.05)` fuhr
# 3 cm, `move(turn=2)` 0.3 Grad, zehnmal 0.1 m ergaben 0.8 m (Beta-Pruefung).
ZIEL_TOLERANZ_M = 0.001
ZIEL_TOLERANZ_RAD = math.radians(0.1)

# Wie weit die Koerperhoehe von der Standhoehe abweichen darf -- derselbe
# Bereich, den `pose()` an der Fassade zusichert (api/body.py, ±0.15 m).
# Darueber hinaus klemmt der Sim: `stand(height=-1)` steckte den Koerper bis
# zum 23.09.2026 einen halben Meter in den Boden, `height=2` hob ihn auf
# 2.5 m. Was der echte Spot bei groesseren Werten tut, ist NICHT gemessen.
HOEHE_BEREICH_M = 0.15

HINWEIS = (
    "Dieser Lauf ist NICHT am Roboter erprobt. Das Sim-Backend interpoliert "
    "gemessene Gangarten — es kennt keine Physik: nichts kann umfallen, "
    "rutschen oder hängenbleiben."
)


# Begrenzter Integrationsschritt, unabhaengig vom Abtaster (10 oder 50 Hz).
MAX_DT_S = 0.005


def synchronisiert(methode):
    """Eine Backend-Transaktion, einschliesslich aller Puppen-Zwischenposen.

    Immer Backend vor Puppe sperren. Der Bildthread braucht nur die Puppe;
    er sieht damit ausschliesslich den fertig uebernommenen Zustand.
    """
    @wraps(methode)
    def aufruf(self, *args, **kwargs):
        with self._sperre:
            puppe = getattr(self, "puppe", None)
            with puppe.lock if puppe is not None else nullcontext():
                return methode(self, *args, **kwargs)
    return aufruf


class SimBackend:
    """Bewegt sich nach der Gangkennlinie. Kein Roboter, keine Physik."""

    def __init__(self, recorder=None, jetzt=time.time, modell=None,
                 raum=None, start=None, antwort=None, treppen="auto", tempoantwort=None):
        from spotlab.kalibrierung.antwort import lade_modell as lade_antwort
        from spotlab.kalibrierung.modell import lade_modell
        from spotlab.kalibrierung.tempoantwort import Folger
        from spotlab.kalibrierung.tempoantwort import lade_modell as lade_tempoantwort

        # Stufe 10: ein Zimmer um den Sim herum. OHNE Raum verhaelt sich alles
        # exakt wie vorher -- daran haengt jeder bestehende Lauf und jeder
        # bestehende Test.
        self._raum = raum
        self._angestossen = False      # Flanke, damit das Protokoll lesbar bleibt

        self._sperre = threading.RLock()
        self._aktives_ziel = None
        self._recorder = recorder
        self._jetzt = jetzt
        self._modell = modell or lade_modell()
        # Die Koerperantwort auf Ziele -- Anfahren, Reisetempo, Bremsen -- aus
        # den kommandierten Laeufen vom 02.09.2026. Vorher fuhr ein Ziel mit
        # einem Tempo aus der Mitte der Kennlinie: ein Platzhalter, der es
        # immerhin zugab.
        self._antwort = antwort or lade_antwort()
        # Die Antwort auf walk(): der Folger haelt das IST-Tempo, `_soll` bleibt
        # das Kommando (die Treppenregel fragt die befohlene Richtung). Ziele
        # (move) fahren weiter ihr eigenes Profil oben.
        self._tempo = tempoantwort or lade_tempoantwort()
        self._folger = Folger(self._tempo)
        self._abgelaufen = True            # der Ablauf des letzten walk ist vorgemerkt
        self._letzte_art = None
        self._unter_drehschwelle = 0       # Kommandos, die Spot auf der Stelle stehen laesst
        self._tempo_ausserhalb = 0         # Kommandos ausserhalb des gemessenen Tempoanteils
        self._deckel = (None, None)        # (m/s, rad/s) aus vel_limit im Kommando
        self._ziele_ausserhalb = 0
        # Totzeiten der gemessenen Antwort: vor dem Losfahren und -- nach dem
        # Stillstand -- bis zur Rueckmeldung. Der echte Spot meldet eine
        # Drehung erst 0.55 s nach dem Stillstand als angekommen.
        self._ziel_ab = 0.0                # frueher faehrt er nicht los
        self._ziel_erreicht = None         # wann er still stand
        self._ziel_nachlauf = 0.0          # so lange danach noch "unterwegs"
        self._powered = False
        self._zaehler = itertools.count(1)
        self._offen = {}
        self.gesendet = []

        self._t = jetzt()
        if start is not None:
            # Raum- und odom-Koordinaten fallen damit zusammen; die Ansicht muss
            # nichts umrechnen.
            self._pose = (float(start[0]), float(start[1]), math.radians(start[2]))
        else:
            self._pose = (0.0, 0.0, 0.0)
        self._phase = 0.0
        self._soll = (0.0, 0.0, 0.0)
        self._gueltig_bis = 0.0
        # Spot beginnt, wie er abgestellt wird: sitzend, Motoren aus. Bis zum
        # 23.09.2026 stand hier False, und der Sim meldete vor `power_on()`
        # STANDING -- ein Programm, das auf den Stand wartet, lief am Sim durch.
        self._sitzt = True
        self._ziel = None
        self._hoehe = self._modell.hoehe_m
        # Stufe 13: Hoehe. `_z` ist der Boden unter der Koerpermitte, `_nick_grad`
        # der Nick entlang der Fahrtrichtung (Rechte-Hand-Regel um y: Nase hoch
        # ist negativ, wie `State.pitch` am echten Spot), `_klippen`
        # die Kanten des Raums, an denen der Boden springt -- einmal je Raum.
        # `treppen` ist der Treppenmodus aus der Konfiguration: bei "aus" sind
        # Rampen und Treppen Klippen, so wie der Roboter sie dann meidet.
        self._treppen = treppen
        self._z, self._nick_grad = 0.0, 0.0
        self._klippen = []
        self._treppe_flanke = False
        self._meldung = ""
        if raum is not None:
            from spotlab.welt.hoehe import boden_bei
            from spotlab.welt.kollision import klippen_von

            self._z, _ = boden_bei(raum, self._pose[0], self._pose[1])
            self._klippen = klippen_von(raum, alles=(treppen == "aus"))
        # Getrennt gezaehlt: Takte sind Zeitschritte, Ziele sind Kommandos.
        self._takte_bewegt = 0
        self._ausserhalb_takte = 0
        self._ziele = 0

    # ------------------------------------------------------------- Auskunft

    def capabilities(self):
        # Keine Kameras, kein GraphNav: dafür gibt es keine Messung. Ein
        # erfundenes Bild wäre schlimmer als gar keins, und `require()` sagt
        # dem Schüler dann ehrlich, was fehlt.
        koennen = Capability.LOCOMOTION | Capability.POSTURE | Capability.POWER
        if self._raum is not None:
            # Mit Raum ist die Wahrnehmung keine Erfindung mehr, sondern
            # Geometrie: sie folgt aus dem, was in der Raumdatei steht.
            koennen |= Capability.WORLD_OBJECTS | Capability.LOCAL_GRID | Capability.STAIRS
        return koennen

    @synchronisiert
    def world_objects(self, kinds=None):
        """Ohne Raum leer — und das ist die Wahrheit, nicht ein Fehler.

        Die Gangart-Interpolation weiss nichts über die Umgebung. Zwei erfundene
        Tags sähen aus wie eine Messung und liefen in jede Auswertung.

        MIT Raum ist es keine Erfindung, sondern Geometrie. Die Übersetzung in
        `Tag` passiert HIER und nicht in `welt/`, weil `richtung()` in
        `backends/base.py` wohnt und `welt/` nichts aus `backends/` importiert.
        """
        if self._raum is None:
            return []
        if kinds is not None and "apriltag" not in kinds:
            return []
        from spotlab.welt.wahrnehmung import sichtbare_tags

        self._fortschreiben()
        gefunden = []
        for tag, dx, dy in sichtbare_tags(self._raum, self._pose, z=self._z):
            peilung, distanz = richtung(dx, dy)
            gefunden.append(Tag(
                name=f"world_obj_apriltag_{tag.id:03d}", kind="apriltag",
                bearing=peilung, distance=distanz, world_xy=(tag.x, tag.y),
                time=self._jetzt(), id=tag.id, filtered=False,
            ))
        return gefunden

    @synchronisiert
    def stairs(self):
        """Die Treppen des Raums in Sicht -- Geometrie, keine Erfindung (wie die Tags)."""
        if self._raum is None:
            return []
        from spotlab.welt.hoehe import bergauf_achse, treppen_in_sicht
        from spotlab.welt.wahrnehmung import TAG_REICHWEITE_M

        self._fortschreiben()
        x, y, yaw = self._pose
        grad = math.degrees(yaw)
        gefunden = []
        for i, lage in enumerate(treppen_in_sicht(self._raum, x, y, grad, TAG_REICHWEITE_M, self._z)):
            achse = (bergauf_achse(lage.boden) - grad + 180.0) % 360.0 - 180.0
            gefunden.append(Staircase(
                name=f"world_obj_staircase_{i + 1:03d}", kind="staircase",
                bearing=lage.peilung_grad, distance=lage.abstand,
                world_xy=(lage.boden.x, lage.boden.y), time=self._jetzt(),
                direction=lage.richtung, steps=lage.boden.stufen,
                rise_m=abs(lage.boden.anstieg), axis_bearing=achse,
            ))
        return gefunden

    def local_grid(self):
        if self._raum is None:
            raise UnsupportedCapability(
                "Die Simulation führt ohne Übungsraum kein Hindernisgitter. "
                "Wähle einen Raum in der Ansicht 'Übungsraum' oder gib ihn an: "
                "spotlab.connect(backend='sim', raum='moebliert')."
            )
        import numpy as np

        from spotlab.welt.wahrnehmung import GITTER_ZELLE_M, abstandsgitter

        self._fortschreiben()
        werte, bekannt, ursprung = abstandsgitter(self._raum, self._pose, z=self._z,
                                                  klippen_=self._klippen)
        return ObstacleGrid(
            cells=np.asarray(werte), cell_size=GITTER_ZELLE_M,
            origin=ursprung, time=self._jetzt(), known=np.asarray(bekannt),
        )

    def _bewege_gegen_welt(self, von, nach):
        """Ohne Raum unveraendert. Mit Raum: an Waenden bleibt Spot stehen.

        Kein Fehler, kein Abbruch -- der echte Spot wirft auch keine Ausnahme,
        wenn er vor einem Hindernis stehenbleibt. Das Programm laeuft weiter und
        `move()` erreicht sein Ziel eben nicht.

        Gemeldet wird nur die FLANKE. Ein Programm, das zehn Sekunden gegen eine
        Wand drueckt, schriebe sonst hundert gleiche Zeilen ins Protokoll.
        """
        if self._raum is None:
            return nach
        from spotlab.welt.kollision import bewege_mit_hoehe

        if self._treppen != "aus" and self._treppe_verweigert(von, nach):
            return (von[0], von[1], nach[2])
        pose, self._z, getroffen = bewege_mit_hoehe(self._raum, von, nach, self._z, self._klippen)
        if getroffen is None:
            self._angestossen = False
        elif not self._angestossen:
            self._angestossen = True
            if self._recorder is not None:
                self._recorder.event(
                    "angestossen",
                    x=round(pose[0], 3), y=round(pose[1], 3), hindernis=getroffen,
                )
        return pose

    def _treppe_verweigert(self, von, nach):
        """Die Treppenregel: auf einer Treppe zeigt die Nase bergauf.

        Geprueft, sobald der Schritt auf die Treppe fuehrt oder ihre Kante
        naeher als den Radius bringt. Verboten heisst: Spot bleibt stehen,
        einmal je Flanke ein Ereignis, und die Rueckmeldung sagt, wie herum.
        Was der echte Spot dabei tut, ist Abnahmepunkt A25.
        """
        from spotlab.welt.hoehe import boden_bei, treppe_erlaubt, treppe_vor
        from spotlab.welt.kollision import ROBOTER_RADIUS_M

        grad = math.degrees(nach[2])
        lage = treppe_vor(self._raum, nach[0], nach[1], grad, self._z)
        if lage is None:
            self._treppe_flanke = False
            return False
        _z, boden = boden_bei(self._raum, nach[0], nach[1], z_nahe=self._z)
        vorher = treppe_vor(self._raum, von[0], von[1], grad, self._z)
        naehert = vorher is None or lage.abstand < vorher.abstand
        betroffen = boden is lage.boden or (lage.abstand <= ROBOTER_RADIUS_M and naehert)
        if not betroffen:
            return False
        erlaubt, verlangt = treppe_erlaubt(lage.richtung, self._soll[0], lage.achsenwinkel_grad)
        if erlaubt:
            self._treppe_flanke = False
            self._meldung = ""
            return False
        self._meldung = (
            f"Treppe {lage.boden.name}: nur mit der Nase bergauf — "
            f"{'aufwärts' if lage.richtung == 'auf' else 'abwärts'} geht nur {verlangt}."
        )
        if not self._treppe_flanke:
            self._treppe_flanke = True
            if self._recorder is not None:
                self._recorder.event(
                    "treppe_verweigert", x=round(von[0], 3), y=round(von[1], 3),
                    treppe=lage.boden.name, richtung=lage.richtung, verlangt=verlangt,
                )
        return True

    def treppengang(self):
        """"nicht gemessen", wenn der Raum Treppen hat -- die Puppe spielt den ebenen Gang."""
        if self._raum is None or not any(b.art == "treppe" for b in self._raum.boeden):
            return None
        return "nicht gemessen"

    def _hoehenbericht(self):
        from spotlab.welt.hoehe import ebenen

        boeden = self._raum.boeden if self._raum is not None else ()
        return {
            "boeden": len(boeden),
            "treppen": sum(1 for b in boeden if b.art == "treppe"),
            "rampen": sum(1 for b in boeden if b.art == "rampe"),
            "ebenen": ebenen(self._raum) if self._raum is not None else [0.0],
            "treppenmodus": self._treppen,
            "treppengang": self.treppengang() or "eben",
        }

    @staticmethod
    def hinweis_zur_gueltigkeit():
        return HINWEIS

    def mobility_params(self, limits, nick_grad=0.0):
        return mobility.mit_grenze(limits)

    def image_sources(self):
        return []

    def images(self, sources):
        raise UnsupportedCapability(
            "Das Sim-Backend hat keine Kameras. Bilder gibt es nur am echten Spot — "
            "erfundene Bilder wären schlimmer als gar keine."
        )

    def safety_status(self):
        return SafetyStatus(lease_holder=None, estop_level=None)

    @property
    def is_powered(self):
        return self._powered

    @synchronisiert
    def power_on(self):
        self._powered = True

    @synchronisiert
    def power_off(self, safe=True):
        self._fortschreiben()
        self._beende_ziel("Motoren aus (Sim)", rejected=True)
        self._powered = False
        self._soll = (0.0, 0.0, 0.0)
        self._folger.zuruecksetzen()
        self._sitzt = True

    def close(self):
        self.power_off()

    @property
    def ausserhalb_der_messung(self):
        """Wie oft nach einer Bewegung gefragt wurde, die nie vermessen wurde."""
        return self._ausserhalb_takte + self._ziele

    def bericht(self):
        """Was dieser Lauf über seine eigene Gültigkeit weiss.

        Gehört beim Abbau in `lauf.json`. Ohne diese Zahlen sieht ein Sim-Lauf
        aus wie jeder andere — und niemand erkennt, dass die Hälfte davon
        ausserhalb der vermessenen Gangarten lag.

        Takte und Zieltrajektorien werden GETRENNT gezählt: das eine sind
        Zeitschritte, das andere Kommandos. Sie in eine Zahl zu addieren gäbe
        ein Verhältnis, das von der Abtastrate abhinge.
        """
        tempo_von, tempo_bis = self._modell.tempo_bereich
        dreh_von, dreh_bis = self._modell.dreh_bereich
        anteil = (
            round(self._ausserhalb_takte / self._takte_bewegt, 3)
            if self._takte_bewegt else None
        )
        return {
            "hinweis": HINWEIS,
            "hoehe": self._hoehenbericht(),
            "takte_in_bewegung": self._takte_bewegt,
            "takte_ausserhalb_der_messung": self._ausserhalb_takte,
            "anteil_ausserhalb": anteil,
            # Zieltrajektorien fahren die gemessene Antwort (1 m, 90°); was
            # darüber hinausgeht, steht unter "antwort".
            "zieltrajektorien": self._ziele,
            "antwort": {
                **self._antwort.beschreibung(),
                "ziele_ausserhalb_der_messung": self._ziele_ausserhalb,
            },
            # Die Antwort auf walk(); was davon nicht gemessen ist, zaehlt hier.
            "tempoantwort": {
                **self._tempo.beschreibung(),
                "befehle_unter_drehschwelle": self._unter_drehschwelle,
                "befehle_ausserhalb_der_messung": self._tempo_ausserhalb,
            },
            "kennlinie": {
                "stuetzstellen_fahrt": len(self._modell.fahren),
                "stuetzstellen_drehung": len(self._modell.drehen),
                "tempo_bereich_m_s": [round(tempo_von, 3), round(tempo_bis, 3)],
                "drehrate_bereich_rad_s": [round(dreh_von, 3), round(dreh_bis, 3)],
                "standhoehe_m": round(self._modell.hoehe_m, 4),
            },
        }

    # ------------------------------------------------------------- Kommandos

    @synchronisiert
    def send_command(self, command, end_time_secs=None):
        if not self._powered:
            raise NotPowered("Die Motoren sind aus — rufe zuerst `spot.power_on()` auf.")
        jetzt = self._jetzt()
        if end_time_secs is not None:
            self._pruefe_endzeit(float(end_time_secs), jetzt)
        kommando = self._als_robot_command(command)
        mobil = kommando.synchronized_command.mobility_command
        if mobil.WhichOneof("command") == "se2_trajectory_request":
            self._ziel_aus(mobil.se2_trajectory_request)  # vor jeder Zustandsaenderung pruefen
        self._hoehenversatz(mobil)                         # ebenso: NaN wird abgewiesen
        self.gesendet.append(kommando)
        self._fortschreiben()
        self._beende_ziel("ersetzt (Sim)", rejected=True)
        self._uebernehmen(kommando, end_time_secs, jetzt)
        kennung = f"sim-{next(self._zaehler)}"
        # Merken, ob dieses Kommando ein ZIEL hatte: nur dann darf die
        # Rückmeldung erst bei Ankunft „fertig" sagen. Sonst kehrte `move()`
        # zurück, während der Roboter noch unterwegs ist.
        self._offen[kennung] = "ziel" if self._ziel is not None else 0
        if self._ziel is not None:
            self._aktives_ziel = kennung
        return kennung

    @staticmethod
    def _pruefe_endzeit(endzeit, jetzt):
        """Wie `DryRunBackend`, aus demselben Grund: `end_time_secs` ist ein
        ZEITPUNKT. Ein Sim, der eine abgelaufene Endzeit annimmt, liesse den
        Fehler durch, an dem der echte Spot sich nie bewegt hätte."""
        if endzeit <= jetzt:
            raise CommandRejected(
                f"Das Kommando war beim Absenden schon abgelaufen (Endzeit "
                f"{endzeit:.1f}, jetzt {jetzt:.1f}). `end_time_secs` ist ein "
                f"Zeitpunkt in Sekunden seit dem 1.1.1970, keine Dauer."
            )

    @staticmethod
    def _als_robot_command(command):
        if isinstance(command, (bytes, bytearray)):
            kommando = robot_command_pb2.RobotCommand()
            kommando.ParseFromString(bytes(command))
            return kommando
        if not isinstance(command, robot_command_pb2.RobotCommand):
            raise ValueError(
                f"Erwartet wird ein bosdyn RobotCommand-Protobuf, bekommen: "
                f"{type(command).__name__}"
            )
        return command

    def _uebernehmen(self, kommando, end_time_secs, jetzt):
        """Aus dem Protobuf lesen, was gefahren werden soll."""
        mobil = kommando.synchronized_command.mobility_command
        art = mobil.WhichOneof("command")
        # Jedes neue Kommando hebt ein laufendes Ziel auf. Sonst arbeitete ein
        # `walk()` nach einem `move()` gegen den Zielregler, und beide schrieben
        # abwechselnd in `_soll`.
        if art != "se2_trajectory_request":
            self._ziel = None
        if art in ("se2_velocity_request", "se2_trajectory_request", "stand_request"):
            # Jedes dieser Kommandos traegt seine Koerperhoehe in den params --
            # ohne eigene Angabe baut das SDK sie mit body_height=0. Wie am
            # Roboter geht also normal hoch, wer geduckt stand und losfaehrt.
            self._hoehe = self._modell.hoehe_m + self._hoehenversatz(mobil)
        if art == "se2_velocity_request":
            # `angular` ist bei SE2Velocity ein SKALAR, kein Vektor — anders als
            # bei der Geschwindigkeit im RobotState, wo `angular.z` steht.
            v = mobil.se2_velocity_request.velocity
            if self._letzte_art == "se2_trajectory_request":
                # Aus dem Zielprofil weiter, sonst spraenge das Tempo auf null.
                self._folger.zuruecksetzen(
                    self._soll if jetzt < self._gueltig_bis else (0.0, 0.0, 0.0))
            self._soll = (v.linear.x, v.linear.y, v.angular)
            ziel, unter = self._tempo.ziel(*self._soll)
            self._unter_drehschwelle += unter
            self._tempo_ausserhalb += not self._tempo.gemessen(*self._soll)
            self._folger.befehl(jetzt, ziel)
            self._abgelaufen = False
            self._sitzt = False
            self._gueltig_bis = (
                float(end_time_secs) if end_time_secs is not None else jetzt + NACHLAUF_S
            )
        elif art == "stand_request":
            self._soll = (0.0, 0.0, 0.0)
            self._folger.befehl(jetzt, (0.0, 0.0, 0.0))
            self._sitzt = False
        elif art == "sit_request":
            self._soll = (0.0, 0.0, 0.0)
            self._folger.zuruecksetzen()
            self._sitzt = True
        elif art == "se2_trajectory_request":
            self._folger.zuruecksetzen()
            # Eine Zieltrajektorie: der echte Spot wählt sein Tempo selbst. WIE,
            # ist seit dem 02.09.2026 gemessen (kalibrierung/antwort.py):
            # Anfahren, Reisetempo, Bremsen — bei 1 m und 90°. Andere Ziele
            # fahren dasselbe Profil und werden als ausserhalb der Messung
            # gezählt. Den Deckel liest der Sim aus demselben Feld wie der
            # Roboter: `vel_limit` in den MobilityParams des Kommandos.
            self._ziele += 1
            self._sitzt = False
            self._ziel = self._ziel_aus(mobil.se2_trajectory_request)
            self._deckel = self._deckel_aus(mobil)
            self._ziel_erreicht = None
            if self._ziel is not None:
                strecke, winkel = self._ziel_relativ()
                if not self._antwort.gemessen(strecke, winkel):
                    self._ziele_ausserhalb += 1
                vorher, nachher = self._antwort.verzug(strecke, winkel)
                self._ziel_ab = jetzt + vorher
                self._ziel_nachlauf = nachher
            self._soll = (0.0, 0.0, 0.0)
            self._gueltig_bis = (
                float(end_time_secs) if end_time_secs is not None else jetzt + NACHLAUF_S
            )
        else:
            # stop_command und alles andere: anhalten -- nach der Latenz, mit
            # Auslaufen (gemessen: 90 % -> 10 % in rund 0.3 s).
            self._soll = (0.0, 0.0, 0.0)
            self._gueltig_bis = jetzt
            self._folger.befehl(jetzt, (0.0, 0.0, 0.0))
            self._abgelaufen = True
        self._letzte_art = art

    def _ziel_aus(self, anfrage):
        """Zielpose (x, y, yaw) im odom-Frame, oder None.

        `synchro_trajectory_command_in_body_frame()` rechnet das Körperziel
        schon in den odom-Frame um — der Rahmenname steht in der Anfrage. Ein
        anderer Rahmen wird NICHT geraten: die Anfrage wird abgewiesen,
        bevor sie ein bereits laufendes Kommando ersetzen kann.
        """
        if anfrage.se2_frame_name != ODOM_FRAME_NAME or not anfrage.trajectory.points:
            raise CommandRejected("Sim-Ziel braucht odom und mindestens einen Trajektorienpunkt.")
        pose = anfrage.trajectory.points[-1].pose
        return (pose.position.x, pose.position.y, pose.angle)

    def _ziel_relativ(self):
        """(Strecke m, Winkel grad) vom jetzigen Stand zum Ziel."""
        x, y, yaw = self._pose
        zx, zy, zyaw = self._ziel
        dyaw = (zyaw - yaw + math.pi) % (2 * math.pi) - math.pi
        return math.hypot(zx - x, zy - y), math.degrees(dyaw)

    @staticmethod
    def _deckel_aus(mobil):
        """(m/s, rad/s) aus `vel_limit` der MobilityParams — oder None je Achse.

        Dasselbe Feld, das `backends/mobility.py::se2_grenze` fuer den echten
        Roboter setzt. Fehlt es, gilt nur das gemessene Reisetempo.
        """
        try:
            from bosdyn.api.spot import robot_command_pb2 as spot_pb2

            if not mobil.HasField("params"):
                return None, None
            params = spot_pb2.MobilityParams()
            mobil.params.Unpack(params)
            if not params.HasField("vel_limit") or not params.vel_limit.HasField("max_vel"):
                return None, None
            v = float(params.vel_limit.max_vel.linear.x)
            w = float(params.vel_limit.max_vel.angular)
            return (v if v > 0 else None), (w if w > 0 else None)
        except Exception:
            return None, None

    def _zum_ziel(self, dt, jetzt):
        """Sollgeschwindigkeit im Körperframe, um dem Ziel näherzukommen.

        Das Tempo kommt aus dem Antwortmodell: anfahren mit der gemessenen
        Beschleunigung, höchstens das gemessene Reisetempo (und nie über den
        Deckel), bremsen, dass es mit der gemessenen Verzögerung zum Stillstand
        reicht. Der bisherige Wert -- `self._soll` -- ist der Zustand des
        Profils; eine Zeitbuchführung braucht es nicht.

        Verschieben und Drehen laufen GLEICHZEITIG, jedes hört für sich auf,
        wenn seine Toleranz erreicht ist. Ein Nacheinander („erst drehen, dann
        fahren") wäre ein erfundener Regler — der echte Spot läuft auch schräg.
        """
        x, y, yaw = self._pose
        zx, zy, zyaw = self._ziel
        dx, dy = zx - x, zy - y
        abstand = math.hypot(dx, dy)
        dyaw = (zyaw - yaw + math.pi) % (2 * math.pi) - math.pi

        fertig_weg = abstand <= ZIEL_TOLERANZ_M
        fertig_dreh = abs(dyaw) <= ZIEL_TOLERANZ_RAD
        if fertig_weg and fertig_dreh:
            # Angekommen -- aber gemeldet wird es erst nach der gemessenen
            # Totzeit; solange steht der Roboter still und ist "unterwegs".
            if self._ziel_erreicht is None:
                self._ziel_erreicht = jetzt
            if jetzt < self._ziel_erreicht + self._ziel_nachlauf:
                return 0.0, 0.0, 0.0
            return None
        if jetzt < self._ziel_ab:
            return 0.0, 0.0, 0.0           # der Roboter faehrt nicht sofort los

        vx = vy = 0.0
        if not fertig_weg:
            tempo = self._antwort.tempo(
                math.hypot(self._soll[0], self._soll[1]), abstand, dt, self._deckel[0]
            )
            # Richtung in den Körperframe drehen: die Geschwindigkeit im
            # Kommando ist körperfest, der Abstand steht in odom.
            tempo = min(tempo, abstand / dt)
            richtung = math.atan2(dy, dx) - yaw
            vx, vy = tempo * math.cos(richtung), tempo * math.sin(richtung)
        wz = 0.0
        if not fertig_dreh:
            wz = math.copysign(
                self._antwort.drehrate(abs(self._soll[2]), abs(dyaw), dt, self._deckel[1]),
                dyaw,
            )
        wz = math.copysign(min(abs(wz), abs(dyaw) / dt), wz)
        return vx, vy, wz

    @staticmethod
    def _hoehenversatz(mobil):
        """Die Körperhöhe aus `synchro_stand_command(body_height=...)`, geklemmt.

        Sie steht nicht im `stand_request`, sondern in den `params` des
        Mobility-Kommandos — einem `Any`, das erst als `MobilityParams`
        ausgepackt werden muss. Der Weg dorthin ist lang und versionsabhängig;
        scheitert er, gilt die gemessene Standhöhe. Eine falsche Höhe ist ein
        Schönheitsfehler, ein Absturz beim `spot.stand()` eines Schülers nicht.

        Geklemmt auf ±HOEHE_BEREICH_M. Ein NaN oder inf ist keine Höhe, die
        man klemmen könnte: CommandRejected, bevor sich etwas ändert.
        """
        try:
            from bosdyn.api.spot import robot_command_pb2 as spot_pb2

            if not mobil.HasField("params"):
                return 0.0
            params = spot_pb2.MobilityParams()
            mobil.params.Unpack(params)
            punkte = params.body_control.base_offset_rt_footprint.points
            versatz = float(punkte[0].pose.position.z) if punkte else 0.0
        except Exception:
            return 0.0
        if not math.isfinite(versatz):
            raise CommandRejected(
                f"Die Körperhöhe {versatz} ist keine endliche Zahl -- Spot bleibt, wie er "
                f"ist. `stand(height=...)` nimmt Meter zwischen -{HOEHE_BEREICH_M} und "
                f"+{HOEHE_BEREICH_M}."
            )
        return max(-HOEHE_BEREICH_M, min(HOEHE_BEREICH_M, versatz))

    @synchronisiert
    def command_feedback(self, command_id):
        rueck = self._rueckmeldung(command_id)
        if self._meldung:
            return Feedback(done=rueck.done, status=f"{rueck.status} — {self._meldung}",
                            rejected=rueck.rejected)
        return rueck

    def _beende_ziel(self, status, rejected=False):
        if self._aktives_ziel is not None:
            self._offen[self._aktives_ziel] = Feedback(
                done=not rejected, status=status, rejected=rejected,
            )
        self._aktives_ziel = None
        self._ziel = None

    def _rueckmeldung(self, command_id):
        self._fortschreiben()
        stand = self._offen.get(command_id)
        if isinstance(stand, Feedback):
            return stand
        if stand is None:
            return Feedback(done=False, status="unbekanntes Kommando (Sim)", rejected=True)
        if stand == "ziel":
            return Feedback(done=False, status="unterwegs (Sim)")
        self._offen[command_id] = stand + 1
        return Feedback(done=stand > 0, status="fertig (Sim)" if stand else "unterwegs (Sim)")

    # ------------------------------------------------------------- Zustand

    @synchronisiert
    def _fortschreiben(self):
        """Gueltige Teilintervalle integrieren, auch nach einer Abfragepause.

        Startverzug und Ablauf sind Zeitgrenzen, keine Eigenschaften des
        letzten Abfragezeitpunkts. Rueckwaertsspruenge werden nicht doppelt
        integriert. Kleine Schritte begrenzen den Fehler des Zielprofils.
        """
        jetzt = self._jetzt()
        if jetzt <= self._t:
            return
        geprueft = self._pose
        if self._ziel is not None:
            ende = min(jetzt, self._gueltig_bis)
            while self._t < ende and self._ziel is not None:
                if not self._powered or self._sitzt:
                    break
                if self._t < self._ziel_ab:
                    self._t = min(ende, self._ziel_ab)
                    continue
                weiter = min(ende, self._t + MAX_DT_S)
                self._schritt(weiter - self._t, self._t)
                if math.dist(geprueft[:2], self._pose[:2]) >= MAX_SCHRITT_M:
                    geprueft = self._welt_pruefen(geprueft)
                self._t = weiter
        else:
            # walk(): das Ist-Tempo laeuft auch NACH dem Ablauf aus. Der Ablauf
            # ist ein Nullkommando genau zur Ablaufzeit -- vorgemerkt, wenn die
            # Zeit ihn erreicht, damit ein spaeteres Kommando ihn nicht ueberholt.
            while self._t < jetzt and self._powered and not self._sitzt:
                if not self._abgelaufen and self._t >= self._gueltig_bis:
                    self._folger.befehl(self._gueltig_bis, (0.0, 0.0, 0.0))
                    self._abgelaufen = True
                if self._folger.ruht:
                    break
                weiter = min(jetzt, self._t + MAX_DT_S)
                if not self._abgelaufen and self._t < self._gueltig_bis < weiter:
                    weiter = self._gueltig_bis
                ereignis = self._folger.naechstes_ereignis()
                if ereignis is not None and self._t < ereignis < weiter:
                    weiter = ereignis
                self._schritt(weiter - self._t, self._t)
                if math.dist(geprueft[:2], self._pose[:2]) >= MAX_SCHRITT_M:
                    geprueft = self._welt_pruefen(geprueft)
                self._t = weiter
            if not self._abgelaufen and jetzt >= self._gueltig_bis:
                self._folger.befehl(self._gueltig_bis, (0.0, 0.0, 0.0))
                self._abgelaufen = True
        self._welt_pruefen(geprueft)
        if jetzt >= self._gueltig_bis:
            self._beende_ziel("abgelaufen (Sim)", rejected=True)
            self._soll = (0.0, 0.0, 0.0)
        self._t = jetzt

    def _geschwindigkeit(self):
        """Das IST-Tempo: bei Zielen das Profil, bei walk() der Folger."""
        if not self._powered or self._sitzt:
            return 0.0, 0.0, 0.0
        if self._ziel is not None:
            return self._soll if self._t < self._gueltig_bis else (0.0, 0.0, 0.0)
        return self._folger.ist

    def _schritt(self, dt, jetzt):
        from spotlab.kalibrierung.modell import integriere

        if self._ziel is not None:
            gefunden = self._zum_ziel(dt, jetzt)
            if gefunden is None:
                self._beende_ziel("angekommen (Sim)")
                self._soll = (0.0, 0.0, 0.0)
            else:
                self._soll = gefunden
            vx, vy, wz = self._soll
        else:
            vx, vy, wz = self._folger.schritt(jetzt, dt)
        tempo = math.hypot(vx, vy)
        if tempo > 1e-6 or abs(wz) > 1e-6:
            self._takte_bewegt += 1
            if self._modell.rand(tempo, wz):
                self._ausserhalb_takte += 1
            dauer = self._modell.zyklusdauer(tempo, wz)
            if dauer > 0:
                self._phase = (self._phase + dt / dauer) % 1.0
            self._pose = integriere(self._pose, vx, vy, wz, dt)

    def _welt_pruefen(self, von):
        """Die Welt gegen den Weg seit `von` halten: Waende, Kanten, Hoehe, Nick.

        Nicht je Integrationsschritt, sondern je MAX_SCHRITT_M Weg und am Ende
        jeder Abfrage -- die Zusicherung "kein Tunneln" haengt an der Strecke,
        der 5-ms-Takt dient nur dem Zielprofil. Auf den Katakomben (330 Waende,
        Hunderte Klippenstrecken, Gelaende) kostete die Pruefung 2-3 ms und lief
        200-mal je Sekunde: der Sim fiel hinter die Echtzeit (07.09.2026). Eine
        Pose sieht niemand, bevor sie hier war.
        """
        if self._pose == von:
            return von
        self._pose = self._bewege_gegen_welt(von, self._pose)
        if self._raum is not None:
            from spotlab.welt.hoehe import nick_grad

            self._nick_grad = nick_grad(self._raum, *self._pose, z_nahe=self._z)
        return self._pose

    @synchronisiert
    def robot_state(self):
        self._fortschreiben()
        vx, vy, wz = self._geschwindigkeit()
        tempo = math.hypot(vx, vy)
        steht_still = tempo <= 1e-6 and abs(wz) <= 1e-6

        zustand = robot_state_pb2.RobotState()
        akku = zustand.battery_states.add()
        akku.charge_percentage.CopyFrom(wrappers_pb2.DoubleValue(value=88.0))
        akku.voltage.CopyFrom(wrappers_pb2.DoubleValue(value=55.9))
        akku.current.CopyFrom(wrappers_pb2.DoubleValue(value=-3.3))
        zustand.power_state.motor_power_state = (
            robot_state_pb2.PowerState.STATE_ON
            if self._powered
            else robot_state_pb2.PowerState.STATE_OFF
        )
        # Der Enum kennt: UNKNOWN, NOT_READY, TRANSITION, STANDING, STEPPING —
        # kein Sitzen. NOT_READY ist die Deutung „kann gerade nicht laufen"; was
        # der echte Spot im Sitzen meldet, ist UNGEPRUEFT (unsere Messfahrten
        # zeigen 1668-mal STANDING und nie etwas anderes). Steht so in
        # docs/ABNAHME.md.
        if self._sitzt:
            zustand.behavior_state.state = robot_state_pb2.BehaviorState.STATE_NOT_READY
        elif steht_still:
            zustand.behavior_state.state = robot_state_pb2.BehaviorState.STATE_STANDING
        else:
            zustand.behavior_state.state = robot_state_pb2.BehaviorState.STATE_STEPPING

        winkel = self._modell.gelenke(tempo, wz, self._phase)
        kontakte = (
            [True] * 4 if steht_still
            else self._modell.fusskontakte(tempo, wz, self._phase)
        )
        for name in self._modell.gelenknamen:
            gelenk = zustand.kinematic_state.joint_states.add()
            gelenk.name = name
            gelenk.position.CopyFrom(wrappers_pb2.DoubleValue(value=winkel[name]))
            # Geschwindigkeit, Beschleunigung und Last bleiben NULL und das ist
            # eine Aussage: die Kennlinie trägt nur Winkel. Erfundene Momente
            # sähen aus wie Messwerte und liefen in jede Auswertung.
            gelenk.velocity.CopyFrom(wrappers_pb2.DoubleValue(value=0.0))
            gelenk.acceleration.CopyFrom(wrappers_pb2.DoubleValue(value=0.0))
            gelenk.load.CopyFrom(wrappers_pb2.DoubleValue(value=0.0))

        for kontakt in kontakte:
            fuss = zustand.foot_state.add()
            fuss.contact = (
                robot_state_pb2.FootState.CONTACT_MADE
                if kontakt
                else robot_state_pb2.FootState.CONTACT_LOST
            )
            fuss.foot_position_rt_body.z = -self._hoehe
            # KEIN terrain: `ground_mu_est` wurde nicht modelliert, und eine
            # erfundene 0.6 mittelte sich durch jede Kalibrierauswertung.

        zustand.kinematic_state.acquisition_timestamp.seconds = int(self._t)
        zustand.kinematic_state.acquisition_timestamp.nanos = int((self._t % 1) * 1e9)
        geschwindigkeit = zustand.kinematic_state.velocity_of_body_in_odom
        yaw = self._pose[2]
        geschwindigkeit.linear.x = vx * math.cos(yaw) - vy * math.sin(yaw)
        geschwindigkeit.linear.y = vx * math.sin(yaw) + vy * math.cos(yaw)
        geschwindigkeit.angular.z = wz
        zustand.kinematic_state.transforms_snapshot.CopyFrom(self._frame_tree_snapshot())
        return zustand

    @synchronisiert
    def frame_tree_snapshot(self):
        self._fortschreiben()
        return self._frame_tree_snapshot()

    def _frame_tree_snapshot(self):
        from bosdyn.api import geometry_pb2
        from bosdyn.client.frame_helpers import (
            BODY_FRAME_NAME,
            ODOM_FRAME_NAME,
            VISION_FRAME_NAME,
        )

        x, y, yaw = self._pose
        baum = geometry_pb2.FrameTreeSnapshot()
        baum.child_to_parent_edge_map[VISION_FRAME_NAME].CopyFrom(
            geometry_pb2.FrameTreeSnapshot.ParentEdge()
        )
        nach_odom = geometry_pb2.FrameTreeSnapshot.ParentEdge(
            parent_frame_name=VISION_FRAME_NAME
        )
        nach_odom.parent_tform_child.rotation.w = 1.0
        baum.child_to_parent_edge_map[ODOM_FRAME_NAME].CopyFrom(nach_odom)

        koerper = geometry_pb2.FrameTreeSnapshot.ParentEdge(
            parent_frame_name=ODOM_FRAME_NAME
        )
        koerper.parent_tform_child.position.x = x
        koerper.parent_tform_child.position.y = y
        koerper.parent_tform_child.position.z = self._z + self._hoehe
        # Yaw um z, danach Nick um die eigene y-Achse (Rechte-Hand-Regel, Nase
        # hoch negativ -- `nick_grad` liefert es schon so, `rpy_aus` liest es so).
        cy, sy = math.cos(yaw / 2.0), math.sin(yaw / 2.0)
        nick = math.radians(self._nick_grad)
        cp, sp = math.cos(nick / 2.0), math.sin(nick / 2.0)
        koerper.parent_tform_child.rotation.w = cy * cp
        koerper.parent_tform_child.rotation.x = -sy * sp
        koerper.parent_tform_child.rotation.y = cy * sp
        koerper.parent_tform_child.rotation.z = sy * cp
        baum.child_to_parent_edge_map[BODY_FRAME_NAME].CopyFrom(koerper)
        return baum
