"""Konfiguration in ~/.spotlab/config.toml, Passwort in der Anmeldeinformationsverwaltung.

Kein Passwort im Klartext auf zwanzig Schullaptops: das Passwort geht über
keyring in den Windows-Tresor, die Konfigurationsdatei enthält es nie.
"""

import math
import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

from spotlab.errors import ConfigBroken, ConfigMissing

CONFIG_PATH = Path.home() / ".spotlab" / "config.toml"
KEYRING_SERVICE = "spotlab"
BACKENDS = ("real", "dryrun", "sim", "mujoco", "physics")
ENV_PASSWORD = "BOSDYN_CLIENT_PASSWORD"
ENV_USERNAME = "BOSDYN_CLIENT_USERNAME"
TREPPENMODI = ("auto", "aus")


@dataclass(frozen=True)
class Limits:
    max_speed: float = 0.6  # m/s
    max_turn_rate: float = 0.8  # rad/s
    # Treppenmodus: "auto" -- der Roboter erkennt Treppen und nimmt sie;
    # "aus" -- Treppen sind tabu. Ein Sicherheitswert wie die Deckel, deshalb
    # hier: `backends/mobility.py::mit_grenze` setzt daraus `stairs_mode` an
    # EINER Stelle, und der Sim liest denselben Wert.
    treppen: str = "auto"


@dataclass(frozen=True)
class Config:
    ip: str
    username: str
    nickname: str = "Spot"
    limits: Limits = field(default_factory=Limits)
    editor_command: str = "code"
    # Wer nichts einstellt, faehrt NICHT den echten Spot: den waehlt man bewusst
    # (Beta-Entscheidung 22.09.2026). Der Uebungsraum 3D liegt jedem Release bei.
    default_backend: str = "mujoco"
    workspace: str = ""  # Arbeitsordner der GUI; leer = noch nicht gewählt
    active_map: str = ""  # in der GUI gewählte Karte; leer = keine
    raum: str = ""        # Übungsraum für den Sim; leer = keiner
    # Startpose als "x,y,grad". Ein String statt dreier Felder oder einer Liste:
    # der TOML-Schreiber hier ist bewusst minimal, und "1.5,2.0,90" ist in der
    # Datei genauso lesbar wie drei einzelne Zeilen.
    raum_start: str = ""


def startpose_aus(text):
    """(x, y, grad) aus "1.5,2.0,90" — oder None.

    Wirft nie: die Datei ist von Hand änderbar, und eine verdorbene Zeile darf
    die GUI nicht am Starten hindern. Ohne Startpose gilt die des Raums.
    """
    teile = str(text or "").split(",")
    if len(teile) != 3:
        return None
    try:
        return tuple(float(t) for t in teile)
    except ValueError:
        return None


def _toml_string(wert):
    """Minimaler TOML-Basic-String — vermeidet eine Schreibabhängigkeit."""
    gesichert = str(wert).replace("\\", "\\\\").replace('"', '\\"')
    return f'"{gesichert}"'


def save_config(cfg, path=None):
    # Pfad erst zur Aufrufzeit auflösen: als Vorgabewert wäre CONFIG_PATH beim
    # Import gebunden und in Tests nicht mehr umzubiegen.
    path = Path(path) if path else CONFIG_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    text = (
        "# von spotlab geschrieben — das Passwort steht NICHT hier, sondern im Windows-Tresor\n"
        "[robot]\n"
        f"ip = {_toml_string(cfg.ip)}\n"
        f"username = {_toml_string(cfg.username)}\n"
        f"nickname = {_toml_string(cfg.nickname)}\n"
        "\n[limits]\n"
        f"max_speed = {float(cfg.limits.max_speed)}\n"
        f"max_turn_rate = {float(cfg.limits.max_turn_rate)}\n"
        f"treppen = {_toml_string(cfg.limits.treppen)}\n"
        "\n[editor]\n"
        f"command = {_toml_string(cfg.editor_command)}\n"
        "\n[defaults]\n"
        f"backend = {_toml_string(cfg.default_backend)}\n"
        "\n[gui]\n"
        f"workspace = {_toml_string(cfg.workspace)}\n"
        "\n[maps]\n"
        f"active = {_toml_string(cfg.active_map)}\n"
        "\n[uebungsraum]\n"
        f"raum = {_toml_string(cfg.raum)}\n"
        f"start = {_toml_string(cfg.raum_start)}\n"
    )
    path.write_text(text, encoding="utf-8")


def _grenze(roh, schluessel, vorgabe, pfad):
    """Ein Sicherheitswert. Muss endlich und echt positiv sein.

    Warum so streng: `max_speed = inf` macht den Deckel wirkungslos, und ein
    NEGATIVER Wert ist schlimmer als gar keiner — `motion.clamp()` rechnet dann
    `max(0.8, min(-0.8, wz))` und liefert für ein kommandiertes wz = 0 eine
    Dauerdrehung. Ein Tippfehler in dieser Datei darf den Roboter nicht bewegen.
    """
    wert = roh.get(schluessel, vorgabe)
    try:
        zahl = float(wert)
    except (TypeError, ValueError):
        raise ConfigBroken(
            f"In {pfad} ist `{schluessel} = {wert!r}` keine Zahl. Korrigieren oder "
            f"die Zeile löschen — dann gilt die Vorgabe {vorgabe}."
        ) from None
    if not math.isfinite(zahl) or zahl <= 0.0:
        raise ConfigBroken(
            f"In {pfad} ist `{schluessel} = {wert}` unbrauchbar. Der Wert ist eine "
            f"Sicherheitsgrenze und muss eine endliche Zahl über 0 sein "
            f"(Vorgabe: {vorgabe})."
        )
    return zahl


def _treppenmodus(limits, pfad):
    wert = limits.get("treppen", Limits.treppen)
    if wert not in TREPPENMODI:
        raise ConfigBroken(
            f"In {pfad} ist `treppen = {wert!r}` unbekannt. Erlaubt: "
            + " oder ".join(TREPPENMODI) + "."
        )
    return wert


def _roh_lesen(path):
    if not path.exists():
        raise ConfigMissing(
            f"Keine Konfiguration unter {path}. Einmalig einrichten mit `spotlab login`."
        )
    try:
        with path.open("rb") as datei:
            return tomllib.load(datei)
    except (tomllib.TOMLDecodeError, UnicodeDecodeError, OSError) as fehler:
        # Ohne diesen Fang sperrt eine halb geschriebene Datei die GUI, das CLI
        # und den Reparaturweg `spotlab login` gleichzeitig — mit rohem Traceback.
        raise ConfigBroken(
            f"{path} ist nicht lesbar ({fehler.__class__.__name__}). Datei "
            f"korrigieren oder löschen und neu einrichten mit `spotlab login`."
        ) from fehler


def load_config(path=None):
    path = Path(path) if path else CONFIG_PATH
    roh = _roh_lesen(path)
    robot = roh.get("robot", {})
    if "ip" not in robot or "username" not in robot:
        raise ConfigMissing(
            f"In {path} fehlen IP oder Benutzername. Neu einrichten mit `spotlab login`."
        )
    return _aus_roh(roh, path)


def rette_config(path=None):
    """Für `spotlab login` nach einem Tippfehler: was gültig ist, bleibt.

    Eine Konfiguration wird ERGÄNZT, nie neu gebaut (CLAUDE.md) -- auch dann
    nicht, wenn EIN Eintrag kaputt ist. Bis zum 23.09.2026 baute login nach
    jedem ConfigBroken alles neu: ein `backend = "Mujoco"` kostete die
    Treppensperre, das Tempo, den Arbeitsordner, die Karte und den Raum.

    Rückgabe `(Config, [ersetzte Einträge als Text])`. Ersetzt wird nur, was
    kein Sicherheitswert ist: ein unbekanntes Backend bekommt die Vorgabe (die
    fährt nie den Roboter), fehlende IP und Benutzername bleiben leer -- login
    fragt beides ohnehin. Ist ein SICHERHEITSWERT kaputt (`max_speed`,
    `max_turn_rate`, `treppen`) oder die Datei gar nicht lesbar, wirft sie
    ConfigBroken: ihn still auf die Vorgabe zu setzen, hiesse eine Sperre
    aufzuheben, die jemand bewusst gesetzt hat. ConfigMissing ohne Datei.
    """
    path = Path(path) if path else CONFIG_PATH
    roh = _roh_lesen(path)
    ersetzt = []
    defaults = roh.get("defaults", {})
    backend = defaults.get("backend", Config.default_backend)
    if backend not in BACKENDS:
        ersetzt.append(f"backend = {backend!r}, jetzt {Config.default_backend!r} (Vorgabe)")
        roh = {**roh, "defaults": {**defaults, "backend": Config.default_backend}}
    robot = roh.get("robot", {})
    roh = {**roh, "robot": {"ip": "", "username": "", **robot}}
    return _aus_roh(roh, path), ersetzt


def _aus_roh(roh, path):
    robot = roh["robot"]
    limits = roh.get("limits", {})
    # Ohne Eintrag die Vorgabe von `Config`, nie "real": wer nichts einstellt,
    # faehrt NICHT den echten Spot -- auch nicht mit einer Datei, in der die
    # Zeile fehlt (von Hand angelegt oder aus einer Fassung vor dem 22.09.2026).
    backend = roh.get("defaults", {}).get("backend", Config.default_backend)
    if backend not in BACKENDS:
        raise ConfigBroken(
            f"In {path} ist `backend = {backend!r}` unbekannt. Erlaubt: "
            + ", ".join(sorted(BACKENDS))
            + ". Die Zeile korrigieren -- oder `spotlab login`, das setzt die "
            f"Vorgabe {Config.default_backend!r} und behält alles andere."
        )
    return Config(
        ip=robot["ip"],
        username=robot["username"],
        nickname=robot.get("nickname", "Spot"),
        limits=Limits(
            max_speed=_grenze(limits, "max_speed", Limits.max_speed, path),
            max_turn_rate=_grenze(limits, "max_turn_rate", Limits.max_turn_rate, path),
            treppen=_treppenmodus(limits, path),
        ),
        editor_command=roh.get("editor", {}).get("command", "code"),
        default_backend=backend,
        workspace=roh.get("gui", {}).get("workspace", ""),
        active_map=roh.get("maps", {}).get("active", ""),
        raum=roh.get("uebungsraum", {}).get("raum", ""),
        raum_start=roh.get("uebungsraum", {}).get("start", ""),
    )


def __getattr__(name):
    """`keyring` erst beim ersten Gebrauch laden: 0.4 s beim GUI-Start, für ein
    Passwort, das erst beim Verbinden gebraucht wird. `spotlab.config.keyring`
    bleibt als Name erreichbar (die Tests ersetzen darüber `get_password`)."""
    if name == "keyring":
        import keyring

        return keyring
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def save_password(username, password):
    import keyring

    keyring.set_password(KEYRING_SERVICE, username, password)


def load_password(username):
    import keyring

    gespeichert = keyring.get_password(KEYRING_SERVICE, username)
    if gespeichert:
        return gespeichert
    aus_umgebung = os.environ.get(ENV_PASSWORD)
    if aus_umgebung:
        return aus_umgebung
    raise ConfigMissing(
        f"Für '{username}' ist kein Passwort hinterlegt. Einmalig setzen mit `spotlab login`."
    )
