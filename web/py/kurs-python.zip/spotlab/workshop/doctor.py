"""`spotlab doctor` — beantwortet „warum geht es nicht" in der Reihenfolge,
in der die Dinge tatsächlich schiefgehen.

Die Kette bricht nach dem ersten Fehlschlag ab: ohne Netz keine Anmeldung, ohne
Anmeldung kein Lease. Weiterzuprüfen erzeugte nur Folgefehler, die vom
eigentlichen Problem ablenken.
"""

import time
from dataclasses import dataclass
from datetime import UTC, datetime

from spotlab.errors import ConfigMissing, translate


@dataclass(frozen=True)
class Check:
    name: str
    ok: bool
    detail: str
    rat: str = ""


STUFEN = (
    "Konfiguration", "Netz", "Anmeldung", "Zeitsync", "Zustandsstrom",
    "Not-Aus", "Not-Aus-Endpunkt", "Lease", "Akku",
    "Lizenz", "Nutzlasten", "Dienste", "Zertifikat",
)

STROM_DIENST = "robot-state-streaming"
# Ab hier wird vor dem Ablauf des Zertifikats gewarnt, statt ihn nur zu melden.
WARNFRIST_TAGE = 30


# Ab diesem Versatz bekommt die Zeile einen Rat: darunter merkt niemand etwas,
# darüber liegen Fehlerzeiten aus dem RobotState sichtbar neben den Läufen.
VERSATZ_WARNUNG_S = 60.0


def _uhrenversatz(time_sync):
    """Die Zeile „Zeitsync" nach gelungenem `wait_for_sync()`: wie weit geht die
    Roboteruhr vor oder nach?

    Am 16.09.2026 ging sie 15 Minuten vor, und „Uhren laufen synchron" stand
    grün darüber — wahr für das SDK, das umrechnet, aber jede Fehlerzeit aus dem
    RobotState (Fehlerhistorie, `t_robot` in der Aufzeichnung) lag damit eine
    Viertelstunde neben den Läufen. Kein Defekt, also ok=True; der Betrag steht
    in der Zeile, damit man ihn beim Abgleich abziehen kann.
    """
    try:
        dauer = time_sync.get_robot_clock_skew()
        versatz = dauer.seconds + dauer.nanos * 1e-9
    except Exception as fehler:
        return Check(
            "Zeitsync", True,
            f"synchronisiert, Versatz nicht ermittelbar ({type(fehler).__name__})",
        )
    richtung = "vor" if versatz >= 0 else "nach"
    detail = f"synchronisiert — Roboteruhr geht {abs(versatz):.1f} s {richtung}"
    if abs(versatz) < VERSATZ_WARNUNG_S:
        return Check("Zeitsync", True, detail)
    return Check(
        "Zeitsync", True, detail,
        "Kommandos gehen, das SDK rechnet um. Aber Zeitstempel aus dem RobotState "
        "(Fehlerhistorie, `t_robot` in zustand.jsonl) sind Roboterzeit: beim "
        f"Abgleich mit Läufen {versatz:+.0f} s abziehen. Ursache ist meist ein "
        "Netz ohne Zeitserver für den Roboter.",
    )


def _zustandsstrom(robot):
    """Gibt es den 333-Hz-Zustandsstrom auf diesem Roboter?

    Die Zeile BENUTZT ihn nicht. Sie beantwortet nur, ob die lizenzpflichtige
    Joint-Control-API auf diesem Gerät freigeschaltet ist — dort, wo man ohnehin
    hinschaut, bevor man misst. Beide Antworten sind ok=True: ein fehlender
    Strom ist kein Defekt, und ein rotes Kreuz wäre eine Falschaussage.
    """
    try:
        namen = {getattr(d, "name", "") for d in robot.list_services()}
    except Exception as fehler:
        return Check(
            "Zustandsstrom", True, f"nicht ermittelbar ({type(fehler).__name__})",
            "Ohne die Angabe bleibt es bei RobotState mit rund 10-50 Hz.",
        )
    if STROM_DIENST in namen:
        return Check(
            "Zustandsstrom", True, "verfügbar (333 Hz mit rohem IMU)",
            "spotlab nutzt ihn noch nicht — die Messfenster laufen über RobotState.",
        )
    return Check(
        "Zustandsstrom", True, "nicht vorhanden",
        "Der 333-Hz-Strom braucht die Joint-Control-Lizenz. Ohne ihn liefert "
        "RobotState alles ausser rohem IMU — für die Gates reicht das.",
    )


def _eigener_endpunkt(estop_client):
    """Steht noch ein spotlab-Endpunkt in der Not-Aus-Konfiguration?

    Automatisiert Abnahmepunkt A3. Bisher fragte diese Diagnose nur den
    aggregierten Systemstatus ab — ein zurückgelassener Endpunkt wäre dort
    unsichtbar geblieben, obwohl der Roboter ihn beim nächsten Timeout als
    ausgelöst wertet und der nächste Schüler einen scheinbar defekten Spot
    vorfindet.

    Zwei Fälle, die NICHT dasselbe sind: eine Leiche aus einem abgestürzten Lauf
    (heilt sich beim nächsten Verbinden selbst) und ein zweiter, laufender
    spotlab-Prozess (da muss ein Mensch etwas tun).
    """
    from spotlab.backends.real.estop import (
        ENDPOINT_NAME,
        ESTOP_TIMEOUT_S,
        sekunden_seit_antwort,
    )

    namen = [e.name for e in estop_client.get_config().endpoints]
    if ENDPOINT_NAME not in namen:
        return Check(
            "Not-Aus-Endpunkt", True,
            f"kein '{ENDPOINT_NAME}'-Endpunkt in der Konfiguration",
        )
    seit = sekunden_seit_antwort(estop_client, ENDPOINT_NAME)
    if seit is not None and seit <= ESTOP_TIMEOUT_S:
        return Check(
            "Not-Aus-Endpunkt", False,
            f"ein anderer spotlab-Lauf hält ihn (Rückmeldung vor {seit:.1f} s)",
            "Beende den anderen Lauf, bevor du verbindest.",
        )
    return Check(
        "Not-Aus-Endpunkt", False,
        f"ein '{ENDPOINT_NAME}'-Endpunkt ist zurückgeblieben und meldet sich nicht",
        "Rest eines hart beendeten Laufs. Der nächste Verbindungsaufbau ersetzt "
        "ihn automatisch — nach einem geordneten Ende sollte er aber weg sein "
        "(Abnahmepunkt A3).",
    )


def diagnose(cfg=None, robot_bauen=None, passwort_lesen=None,
             zertifikat_holen=None):
    """`zertifikat_holen` ist injizierbar wie `robot_bauen`: die Zeile macht
    sonst einen echten TCP-Versuch und wartet dessen Frist ab — in einem Test
    gegen eine Attrappen-IP sind das drei geschenkte Sekunden je Lauf."""
    from spotlab.backends.real.estop import LEVEL_NAMEN
    from spotlab.backends.real.lease import holder_of
    from spotlab.backends.real.verbindung import standard_robot
    from spotlab.config import load_config, load_password

    robot_bauen = robot_bauen or standard_robot
    passwort_lesen = passwort_lesen or load_password
    pruefungen = []

    if cfg is None:
        try:
            cfg = load_config()
        except ConfigMissing as fehler:
            return [
                Check(
                    "Konfiguration", False, str(fehler),
                    "Einmalig einrichten mit `spotlab login`.",
                )
            ]
    pruefungen.append(
        Check("Konfiguration", True, f"{cfg.nickname} unter {cfg.ip} als '{cfg.username}'")
    )

    try:
        robot = robot_bauen(cfg)
        # `create_robot()` macht KEINEN RPC — es baut nur ein Objekt. Ohne den
        # folgenden Aufruf stand „Netz: OK" grün über einem Spot, der gar nicht
        # antwortet, und der Fehler fiel erst eine Stufe später bei „Anmeldung"
        # auf. `get_id()` braucht keine Anmeldung und ist damit die billigste
        # Frage, die wirklich übers Netz geht.
        robot.get_id()
    except Exception as fehler:
        return pruefungen + [_fehler("Netz", fehler, cfg.ip)]
    pruefungen.append(Check("Netz", True, f"{cfg.ip} antwortet"))

    try:
        robot.authenticate(cfg.username, passwort_lesen(cfg.username))
    except Exception as fehler:
        return pruefungen + [_fehler("Anmeldung", fehler, cfg.ip)]
    pruefungen.append(Check("Anmeldung", True, f"als '{cfg.username}' angemeldet"))

    try:
        robot.time_sync.wait_for_sync()
    except Exception as fehler:
        return pruefungen + [
            Check("Zeitsync", False, str(fehler),
                  "Windows-Uhrzeit automatisch stellen lassen.")
        ]
    pruefungen.append(_uhrenversatz(robot.time_sync))
    pruefungen.append(_zustandsstrom(robot))

    try:
        from bosdyn.client.estop import EstopClient

        estop_client = robot.ensure_client(EstopClient.default_service_name)
        status = estop_client.get_status()
        stufe = LEVEL_NAMEN.get(status.stop_level, "unbekannt")
        frei = stufe == "frei"
        pruefungen.append(
            Check("Not-Aus", frei, stufe, "" if frei else "Am Tablet oder Knopf freigeben.")
        )
        if not frei:
            return pruefungen
    except Exception as fehler:
        return pruefungen + [_fehler("Not-Aus", fehler, cfg.ip)]

    try:
        pruefungen.append(_eigener_endpunkt(estop_client))
    except Exception as fehler:
        pruefungen.append(_fehler("Not-Aus-Endpunkt", fehler, cfg.ip))

    try:
        from bosdyn.client.lease import LeaseClient

        halter = holder_of(robot.ensure_client(LeaseClient.default_service_name))
        if halter and not halter.startswith("spotlab/"):
            pruefungen.append(
                Check("Lease", False, f"gehalten von {halter}",
                      "Absprechen, dann `spotlab lease --take`.")
            )
        elif halter:
            pruefungen.append(
                Check("Lease", False, f"gehalten von {halter}",
                      "Läuft dort noch ein Skript? Sonst `spotlab lease --take`.")
            )
        else:
            pruefungen.append(Check("Lease", True, "frei"))
    except Exception as fehler:
        return pruefungen + [_fehler("Lease", fehler, cfg.ip)]

    try:
        from bosdyn.client.robot_state import RobotStateClient

        zustand = robot.ensure_client(RobotStateClient.default_service_name).get_robot_state()
        if not zustand.battery_states:
            # Kein Akku gemeldet ist NICHT „0 %“: ein erfundener Messwert samt Rat
            # zur Ladestation schickte auf die falsche Faehrte (Pruefung 23.09.2026).
            pruefungen.append(
                Check("Akku", False, "keine Akkumeldung",
                      "Der Roboter meldet keinen Akku. Sitzt er richtig? Neu verbinden; "
                      "hält es an, den Roboter neu starten.")
            )
        else:
            prozent = zustand.battery_states[0].charge_percentage.value
            genug = prozent >= 20.0
            pruefungen.append(
                Check("Akku", genug, f"{prozent:.0f} %",
                      "" if genug else "Auf die Ladestation stellen.")
            )
    except Exception as fehler:
        pruefungen.append(_fehler("Akku", fehler, cfg.ip))

    # Geräte-Auskunft: was kann dieser Roboter überhaupt? Jede Zeile in eigenem
    # try — ein fehlender Dienst darf die übrigen Antworten nicht mitreissen.
    try:
        from bosdyn.client.license import LicenseClient

        pruefungen.append(
            _lizenz(robot.ensure_client(LicenseClient.default_service_name))
        )
    except Exception as fehler:
        pruefungen.append(
            Check("Lizenz", True, f"nicht ermittelbar ({type(fehler).__name__})", "")
        )

    try:
        from bosdyn.client.payload import PayloadClient

        pruefungen.append(
            _nutzlasten(robot.ensure_client(PayloadClient.default_service_name))
        )
    except Exception as fehler:
        pruefungen.append(
            Check("Nutzlasten", True, f"nicht ermittelbar ({type(fehler).__name__})", "")
        )

    pruefungen.append(_dienste(robot))
    pruefungen.append(_zertifikat(cfg.ip, holen=zertifikat_holen))

    return pruefungen


_LIZENZSTATUS = {
    "STATUS_EXPIRED": "abgelaufen",
    "STATUS_NOT_YET_VALID": "noch nicht gültig",
    "STATUS_MALFORMED": "beschädigt",
    "STATUS_SERIAL_MISMATCH": "gehört zu einem anderen Roboter",
    "STATUS_NO_LICENSE": "keine Lizenz eingespielt",
}


def _lizenz(license_client, jetzt=None):
    """Was ist auf diesem Roboter freigeschaltet — autoritativ, nicht geraten.

    Loest die Heuristik in `_zustandsstrom` nicht ab, sondern ergaenzt sie:
    „lizenziert, aber Dienst laeuft nicht" ist ein anderes Problem als „nicht
    lizenziert", und nur wer beides fragt, kann sie unterscheiden.

    Das Urteil gibt der ROBOTER (`status`), nicht das Datum: am Schul-Spot stand am
    11.11.2026 `STATUS_VALID` bei einem `not_valid_after` vom 05.02.2026. Beides wird
    gesagt; ein vergangenes Datum allein ist kein Fehler.
    """
    jetzt = time.time() if jetzt is None else jetzt
    try:
        info = license_client.get_license_info()
    except Exception as fehler:
        return Check(
            "Lizenz", True, f"nicht ermittelbar ({type(fehler).__name__})",
            "Ohne die Angabe bleibt es bei der Auskunft aus der Dienstliste.",
        )
    features = list(getattr(info, "licensed_features", []) or [])
    bis = getattr(info, "not_valid_after", "") or ""
    vorbei = False
    if hasattr(bis, "ToJsonString"):
        # Ein protobuf-Timestamp, kein Text: `str()` ergab „seconds: 1…“. Leer heisst 1970,
        # also gar kein Datum — das wird nicht als Ablauf behauptet.
        if bis.seconds or bis.nanos:
            vorbei = bis.seconds < jetzt
            bis = bis.ToJsonString()
        else:
            bis = ""
    bis = str(bis)
    detail = ", ".join(features) if features else "keine Features gemeldet"
    status = _status_name(info)
    if status in _LIZENZSTATUS:
        return Check(
            "Lizenz", False, f"{detail} — laut Spot {_LIZENZSTATUS[status]}",
            "Am Tablet unter Lizenz nachsehen und mit der Person klären, die den Spot "
            "an der Schule betreut.",
        )
    if status == "STATUS_VALID":
        detail += " — gültig laut Spot"
        if bis:
            detail += f", Datum in der Lizenz {bis[:10]}" + (" (vorbei)" if vorbei else "")
    elif bis:
        detail += f" — gültig bis {bis[:10]}"
    return Check(
        "Lizenz", True, detail,
        "Auch die Lizenz hat ein Ablaufdatum. Vor einem Messtag hinschauen.",
    )


def _status_name(info):
    """`STATUS_VALID` usw. aus dem echten Protobuf, sonst None (Attrappe ohne Status)."""
    status = getattr(info, "status", None)
    aufzaehlung = getattr(type(info), "Status", None)
    if status is None or aufzaehlung is None:
        return None
    try:
        return aufzaehlung.Name(status)
    except ValueError:
        return None


def _nutzlasten(payload_client):
    """Beantwortet „GPS? Lidar?" — statt es zu vermuten."""
    try:
        nutzlasten = list(payload_client.list_payloads())
    except Exception as fehler:
        return Check("Nutzlasten", True, f"nicht ermittelbar ({type(fehler).__name__})", "")
    if not nutzlasten:
        return Check(
            "Nutzlasten", True, "keine verbaut",
            "Ohne Nutzlast gibt es an diesem Roboter kein GPS und kein Lidar.",
        )
    namen = ", ".join(
        str(getattr(p, "name", "?"))
        + ("" if getattr(p, "is_authorized", True) else " (nicht freigegeben)")
        for p in nutzlasten
    )
    return Check("Nutzlasten", True, namen, "")


def _dienste(robot):
    try:
        namen = sorted({getattr(d, "name", "") for d in robot.list_services()})
    except Exception as fehler:
        return Check("Dienste", True, f"nicht ermittelbar ({type(fehler).__name__})", "")
    return Check("Dienste", True, f"{len(namen)} Dienste", ", ".join(namen))


def _zertifikat(ip, jetzt=None, holen=None):
    """Läuft das Roboter-Zertifikat bald ab? Die Lehre aus dem 02.09.2026.

    Der Rat nennt, was damals geholfen hat, und behauptet KEINE Ursache — die
    ist bis heute unbekannt.
    """
    from spotlab.workshop.zertifikat import fenster_von

    jetzt = jetzt or datetime.now(UTC)
    holen = holen or fenster_von
    try:
        _vor, nach = holen(ip)
    except Exception as fehler:
        return Check(
            "Zertifikat", True, f"nicht ermittelbar ({type(fehler).__name__})",
            "Nur im WLAN des Spot prüfbar.",
        )
    tage = (nach - jetzt).days
    datum = nach.strftime("%Y-%m-%d")
    if tage < 0:
        return Check(
            "Zertifikat", False, f"abgelaufen am {datum} (seit {-tage} Tagen)",
            "Den Roboter neu starten — das hat am 02.09.2026 geholfen. "
            "Die Laptop-Uhr NICHT zurückstellen: das behebt nichts und "
            "verfälscht die Zeitstempel aller Läufe.",
        )
    if tage <= WARNFRIST_TAGE:
        return Check(
            "Zertifikat", True, f"gültig bis {datum} — noch {tage} Tage",
            "Vor dem nächsten Messtag einen Neustart einplanen.",
        )
    return Check("Zertifikat", True, f"gültig bis {datum}", "")


def _fehler(name, fehler, ip):
    uebersetzt = translate(fehler, ip=ip)
    if uebersetzt is not None:
        return Check(name, False, type(fehler).__name__, str(uebersetzt))
    return Check(name, False, f"{type(fehler).__name__}: {fehler}", "")
