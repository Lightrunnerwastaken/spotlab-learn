"""Projektvorlagen."""
