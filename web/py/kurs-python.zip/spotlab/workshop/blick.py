"""Der Blick des Roboters: `ansicht.jpg` aus den beiden Frontkameras — wie auf dem Tablet.

Wer den Spot mit W A S D Q E fährt, will sehen, wohin. Im Übungsraum rendert
das MuJoCo-Backend dafür das Zimmer von aussen (`backends/mujoco.py`,
Ansichtsthread); am ECHTEN Roboter gibt es kein Zimmer -- dort ist der Blick
das, was die Frontkameras sehen: zu EINEM Rechteck zusammengesetzt
(`backends/real/panorama.py`), in Farbe, wo die Kamera Farbe kann, und so
schnell, wie der Roboter Bilder liefert.

Beides landet unter demselben Namen im Lauf-Verzeichnis: `ansicht.jpg` ist
**die Ansicht dieses Laufs**, geschrieben von dem, der sie hat. Zwei Schreiber
gleichzeitig gibt es nie: `starte()` legt einen Blick nur an, wenn das Backend
es ERLAUBT (`blick_aus_kameras`, gesetzt am echten Roboter) -- eine
Erlaubnisliste, keine Sperrliste, denn ein Sim, der Kameras vortäuscht und die
Ansicht selbst rendert, hätte sonst zwei Schreiber auf einer Datei. Für die GUI
ändert sich nichts: sie liest wie bisher eine Datei von der Platte.

BILDRATE. Ein Bildabruf über WLAN dauert länger als ein Fahrtakt und ist
reine Wartezeit; Zusammensetzen und Schreiben dauern rund 15 ms und sind
Rechenzeit. Deshalb zwei Threads: einer holt in Schleife und legt die neueste
Antwort ab, der andere setzt zusammen und schreibt -- und kommt er nicht nach,
fällt das ältere Bild weg, nie das neueste. Die Obergrenze ist `TAKT_S`; die
wirkliche Rate bestimmen Kamera und WLAN. Dasselbe Bild (gleiche
Aufnahmezeit) wird nie zweimal geschrieben.

RÜCKFALL. Ohne Intrinsik oder Rahmenbaum gibt es kein Panorama; dann kommen
die Bilder aufrecht gedreht nebeneinander (−102° und −78°, die Winkel des
SDK-Beispiels `image_viewer.py`, `frontright` LINKS neben `frontleft` -- die
Kameras schauen über Kreuz). Ein Fehler beendet den Blick, nie den Lauf: ohne
Bild fährt man weiter (der Mensch steht daneben), ohne Fahrbefehle nicht.

NICHT über `spot.camera()`: jenes schreibt über den `RunRecorder` mit, und
`bilder.json` wird dabei bei jedem Bild vollständig neu geschrieben -- bei
zwanzig Bildern je Sekunde wäre das quadratisch. Der Blick ist ein Strom,
keine Aufnahme; er ersetzt eine Datei und legt kein Ereignis an.
"""

import io
import threading
import time
from pathlib import Path

from spotlab.errors import SpotlabError

DATEI = "ansicht.jpg"
TAKT_S = 1.0 / 30           # Obergrenze der Abrufe: schneller fragt niemand
GUETE_ANFRAGE = 60          # JPEG vom Roboter, übers WLAN: klein
GUETE = 80                  # JPEG auf der Platte: das Bild, das man sieht
FEHLER_BIS_AUFGABE = 3      # Fehler NACHEINANDER; ein Erfolg setzt zurück

# Anzeigereihenfolge: rechts LINKS im Bild -- die Kameras schauen über Kreuz.
KAMERAS = ("frontright_fisheye_image", "frontleft_fisheye_image")
# Drehung für den Rückfall ohne Kalibrierung (Grad, gegen den Uhrzeigersinn).
DREHUNG = {"frontright_fisheye_image": -102.0, "frontleft_fisheye_image": -78.0}


def jpeg_bytes(feld, guete=GUETE):
    """Ein uint8-Feld (HxW oder HxWx3) als JPEG-Bytes."""
    from PIL import Image as PILImage

    puffer = io.BytesIO()
    PILImage.fromarray(feld).save(puffer, format="JPEG", quality=guete)
    return puffer.getvalue()


def feld_aus(antworten, drehungen=None):
    """Rückfall: die Kamerabilder aufrecht gedreht und nebeneinander, als Feld."""
    import numpy as np
    from PIL import Image as PILImage

    from spotlab.api.perception import Image

    winkel = DREHUNG if drehungen is None else dict(drehungen)
    teile = []
    for antwort in antworten:
        bild = Image(antwort)
        feld = PILImage.fromarray(bild.array)
        teile.append(feld.rotate(winkel.get(bild.source, 0.0), expand=True))
    if not teile:
        raise ValueError("Kein Bild -- ohne Kamera gibt es keinen Blick.")
    modus = "RGB" if any(t.mode == "RGB" for t in teile) else "L"
    hoehe = max(t.height for t in teile)
    zusammen = PILImage.new(modus, (sum(t.width for t in teile), hoehe))
    x = 0
    for teil in teile:
        zusammen.paste(teil.convert(modus), (x, 0))
        x += teil.width
    return np.asarray(zusammen)


def bild_aus(antworten, drehungen=None, guete=GUETE):
    """Rückfall: die Kamerabilder aufrecht gedreht und nebeneinander, als JPEG-Bytes."""
    return jpeg_bytes(feld_aus(antworten, drehungen), guete)


# Grün wie am Tablet, und dick genug, dass die Linie ein JPEG überlebt.
KASTEN_FARBE = (0, 255, 0)
HAND_FARBE = (255, 220, 0)       # gelb: vom Gesichtskasten unterscheidbar
KASTEN_DICKE = 3
MELDUNG_FARBE = (255, 40, 40)
MELDUNG_BREITE = 72              # Zeichen je Zeile, bevor umgebrochen wird
MELDUNG_ZEILEN = 4               # mehr verdeckt den Blick, den man beim Fahren braucht
# Der Standardzeichensatz von PIL ist 11 px hoch; auf einem Panorama von rund
# tausend Bildpunkten Breite liest das niemand.
SCHRIFT_KASTEN = 16
SCHRIFT_MELDUNG = 18


def _meldungszeilen(meldung, breite=MELDUNG_BREITE, hoechstens=MELDUNG_ZEILEN):
    """Die Meldung umgebrochen — und sichtbar gekürzt, wenn sie nicht hineinpasst.

    Ein Text, der mitten im Wort aufhört, sieht aus wie ein Fehler statt wie
    eine Kürzung. Der ganze Satz steht ohnehin in `diagnose.log`.
    """
    import textwrap

    zeilen = textwrap.wrap(meldung, breite)
    if len(zeilen) <= hoechstens:
        return zeilen
    gekuerzt = zeilen[:hoechstens]
    gekuerzt[-1] += " …"
    return gekuerzt


def _schrift(groesse):
    """Der Standardzeichensatz in lesbarer Grösse — notfalls in seiner alten.

    `load_default(size=)` gibt es erst ab Pillow 10.1, das Projekt erlaubt ab
    10.0. Eine fehlende Schriftgrösse darf den Blick nicht anhalten.
    """
    from PIL import ImageFont

    try:
        return ImageFont.load_default(size=groesse)
    except TypeError:
        return ImageFont.load_default()


def zeichne_jpeg(feld, kaesten=(), meldung="", guete=GUETE, haende=()):
    """Das Feld mit Kästen und einer etwaigen Meldung, als JPEG-Bytes.

    `kaesten` sind Gesichter `(x, y, breite, hoehe, score)` in Grün, `haende`
    Handkästen `(x, y, breite, hoehe, text)` in Gelb — der Text ist das Zeichen
    („Halt", „Weiter" oder nur „Hand") samt Sicherheit.

    Gezeichnet wird mit PIL und NICHT mit cv2: die häufigste Meldung, die hier
    landet, ist „für die Gesichtssuche fehlt OpenCV" — sie mit OpenCV zu malen
    wäre der eine Fall, in dem sie niemand zu sehen bekäme.

    Das Bild wird dafür nach RGB gewandelt. Ein graues Panorama mit grünen
    Kästen geht nicht anders, und es passiert nur, wenn ein Schalter an ist:
    ohne ihn bleibt `ansicht.jpg` genau das Bild, das es immer war.
    """
    from PIL import Image as PILImage
    from PIL import ImageDraw

    bild = PILImage.fromarray(feld).convert("RGB")
    maler = ImageDraw.Draw(bild)
    if len(kaesten) or len(haende):
        schrift = _schrift(SCHRIFT_KASTEN)
        beschriftet = [(x, y, b, h, f"{score:.2f}", KASTEN_FARBE) for x, y, b, h, score in kaesten]
        beschriftet += [(x, y, b, h, str(text), HAND_FARBE) for x, y, b, h, text in haende]
        for x, y, breite, hoehe, text, farbe in beschriftet:
            maler.rectangle([x, y, x + breite, y + hoehe], outline=farbe, width=KASTEN_DICKE)
            # Über den Kasten, solange oben Platz ist — sonst hinein, denn ein
            # Gesicht am oberen Bildrand ist hier der Normalfall.
            oben = y - SCHRIFT_KASTEN - 2
            maler.text((x, oben if oben >= 0 else y + 2), text, fill=farbe, font=schrift)
    if meldung:
        schrift = _schrift(SCHRIFT_MELDUNG)
        for nummer, zeile in enumerate(_meldungszeilen(meldung)):
            maler.text((8, 8 + nummer * (SCHRIFT_MELDUNG + 4)), zeile,
                       fill=MELDUNG_FARBE, font=schrift)
    puffer = io.BytesIO()
    bild.save(puffer, format="JPEG", quality=guete)
    return puffer.getvalue()


class Blick(threading.Thread):
    """Holt Bilder in Schleife, setzt sie zusammen und ersetzt `ansicht.jpg`.

    Zwei Threads (siehe oben): dieser setzt zusammen und schreibt, ein innerer
    holt. Zähler: `abrufe` (Antworten vom Roboter), `bilder` (geschriebene
    Dateien), `fehler` (Fehler nacheinander), `letzter_fehler`.
    """

    def __init__(self, spot, lauf_dir, takt_s=TAKT_S, kameras=KAMERAS,
                 schlaf=time.sleep, jetzt=time.monotonic, gesichter_holen=None,
                 haende_holen=None):
        super().__init__(name="spotlab-blick", daemon=True)
        self._spot = spot
        self._lauf_dir = Path(lauf_dir)
        self._ziel = self._lauf_dir / DATEI
        self._takt_s = takt_s
        self._quellen = list(kameras)
        self._schlaf, self._jetzt = schlaf, jetzt
        self._halt = threading.Event()
        self._neu = threading.Condition()
        self._antworten = None
        self._panorama = None
        self._rueckfall = False
        self._letzte_aufnahme = None
        self.abrufe = 0
        self.bilder = 0
        self.fehler = 0
        self.letzter_fehler = ""
        self.aufgegeben = False
        # Gesichter: die Testnaht, der Erkenner (einer je Lauf) und die Zähler.
        self._gesichter_holen = gesichter_holen or self._vom_erkenner
        self._erkenner = None
        self._gesicht_meldung = ""
        self.gesichter = 0
        self.gesicht_fehler = 0
        self.letzter_gesichtsfehler = ""
        # Hände: dieselbe Kette wie im Folgemodus (Körper → Rumpf → Hand), eigene
        # Naht, eigene Meldung und eigene Zähler -- ein fehlendes Handmodell darf
        # den Gesichtsweg nicht mitreissen, und umgekehrt.
        self._haende_holen = haende_holen or self._vom_handerkenner
        self._koerpererkenner = None
        self._handerkenner = None
        self._hand_meldung = ""
        self.haende = 0
        self.hand_fehler = 0
        self.letzter_handfehler = ""

    # -------------------------------------------------------------- Schritte

    def holen(self):
        """Die Antworten des Roboters für die beiden Frontkameras."""
        return self._spot.backend.images(self._quellen, farbe=True, guete=GUETE_ANFRAGE)

    def schreiben(self, antworten):
        """`ansicht.jpg` aus den Antworten ersetzen. False, wenn es dasselbe Bild war."""
        from spotlab.backends.real import panorama
        from spotlab.record import atomar

        aufnahme = tuple(panorama.aufnahmezeit(a) for a in antworten)
        if aufnahme == self._letzte_aufnahme:
            return False
        atomar.schreibe_atomar(self._ziel, self._bild_bytes(antworten))
        self._letzte_aufnahme = aufnahme
        self.bilder += 1
        return True

    def _bild_bytes(self, antworten):
        feld = self._feld(antworten)
        kaesten, haende, meldung = self._erkennung(feld)
        if kaesten or haende or meldung:
            return zeichne_jpeg(feld, kaesten, meldung, haende=haende)
        return jpeg_bytes(feld)

    def _feld(self, antworten):
        from spotlab.backends.real import panorama

        if not self._rueckfall:
            try:
                if self._panorama is None:
                    self._panorama = panorama.Panorama(panorama.kalibrierung_aus(antworten))
                return self._panorama.zusammensetzen(panorama.bilder_aus(antworten))
            except SpotlabError as fehler:
                from spotlab import protokoll

                self._rueckfall = True
                protokoll.notiere(f"Blick ohne Panorama (gedreht nebeneinander): {fehler}")
        return feld_aus(antworten)

    # ------------------------------------------------------------- Gesichter

    def _erkennung(self, feld):
        """(Gesichtskästen, Handkästen, Meldung) für dieses Bild. Alles leer heisst: unberührt durch.

        Die Schalter kommen aus `ansicht.json`, geschrieben von der Ansicht
        „Fahren" (`record/ansicht.py`). Sie werden bei JEDEM Bild gelesen -- eine
        Datei von dreissig Byte, und dafür wirkt das Umlegen mitten in der Fahrt,
        ohne den Lauf neu zu starten. Jeder Schalter zahlt nur seinen eigenen
        Weg: das Gesicht kostet YuNet, die Hand die Körpersuche.
        """
        from spotlab.record import ansicht

        schalter = ansicht.schalter(self._lauf_dir)
        kaesten, haende, meldungen = [], [], []
        if schalter["gesicht"]:
            kaesten, meldung = self._gesichter(feld)
            if meldung:
                meldungen.append(meldung)
        if schalter["hand"]:
            haende, meldung = self._haende(feld)
            if meldung:
                meldungen.append(meldung)
        return kaesten, haende, " ".join(meldungen)

    def _gesichter(self, feld):
        """(Kästen, Meldung) des Gesichtswegs."""
        if self._gesicht_meldung:
            # Einmal gescheitert (Modell fehlt, OpenCV fehlt) heisst nicht
            # dreissigmal je Sekunde neu scheitern. Die Meldung bleibt stehen.
            return [], self._gesicht_meldung
        try:
            gefunden = list(self._gesichter_holen(feld))
        except SpotlabError as fehler:
            from spotlab import protokoll

            self._gesicht_meldung = str(fehler)
            protokoll.notiere(f"Gesichtserkennung im Blick aus: {fehler}")
            return [], self._gesicht_meldung
        except Exception as fehler:
            # Kein Bildfehler: die Kamera liefert ja. Zählte es als solcher, gäbe
            # der Blick nach drei Takten auf und das Bild wäre weg -- wegen der
            # Beigabe, nicht wegen der Sache.
            self.gesicht_fehler += 1
            self.letzter_gesichtsfehler = f"{type(fehler).__name__}: {fehler}"
            return [], ""
        self.gesichter += len(gefunden)
        return gefunden, ""

    def _vom_erkenner(self, feld):
        """Der Vorgabeweg: YuNet über `gesicht.kaesten` -- mit der Aufhellung,
        die auch Folgemodus und Messprobe fahren. Eine Formulierung, nicht zwei."""
        from spotlab.backends.real import gesicht

        if self._erkenner is None:
            self._erkenner = gesicht.erkenner(feld.shape[1], feld.shape[0])
        return gesicht.kaesten(feld, self._erkenner)

    # ----------------------------------------------------------------- Hände

    def _haende(self, feld):
        """(Handkästen, Meldung) des Handwegs -- dieselben Regeln wie beim Gesicht.

        Ein fehlendes Modell steht einmal in rot im Bild und wird nicht je Bild
        neu versucht; ein stolpernder Erkenner zählt nicht als Bildfehler.
        """
        from spotlab.backends.real import gesten

        if self._hand_meldung:
            return [], self._hand_meldung
        try:
            gefunden = list(self._haende_holen(feld))
        except SpotlabError as fehler:
            from spotlab import protokoll

            self._hand_meldung = str(fehler)
            protokoll.notiere(f"Handerkennung im Blick aus: {fehler}")
            return [], self._hand_meldung
        except Exception as fehler:
            self.hand_fehler += 1
            self.letzter_handfehler = f"{type(fehler).__name__}: {fehler}"
            return [], ""
        self.haende += len(gefunden)
        kaesten = []
        for hand in gefunden:
            x1, y1, x2, y2 = hand.kasten
            kaesten.append((x1, y1, x2 - x1, y2 - y1, gesten.beschriftung(hand)))
        return kaesten, ""

    def _vom_handerkenner(self, feld):
        """Der Vorgabeweg: Körper (mit Spur) → Rumpf-Ausschnitt → Hände, wie `folgen.gesten_leser`.

        Auf dem ganzen Bild fände die Handpose nichts (gemessen am 16.09.2026:
        0 von 510 Panoramen, im Rumpf-Ausschnitt 31). Der Preis ist die
        Körpersuche: ohne Spur 375 ms je Bild, mit Spur rund 60 ms, dazu 65 ms
        für die Hand -- der Blick wird langsamer, nicht falsch. OpenCV fehlt hier
        beim BAU der Zoo-Klassen, nicht beim Import: deshalb die Übersetzung in
        die Meldung, die auch das Gesicht gibt.
        """
        from spotlab.backends.real import gesten, koerper

        if self._koerpererkenner is None:
            try:
                self._koerpererkenner = koerper.Koerpererkenner()
                self._handerkenner = gesten.Handerkenner()
            except ImportError as fehler:
                raise SpotlabError(
                    "Für die Handsuche fehlt OpenCV. Installiere das Extra: "
                    "pip install \"spotlab[gesicht]\" (OpenCV trägt Gesicht, Körper und Hand)."
                ) from fehler
        gefunden = self._koerpererkenner.finde(feld)
        return gesten.haende_beim_koerper(feld, gefunden[0] if gefunden else None,
                                          self._handerkenner)

    def einmal(self):
        """Ein Bild holen und schreiben, in diesem Thread. True, wenn es geklappt hat."""
        try:
            antworten = self.holen()
            self.abrufe += 1
            self.schreiben(antworten)
        except Exception as fehler:
            self._fehler(fehler)
            return False
        self.fehler = 0
        return True

    def _fehler(self, fehler):
        self.fehler += 1
        self.letzter_fehler = f"{type(fehler).__name__}: {fehler}"
        if self.fehler >= FEHLER_BIS_AUFGABE and not self.aufgegeben:
            from spotlab import protokoll

            self.aufgegeben = True
            protokoll.notiere(f"Blick aufgegeben: {self.letzter_fehler}")
            self._halt.set()
            with self._neu:
                self._neu.notify_all()

    # ---------------------------------------------------------------- Threads

    def beenden(self, frist_s=2.0):
        self._halt.set()
        with self._neu:
            self._neu.notify_all()
        if self.is_alive():
            self.join(timeout=frist_s)

    def _holschleife(self):
        while not self._halt.is_set():
            beginn = self._jetzt()
            try:
                antworten = self.holen()
            except Exception as fehler:
                self._fehler(fehler)
                self._schlaf(self._takt_s)
                continue
            self.abrufe += 1
            self.fehler = 0
            with self._neu:
                self._antworten = antworten          # das Neueste ersetzt das Alte
                self._neu.notify_all()
            rest = self._takt_s - (self._jetzt() - beginn)
            if rest > 0:
                self._schlaf(rest)

    def _naechste(self, frist_s=0.5):
        with self._neu:
            if self._antworten is None:
                self._neu.wait(frist_s)
            antworten, self._antworten = self._antworten, None
            return antworten

    def run(self):
        holer = threading.Thread(target=self._holschleife, name="spotlab-blick-abruf", daemon=True)
        holer.start()
        try:
            while not self._halt.is_set():
                antworten = self._naechste()
                if antworten is None:
                    continue
                try:
                    self.schreiben(antworten)
                except Exception as fehler:
                    self._fehler(fehler)
        finally:
            self._halt.set()
            # Der Holer hängt schlimmstenfalls in einem Abruf (Frist im Backend);
            # als Daemon stirbt er mit dem Prozess, hier nur kurz warten.
            holer.join(timeout=0.5)


def starte(spot, lauf_dir, takt_s=TAKT_S):
    """Einen `Blick` starten -- oder None, wenn dieser Lauf keinen bekommt.

    Keinen bekommt er, wenn das Backend es nicht ausdrücklich erlaubt
    (`blick_aus_kameras`; MuJoCo rendert das Zimmer von aussen selbst, 2D-Sim
    und Trockenlauf haben keine Kameras) oder die Frontkameras fehlen.
    """
    from spotlab.backends.base import Capability

    backend = getattr(spot, "backend", None)
    if backend is None or not getattr(backend, "blick_aus_kameras", False):
        return None
    try:
        if not (backend.capabilities() & Capability.GRAY_CAMERAS):
            return None
        vorhanden = set(backend.image_sources())
    except Exception:
        return None
    if not all(q in vorhanden for q in KAMERAS):
        return None
    blick = Blick(spot, lauf_dir, takt_s=takt_s)
    blick.start()
    return blick
