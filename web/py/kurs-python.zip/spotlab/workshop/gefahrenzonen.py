"""Gefahrenzonen der Steuerzentrale: bekanntes Glas und andere Stellen, an die Spot nicht darf.

Agenten am Spot, Teil 3 (`docs/superpowers/specs/2026-10-10-agent-zonen-design.md`). Spot sieht
Glas nicht — weder das Hindernisgitter noch die Tiefenkameras. Wer es weiss, ist der Mensch (oder
der Agent): er zeichnet eine Gefahrenzone, und JEDE Fahrt der Zentrale meidet sie.

Eine Zone ist eine `welt.raum.Sperrzone` (Rechteck mit Drehung und Grund); wer sie gesetzt hat und
woher sie stammt, steht daneben (`Gefahrenzone`), nie in der Raumdatei. Die Regel ist die der
Übungsräume (`welt/kollision`): **hinein nie, heraus und entlang immer** — wer im Rand steht
(Drift, Bremsweg), muss herauskommen, nur tiefer hinein nicht.

`schranke` prüft einen Gehbefehl, `ZonenSpot` setzt sie vor JEDES `walk()` der Zentrale — Tasten,
Klickfahrt, Agent und Folgemodus gehen alle durch dieselbe Hülle.
"""

import json
import math
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from spotlab.record import atomar
from spotlab.welt import kollision
from spotlab.welt.raum import Sperrzone

DICKE_M = 0.3              # so dick wird eine gezogene Linie (Glaswand)
MIN_SEITE_M = 0.1          # kürzer ist ein Versehen, kein Rechteck
MAX_ZEICHEN = 40
SCHRANKE_VORAUS_S = 1.0    # ein Gehbefehl gilt am echten Spot gut eine Sekunde
LAGE_UNLESBAR = "Lage nicht lesbar — nur Drehen (Gefahrenzonen)"


@dataclass(frozen=True)
class Gefahrenzone:
    zone: Sperrzone
    von: str               # "mensch" oder der Name des Agenten
    quelle: str            # raum, karte, lauf, uebung
    gesetzt: float         # Wanduhr beim Setzen

    @property
    def name(self):
        return self.zone.name

    @property
    def grund(self):
        return self.zone.grund


def _name(name):
    name = str(name or "").strip()
    if not 1 <= len(name) <= MAX_ZEICHEN:
        raise ValueError(f"Eine Gefahrenzone braucht einen Namen mit 1 bis {MAX_ZEICHEN} Zeichen, "
                         f"nicht {name!r}")
    return name


def _zahl(wert):
    zahl = float(wert)
    if not math.isfinite(zahl):
        raise ValueError(f"Eine Gefahrenzone braucht endliche Zahlen, nicht {wert!r}")
    return zahl


def aus_linie(name, von_xy, bis_xy, dicke_m=DICKE_M, grund=""):
    """Ein Streifen von `dicke_m` entlang der Linie — so liegt eine Glaswand."""
    x1, y1, x2, y2 = (_zahl(v) for v in (*von_xy, *bis_xy))
    dicke = _zahl(dicke_m)
    laenge = math.hypot(x2 - x1, y2 - y1)
    if laenge < MIN_SEITE_M or dicke < MIN_SEITE_M:
        raise ValueError(f"Die Linie ist zu kurz oder zu dünn ({laenge:.2f} m × {dicke:.2f} m, "
                         f"mindestens {MIN_SEITE_M} m) — länger ziehen.")
    return Sperrzone(_name(name), (x1 + x2) / 2, (y1 + y2) / 2, laenge, dicke,
                     drehung=math.degrees(math.atan2(y2 - y1, x2 - x1)), grund=str(grund or ""))


def aus_flaeche(name, ecke_a, ecke_b, grund=""):
    """Ein achsparalleles Rechteck zwischen zwei Ecken — so liegt ein Treppenabgang."""
    x1, y1, x2, y2 = (_zahl(v) for v in (*ecke_a, *ecke_b))
    breite, tiefe = abs(x2 - x1), abs(y2 - y1)
    if breite < MIN_SEITE_M or tiefe < MIN_SEITE_M:
        raise ValueError(f"Die Fläche ist zu schmal ({breite:.2f} m × {tiefe:.2f} m, mindestens "
                         f"{MIN_SEITE_M} m je Seite) — grösser ziehen.")
    return Sperrzone(_name(name), (x1 + x2) / 2, (y1 + y2) / 2, breite, tiefe,
                     grund=str(grund or ""))


# ------------------------------------------------------------ Datei


def pfad_karte(arbeitsordner, karte):
    """`<Arbeitsordner>/karten/<karte>/gefahrenzonen.json` — zieht mit der Karte um."""
    from spotlab.maps import store

    return store.karten_wurzel(arbeitsordner) / karte / store.ZONEN


def pfad_uebung(arbeitsordner, raum):
    """`<Arbeitsordner>/raeume/<raum>.gefahrenzonen.json` — eine eigene Datei neben dem Raum,
    damit der Raumeditor sie beim Speichern des Raums nicht verliert (wie die Merkorte)."""
    from spotlab.welt.raum import raum_pfad

    return raum_pfad(arbeitsordner, raum).with_name(f"{raum}.gefahrenzonen.json")


def schreibe(pfad, zonen):
    """Atomar schreiben — oder `ValueError`, wenn es nicht gelang: eine Zone, die nur im Speicher
    steht, gälte als gespeichert und fehlte beim nächsten Laden."""
    pfad = Path(pfad)
    daten = [dict(asdict(g.zone), von=g.von, quelle=g.quelle, gesetzt=g.gesetzt) for g in zonen]
    try:
        pfad.parent.mkdir(parents=True, exist_ok=True)
        geschrieben = atomar.schreibe_atomar(pfad, json.dumps(daten, ensure_ascii=False))
    except OSError as fehler:
        geschrieben, grund = False, f" ({fehler})"
    else:
        grund = ""
    if not geschrieben:
        raise ValueError(f"Gefahrenzonen nicht gespeichert{grund}: {pfad} — die Änderung gilt "
                         f"nicht, nochmal versuchen")


def lies(pfad):
    """Die Zonen aus der Datei. Fehlt sie: keine. Ist sie unlesbar: `ValueError` — kaputt ist
    nicht leer, sonst überschriebe die nächste Zone alle alten. Ein einzelner kaputter Eintrag
    fällt weg, die anderen bleiben."""
    pfad = Path(pfad)
    if not pfad.exists():
        return []
    try:
        roh = json.loads(pfad.read_text(encoding="utf-8"))
        if not isinstance(roh, list):
            raise ValueError("keine Liste")
    except (OSError, ValueError) as fehler:
        raise ValueError(f"Zonendatei {pfad} unlesbar ({fehler})") from fehler
    zonen = []
    for z in roh:
        try:
            zonen.append(Gefahrenzone(
                Sperrzone(_name(z["name"]), float(z["x"]), float(z["y"]), float(z["breite"]),
                          float(z["tiefe"]), float(z.get("drehung", 0.0)), str(z.get("grund", ""))),
                von=str(z["von"]), quelle=str(z["quelle"]), gesetzt=float(z["gesetzt"])))
        except (ValueError, TypeError, KeyError, AttributeError):
            continue
    return zonen


# ------------------------------------------------------------ Schranke


def schranke(zonen, lage, vx, vy, wz, voraus_s=SCHRANKE_VORAUS_S):
    """(vx, vy, wz, Grund) — der Befehl, wie er durch die Zonen darf.

    `lage` (x, y, Gier in Bogenmass) im Rahmen „vision“, der Befehl im Körperrahmen. Käme Spot
    nach `voraus_s` einer Zone näher und in ihren Rand, fällt die Fahrt weg, das Drehen bleibt.
    Ohne lesbare Lage gibt es mit Zonen nur noch Drehen (fail-closed)."""
    if not zonen or (vx == 0.0 and vy == 0.0):
        return vx, vy, wz, ""
    if lage is None:
        return 0.0, 0.0, wz, LAGE_UNLESBAR
    x, y, gier = lage
    c, s = math.cos(gier), math.sin(gier)
    nach = (x + (vx * c - vy * s) * voraus_s, y + (vx * s + vy * c) * voraus_s)
    name = kollision.zonen_auf_strecke(zonen, (x, y), nach)
    if name is None:
        return vx, vy, wz, ""
    zone = next(z for z in zonen if z.name == name)
    grund = f" ({zone.grund})" if zone.grund else ""
    return 0.0, 0.0, wz, f"Gefahrenzone ‹{name}›{grund} voraus"


class ZonenSpot:
    """Spot hinter der Schranke: `walk()` geht durch `pruefe(vx, vy, wz)`, alles andere durch.

    Der letzte Grund steht in `grund` ("" heisst: ungebremst)."""

    def __init__(self, spot, pruefe):
        self._spot = spot
        self._pruefe = pruefe
        self.grund = ""

    def walk(self, vx=0.0, vy=0.0, wz=0.0, **mehr):
        vx, vy, wz, self.grund = self._pruefe(vx, vy, wz)
        return self._spot.walk(vx=vx, vy=vy, wz=wz, **mehr)

    def __getattr__(self, name):
        return getattr(self._spot, name)


# ------------------------------------------------------------ Verwaltung der Quellen

NICHT_PLATZIERT = ("Zonen der Karte noch nicht platziert — einen Tag der Karte ins Bild drehen, "
                   "bis Spot verortet ist")
NACHBEARBEITET = ("Karte nach dem Einzeichnen nachbearbeitet — die Zonen können sich verschoben "
                  "haben, im Tab prüfen")


def _verschoben(zone, trafo, rueckwaerts=False):
    """Die Zone im anderen Rahmen: Seed → „vision“ (`R(dg)·p + t`) oder zurück."""
    tx, ty, dg = trafo
    if rueckwaerts:
        x, y, dg = zone.x - tx, zone.y - ty, -dg
        c, s = math.cos(dg), math.sin(dg)
        x, y = c * x - s * y, s * x + c * y
    else:
        c, s = math.cos(dg), math.sin(dg)
        x, y = c * zone.x - s * zone.y + tx, s * zone.x + c * zone.y + ty
    return Sperrzone(zone.name, x, y, zone.breite, zone.tiefe,
                     drehung=zone.drehung + math.degrees(dg), grund=zone.grund)


def _raum_zonen_der_karte(arbeitsordner, karte):
    """Die Sperrzonen aller eigenen Räume, die aus dieser Karte gebaut wurden — im Seed-Rahmen."""
    from spotlab.welt import raum as raummodul

    zonen = []
    for name in raummodul.eigene_raeume(arbeitsordner):
        try:
            raum = raummodul.raum_laden(name, arbeitsordner)
        except Exception:
            continue                         # ein kaputter Raum nimmt die anderen nicht mit
        if raum.karte is None or raum.karte.name != karte:
            continue
        for z in raum.sperrzonen:
            x, y, grad = raummodul.nach_karte(raum, z.x, z.y, z.drehung)
            zonen.append(Gefahrenzone(Sperrzone(z.name, x, y, z.breite, z.tiefe, grad, z.grund),
                                      von="raumeditor", quelle="raum", gesetzt=0.0))
    return zonen


class Gefahrenzonen:
    """Alle Zonen der Zentrale an EINER Stelle, für Schranke, Wegsuche und Lagebild in „vision“.

    Quellen: `raum` (die Zonen des Übungsraums, oder am echten Spot die der Räume, die aus der
    geladenen Karte gebaut wurden — ändern nur im Raumeditor), `karte` (gesetzt mit geladener und
    platzierter Karte, Datei im Kartenordner, Seed-Rahmen), `uebung` (gesetzt im Übungsraum,
    Datei neben dem Raum) und `lauf` (sonst: nur bis zum Ende der Zentrale). Die Zentrale ruft
    `beobachte` im Wahrnehmungsfaden und `setze`/`loesche` im Fahrtakt — eine Sperre trennt sie."""

    def __init__(self, arbeitsordner=None, uebung_pfad=None, raum_zonen=(), jetzt=None):
        self.arbeitsordner = arbeitsordner
        self.jetzt = jetzt or time.time
        self._sperre = threading.Lock()
        self._uebung_pfad = Path(uebung_pfad) if uebung_pfad else None
        self._raum = [Gefahrenzone(z, von="raumeditor", quelle="raum", gesetzt=0.0)
                      for z in raum_zonen]                       # „vision“ (Übungsraum)
        self._kaputt = {}                # Quelle -> warum ihre Datei unlesbar ist (nie überschreiben)
        self._uebung = self._lies("uebung", self._uebung_pfad) if self._uebung_pfad else []
        self._lauf = []
        self._karte_name = None
        self._karte = []                 # Seed-Rahmen, aus der Datei der Karte
        self._karte_raum = []            # Seed-Rahmen, aus den Räumen der Karte
        self._trafo = None
        self._nachbearbeitet = None

    # ---------------------------------------------------------- Karte

    def beobachte(self, karte, trafo, nachbearbeitet=None):
        """Die geladene Karte (Name oder None), wie sie in „vision“ liegt (`vision_von_seed` oder
        None — dann bleibt die letzte Lage) und wann sie zuletzt nachbearbeitet wurde (Wanduhr)."""
        if karte != self._karte_name:
            datei = (self._lies("karte", pfad_karte(self.arbeitsordner, karte))
                     if karte and self.arbeitsordner else self._lies("karte", None))
            raeume = (_raum_zonen_der_karte(self.arbeitsordner, karte)
                      if karte and self.arbeitsordner else [])
            with self._sperre:
                self._karte_name, self._karte, self._karte_raum = karte, datei, raeume
                self._trafo = None
        with self._sperre:
            if trafo is not None:
                self._trafo = tuple(trafo)
            self._nachbearbeitet = nachbearbeitet

    def _lies(self, quelle, pfad):
        """Die Datei einer Quelle — eine unlesbare merkt sich, damit sie nie überschrieben wird."""
        self._kaputt.pop(quelle, None)
        if pfad is None:
            return []
        try:
            return lies(pfad)
        except ValueError as fehler:
            self._kaputt[quelle] = str(fehler)
            return []

    @property
    def unplatziert(self):
        """Hat die Karte Zonen, aber Spot war seit dem Laden nie verortet?"""
        with self._sperre:
            return bool(self._karte or self._karte_raum) and self._trafo is None

    @property
    def hinweis(self):
        if self._kaputt:
            return " · ".join(f"{grund} — nichts wird überschrieben, die Datei prüfen"
                              for grund in self._kaputt.values())
        if self.unplatziert:
            return NICHT_PLATZIERT
        with self._sperre:
            gesetzt = [g.gesetzt for g in self._karte]
            spaeter = self._nachbearbeitet
        if gesetzt and spaeter is not None and spaeter > max(gesetzt):
            return NACHBEARBEITET
        return ""

    # ---------------------------------------------------------- Lesen

    def _alle(self):
        """(Gefahrenzone, Zone in „vision“ oder None) — unter der Sperre."""
        paare = [(g, g.zone) for g in (*self._raum, *self._uebung, *self._lauf)]
        for g in (*self._karte, *self._karte_raum):
            paare.append((g, None if self._trafo is None else _verschoben(g.zone, self._trafo)))
        return paare

    def in_vision(self):
        """Die platzierten Zonen im Rahmen „vision“ — für Schranke und Wegsuche."""
        with self._sperre:
            return [v for _, v in self._alle() if v is not None]

    def als_daten(self):
        with self._sperre:
            liste = [{"name": g.name, "grund": g.grund, "von": g.von, "quelle": g.quelle,
                      "ecken": [[round(x, 3), round(y, 3)] for x, y in v.ecken()]}
                     for g, v in self._alle() if v is not None]
        return {"liste": liste, "hinweis": self.hinweis}

    # ---------------------------------------------------------- Ändern

    def setze(self, zone, von):
        """Eine neue Zone (in „vision“). Im Übungsraum gehört sie zum Raum, mit platzierter Karte
        zur Karte, sonst nur zum Lauf."""
        with self._sperre:
            if any(g.name == zone.name for g, _ in self._alle()):
                raise ValueError(f"Eine Zone ‹{zone.name}› gibt es schon — einen anderen Namen "
                                 f"wählen.")
            gesetzt = float(self.jetzt())
            if self._uebung_pfad is not None:
                self._nicht_kaputt("uebung")
                neu = Gefahrenzone(zone, von=von, quelle="uebung", gesetzt=gesetzt)
                schreibe(self._uebung_pfad, [*self._uebung, neu])      # erst die Datei
                self._uebung.append(neu)
            elif self._karte_name and self._trafo is not None and self.arbeitsordner:
                self._nicht_kaputt("karte")
                seed = _verschoben(zone, self._trafo, rueckwaerts=True)
                neu = Gefahrenzone(seed, von=von, quelle="karte", gesetzt=gesetzt)
                schreibe(pfad_karte(self.arbeitsordner, self._karte_name), [*self._karte, neu])
                self._karte.append(neu)
            else:
                neu = Gefahrenzone(zone, von=von, quelle="lauf", gesetzt=gesetzt)
                self._lauf.append(neu)
        return neu

    def loesche(self, name, von):
        """Eine Zone löschen — ein Mensch alle ausser Raum-Zonen, ein Agent nur seine eigenen."""
        name = str(name or "").strip()
        with self._sperre:
            treffer = next((g for g, _ in self._alle() if g.name == name), None)
            if treffer is None:
                vorhanden = ", ".join(g.name for g, _ in self._alle()) or "keine"
                raise ValueError(f"Eine Zone ‹{name}› gibt es nicht — vorhanden: {vorhanden}")
            if treffer.quelle == "raum":
                raise ValueError(f"‹{name}› gehört zum Raum — im Raumeditor löschen.")
            if von != "mensch" and treffer.von != von:
                wer = "ein Mensch" if treffer.von == "mensch" else treffer.von
                raise ValueError(f"‹{name}› hat {wer} gesetzt — nur ein Mensch im Tab kann sie "
                                 f"löschen.")
            if treffer.quelle == "uebung":
                schreibe(self._uebung_pfad, [g for g in self._uebung if g is not treffer])
            elif treffer.quelle == "karte":
                schreibe(pfad_karte(self.arbeitsordner, self._karte_name),
                         [g for g in self._karte if g is not treffer])
            for liste in (self._uebung, self._lauf, self._karte):
                if treffer in liste:
                    liste.remove(treffer)
        return treffer

    def _nicht_kaputt(self, quelle):
        if quelle in self._kaputt:
            raise ValueError(f"{self._kaputt[quelle]} — keine neue Zone dort, damit die alten "
                             f"nicht verloren gehen; die Datei prüfen")


# ------------------------------------------------------------ Sperrbereiche im Roboter

SPERRBEREICH_LEBT_S = 6.0      # so lange gilt ein Sperrbereich ohne Auffrischen (der Totmann)
SPERRBEREICH_TAKT_S = 2.0      # so oft wird aufgefrischt


GLEICH_M = 0.02            # so viel zittert eine Kartenzone mit der Verortung, ohne neu zu senden
GLEICH_GRAD = 1.0


def _gleich(a, b):
    """Dieselben Zonen, bis aufs Zittern der Verortung? (Sonst gingen am echten Spot mit jeder
    Wahrnehmung — 4-mal je Sekunde — alle Sperrbereiche neu hinaus.)"""
    if a is None or b is None or len(a) != len(b):
        return False
    return all(x.name == y.name and abs(x.x - y.x) <= GLEICH_M and abs(x.y - y.y) <= GLEICH_M
               and abs(x.breite - y.breite) <= GLEICH_M and abs(x.tiefe - y.tiefe) <= GLEICH_M
               and abs((x.drehung - y.drehung + 180.0) % 360.0 - 180.0) <= GLEICH_GRAD
               for x, y in zip(a, b))


class ZonenRoboter:
    """Die Gefahrenzonen als Sperrbereiche im Roboter — die zweite Sicherung.

    Nur mit `Capability.NOGO_REGIONS` (am echten Spot); sonst tut sie nichts und `anzahl` ist
    None. Aufgefrischt wird bei jeder Änderung und alle `SPERRBEREICH_TAKT_S`: erst die neuen
    setzen, dann die alten löschen, damit keine Lücke entsteht. Ein Fehler hält nichts an — die
    Schranke in spotlab gilt weiter — er steht in `fehler` und wird je Text einmal gesagt."""

    def __init__(self, backend, melde=print):
        from spotlab.backends.base import Capability

        self.backend = backend
        self.melde = melde
        try:
            self.kann = bool(backend.capabilities() & Capability.NOGO_REGIONS)
        except Exception:
            self.kann = False
        self._ids = []
        self._gesetzt = None           # die Zonen, für die `_ids` gelten
        self._t = None
        self._fehler_t = None          # nach einem Fehler erst nach dem Takt wieder versuchen
        self.fehler = ""
        self._gesagt = set()

    @property
    def anzahl(self):
        return len(self._ids) if self.kann else None

    def abgleichen(self, zonen, t):
        if not self.kann:
            return
        zonen = list(zonen)
        if self._fehler_t is not None and t - self._fehler_t < SPERRBEREICH_TAKT_S:
            return
        if (_gleich(zonen, self._gesetzt) and self._t is not None
                and t - self._t < SPERRBEREICH_TAKT_S):
            return
        try:
            neu = self.backend.sperrbereiche_setzen(zonen, SPERRBEREICH_LEBT_S) if zonen else []
            alt, self._ids, self._gesetzt, self._t = self._ids, list(neu), zonen, t
            if alt:
                self.backend.sperrbereiche_loeschen(alt)
            self.fehler, self._fehler_t = "", None
        except Exception as fehler:
            self._fehler_t = t
            self._fehler(fehler)

    def schluss(self):
        if not self.kann or not self._ids:
            return
        try:
            self.backend.sperrbereiche_loeschen(self._ids)
        except Exception as fehler:
            self._fehler(fehler)
        self._ids, self._gesetzt = [], None

    def _fehler(self, fehler):
        self.fehler = (f"Sperrbereiche im Roboter gescheitert ({fehler}) — die Gefahrenzonen gelten "
                       f"in spotlab weiter")
        if self.fehler not in self._gesagt:
            self._gesagt.add(self.fehler)
            self.melde(self.fehler)
