"""Folgen: Spot geht einem Menschen hinterher — mit Abstand und mit Schranken.

Das Programm dazu ist `Beispiele/folgen.py` im Arbeitsordner. Es besteht aus
zwei Teilen, die man getrennt lesen und getrennt austauschen kann:

ZIEL-FINDER   sagt, wo das Ziel ist: `(Peilung in Grad, Abstand in Metern)`.
              Woher er das weiss, ist ihm überlassen — ein AprilTag am Rucksack
              (`tag_finder`), Spots eigener Personen-Tracker (`personen_finder`)
              oder etwas Selbstgebautes. Alle drei liefern dasselbe Paar.
REGLER        `folge()` hält daraus den Abstand und die Nase auf das Ziel.

Die Trennung ist der Punkt: der Regler bleibt gleich, wenn der Finder wechselt,
und damit lassen sich Strategien VERGLEICHEN, statt sie zu behaupten.

SCHRANKEN. Ein Roboter, der von selbst einem Menschen hinterherläuft, ist ein
anderer Fall als ein Roboter, den jemand fährt. Deshalb, alle gleichzeitig:

- Näher als `MIN_ABSTAND_M` geht er nie. Rückwärts fährt er auch nicht — nach
  hinten sieht er nichts; kommt der Mensch näher, bleibt Spot stehen.
- Ohne Ziel steht er. Blind weiter FAHREN darf er nur den Nachlauf lang
  (`NACHLAUF_S`, 1 s); der Merkpunkt (`workshop/merkpunkt.py`) lässt ihn danach
  bis `merkpunkt.HALTEN_S` nur noch zum gemerkten Menschen DREHEN, dann steht
  er und sucht. Das ist derselbe Totmann-Gedanke wie im Fahrmodus.
- Vorwärts nur, wenn das Hindernisgitter voraus Platz meldet, wenn über dem
  Weg genug Kopfraum ist und wenn keine Sperrzone davorliegt. Jede Schranke,
  die ihre Daten NICHT lesen kann, verbietet die Fahrt (fail-closed) — eine
  Schranke, die bei Störung durchwinkt, ist keine.
- Das Tempo: nah höchstens `MAX_TEMPO_M_S`, weit weg bis `MAX_TEMPO_WEIT_M_S`
  (`tempo_deckel`); schneller als `MAX_TEMPO_M_S` prüfen alle drei Schranken
  weiter voraus (`vorausschau_m`), und reicht der Platz nicht, fährt er das alte
  Tempo. `config.toml` deckelt zusätzlich, wie bei jedem `walk()`.

Der Kopfraum wird bis `MAX_TEMPO_M_S` nicht in jedem Takt geprüft: zwei
Tiefenbilder über WLAN kosten mehr Zeit als ein Takt. Er gilt `KOPFRAUM_TAKT_S`
lang weiter, und in dieser Zeit legt Spot höchstens einen halben Meter zurück —
der geprüfte Korridor reicht zwei Meter voraus. Wer schneller fährt, holt ihn
jeden Takt frisch.
"""

import contextlib
import contextvars
import math
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path

from spotlab.errors import SpotlabError
from spotlab.record.run import STOPP_DATEI
from spotlab.workshop import folgeaufnahme, merkpunkt
from spotlab.workshop.beispiele import ORDNER

DATEINAME = "folgen.py"

WUNSCH_ABSTAND_M = 1.6           # so nah will Spot heran
MIN_ABSTAND_M = 1.0              # näher NIE
TOLERANZ_M = 0.25                # innerhalb davon fährt er gar nicht
MAX_TEMPO_M_S = 0.5              # zusätzlich zum Deckel aus config.toml
ANNAEHERUNG = 0.6                # m/s je Meter Abstandsfehler
# WEIT WEG DARF ER SCHNELLER (27.09.2026, freigegeben vom Menschen): in der zweiten
# Folge-Aufnahme (20260925T155416Z) fuhr Spot 116 Takte am Deckel von 0.5 m/s, und
# zweimal wuchs der Abstand dabei auf 7-8 m -- genau dort ging der Mensch verloren.
# Bis WEIT_AB_M bleibt es bei MAX_TEMPO_M_S, bis WEIT_VOLL_M steigt der Deckel auf
# MAX_TEMPO_WEIT_M_S. `config.toml` deckelt weiter alles (Schueler 0.6 m/s).
MAX_TEMPO_WEIT_M_S = 1.0
WEIT_AB_M = 2.5
WEIT_VOLL_M = 3.5
# Wer schneller faehrt als MAX_TEMPO_M_S, prueft so viele Sekunden des Mehrtempos
# weiter voraus -- Gitter, Kopfraum und Sperrzonen: bei 1 m/s 1.8 m statt 0.8 m frei.
# Darunter bleibt alles wie bisher. Reicht der Platz nicht, faehrt er MAX_TEMPO_M_S.
VORAUS_JE_TEMPO_S = 2.0
MAX_DREHRATE_GRAD = 45.0
LENKUNG = 1.2                    # Grad/s je Grad Peilung
# Je Takt hoechstens diesen Anteil der Peilung wegdrehen. Mit dem Tag dauert ein
# Takt 0.2 s und die Deckelung greift nie; mit dem Gesicht sind es 0.45-0.9 s
# (vier Bilder plus YuNet), und bei 45 Grad/s drehte Spot je Takt 20-40 Grad --
# mehr als die Peilung selbst. Lauf 20260916T122739Z: 94 Befehle, wz pendelt
# zwischen -0.79 und +0.79 rad/s mit 13 Drehsinn-Wechseln, vx fast immer null.
ANTEIL_JE_TAKT = 0.5
SCHWENK_GRAD = 40.0              # weiter seitlich: erst drehen, nicht fahren
# Unter dieser Peilung wird nicht gedreht: die Huefte eines Menschen wandert im Bild
# um ein paar Pixel, und bei 7 px je Grad hiesse jedes Zittern ein Drehbefehl.
PEILUNG_TOTBAND_GRAD = 4.0
# Die Kreissperre. Lauf 20260917T094118Z: zweimal 14 Takte lang +45 Grad/s, ueber 400
# Grad, ohne dass das Ziel je vor den Roboter kam -- ein Mensch bei +60 Grad ist nach
# 1.3 s voraus, ein Ziel, das im Bild stehen bleibt, ist keiner. Wer eine halbe
# Drehung lang seitlich bleibt, hoert auf zu drehen und wartet, bis etwas vor ihm ist.
MAX_SUCHDREHUNG_GRAD = 180.0
FREIRAUM_M = 0.8                 # so viel muss voraus frei sein
KOPFRAUM_M = 1.0                 # so weit voraus darf nichts über dem Weg hängen
KOPFRAUM_TAKT_S = 1.0
ZONE_VORAUS_M = 1.0
# Quellen der Gesichtssuche: die zwei Frontkameras fuer das Bild, die zwei
# Tiefenkameras fuer die Entfernung -- in EINEM Abruf, nicht in zweien.
GESICHT_QUELLEN = ("frontright_fisheye_image", "frontleft_fisheye_image")
TIEFE_QUELLEN = ("frontleft_depth", "frontright_depth")
# Die Bilder DIESES Takts, solange eine Staffel (`zuerst`) läuft: der zweite Finder nimmt
# dieselbe Aufnahme, statt vier Bilder neu zu holen. Lauf 20260925T125326Z: in 303 von 441
# Takten holte das Gesicht die Bilder ein zweites Mal, je rund 200 ms. Ausserhalb einer
# Staffel ist der Wert None, und jeder Aufruf holt selbst — wie vorher.
_TAKT_BILDER = contextvars.ContextVar("folgen_takt_bilder", default=None)
# WER ist das Ziel, wenn ein Finder mehrere Menschen sieht? In `folge()` entscheidet
# der Merkpunkt (`workshop/merkpunkt.py`: der, der dort steht, wo der gefolgte erwartet
# wird), ausserhalb der naechste. Eine ContextVar wie `_TAKT_BILDER`: die Signatur der
# Finder bleibt, und ein selbstgebauter Finder bekommt die Wahl ueber `waehle_ziel`.
_WAHL = contextvars.ContextVar("folgen_wahl", default=None)
TAKT_S = 0.2
VERLOREN_S = 5.0                 # so lange ohne Ziel, dann sagt er es
# ...und dann immer wieder. Einmal am Anfang genügt nicht: nach einer halben
# Minute ist die Zeile weggescrollt, und ein stehender Spot ist von einem
# hängenden Programm nicht zu unterscheiden (gesehen am 16.09.2026).
STILLE_TAKT_S = 15.0
# NACHLAUF: ein Ziel, das vor unter einer Sekunde noch da war, gilt weiter, und
# der Regler faehrt aus dem letzten Ziel weiter -- mit allen Schranken. Der
# Erkenner trifft neun von zehn Takten, und der zehnte hielt Spot bisher sofort
# an; das Folgen stotterte. Eine Sekunde bei 0.5 m/s sind 50 cm blind, und das
# Fahrkommando selbst verfaellt ohnehin nach rund einer Sekunde. Entscheidung
# des Menschen am 16.09.2026. 0 = der alte Sofortstopp.
NACHLAUF_S = 1.0
# Wie weit Spot die Nase hebt, damit die Kameras hoeher schauen. 0 = gar nicht.
# Gerechnet (`backends/real/gesicht.py`): ohne Neigung kommt ein stehendes Gesicht
# erst ab 2.31 m ins Bild, mit 10 Grad ab 1.46 m, mit 15 Grad ab 1.18 m. Der
# Preis steht daneben: der Boden vor den Fuessen verschwindet, bei 15 Grad ist er
# erst ab 0.66 m statt 0.32 m im Bild.
#
# VORGABE 15 SEIT DEM 16.09.2026. Bis dahin war sie null, um der Hindernisschranke
# den Boden zu lassen -- und der Folgemodus fand deshalb NIE einen aufrecht
# stehenden Menschen auf Folgeabstand: mit waagrechtem Koerper reicht das Bild bei
# 1.5 m bis 1.20 m Hoehe, bei 2 m bis 1.45 m (150 Takte bei `stand()`: auf 1 m nur
# Beine im Bild, auf 2 m der Oberkoerper oben abgeschnitten). In den beiden Sonden,
# in denen er jeden Takt ein Gesicht fand, stand er mit der Nase 25 Grad oben.
# Wer den Boden braucht, sagt `blick_grad=0` -- der alte Weg bleibt.
BLICK_GRAD = 15.0
MAX_BLICK_GRAD = 20.0
# DIE NASE FOLGT DEM GESICHT (16.09.2026). Feste Zahlen passen fuer EINEN
# Menschen: bei 15 Grad und 1.6 m genau voraus lag ein 1.65 m hohes Gesicht in
# der Naht-Kerbe (Grenze 1.46 m) und war abgeschnitten -- Takt 110 der
# Reichweiten-Sonde, fotografiert. Deshalb haelt `folge()` die Oberkante des
# Kastens auf SOLL_OBEN_GRAD: sicher unter der Kerbe (+17 Grad) und der Kante
# (+26). Zu hoch -> Nase hoch, hoechstens NICK_SCHRITT_GRAD je Takt, bis
# MAX_BLICK_GRAD; zu tief -> Nase runter bis NICK_MIN_GRAD, damit die
# Hindernisschranke den Boden zurueckbekommt, wenn Spot Strecke macht -- aber
# nie ganz flach, sonst ist das Gesicht beim Naeherkommen sofort wieder weg.
# Reihenfolge der Wuensche (Mensch, 16.09.2026): erst so nah wie moeglich, dann
# so hoch wie moeglich schauen; erst wenn die Nase am Anschlag ist und der
# Kasten noch ZU_HOCH_GRAD ueber dem Soll liegt, kommt er nicht naeher.
SOLL_OBEN_GRAD = 10.0
NICK_MIN_GRAD = 10.0
NICK_SCHRITT_GRAD = 3.0
TOTBAND_GRAD = 2.0
ZU_HOCH_GRAD = 4.0

# Handzeichen (`gesten_leser`): gelesen wird nur beim gefolgten Koerper, jeden
# `GESTEN_JEDER_TAKT`-ten Takt, in dem es einen gibt -- eine Lesung kostet rund
# 65 ms (Handflaeche 45, Handpose 18, gemessen am 16.09.2026), ein Koerper-Takt
# mit Spur rund 60 ms. Ein Zeichen zaehlt erst nach `GESTEN_TAKTE` Lesungen
# hintereinander: bei einem halben Takt-Sekunde sind das zwei bis drei Sekunden
# gehaltene Hand. Ein erfundenes Halt haelt den Roboter an, ein erfundenes
# Weiter laesst ihn losgehen -- beides ist schlimmer als ein uebersehenes.
GESTEN_JEDER_TAKT = 2
GESTEN_TAKTE = 3

# Die LEDs am Kopf sagen, was Spot gerade denkt -- fuer den Menschen DAVOR, der
# keinen Laptop in der Hand hat. Ohne sie sieht niemand, ob ein Handzeichen
# angekommen ist; man sieht nur, dass der Roboter steht, und das tut er aus
# vielen Gruenden. Gesetzt wird nur bei ECHTER Aenderung (`api.signals.Statuslicht`).
LICHT_FOLGT = "blue"          # ein Mensch ist da, Spot haelt sich an ihn
LICHT_SUCHT = "yellow"        # kein Ziel -- er sucht
LICHT_ANGEHALTEN = "red"      # per Handzeichen gestoppt, wartet auf den Daumen


@dataclass(frozen=True)
class Ziel:
    bearing: float               # Grad, links positiv
    distance: float              # Meter
    name: str = "Ziel"
    # Hoehenwinkel der OBERKANTE des Kastens, koerperfest (Grad, oben positiv) --
    # nur beim Gesicht gesetzt. Das ist, was oben aus dem Bild laeuft, und
    # danach regelt `folge()` die Nase. Ein Tag hat kein "im Bild"-Problem.
    bild_oben: float = None
    # Der Gierwinkel des Roboters (RAD, aus `state.pose`), als das Bild kam, aus dem
    # dieses Ziel stammt -- None, wenn das Ziel nicht aus einem Bild ist (Tag, Tracker).
    # `folge()` zieht davon ab, was Spot seither gedreht hat: das Bild ist beim Befehl
    # einen halben Takt alt, und der vorige Befehl lief die ganze Zeit weiter.
    gier: float = None
    # Wo der Roboter stand, als das Bild kam: (x, y) in Metern aus `state.pose`
    # (Odometrie) -- mit `gier` zusammen legt das den Menschen als Punkt in den
    # Raum (`workshop/merkpunkt.py`). None wie bei `gier`.
    ort: tuple = None


@dataclass(frozen=True)
class Sicht:
    """Was der Koerper-Finder in seinem letzten Takt sah -- fuer den Gestenleser.

    `nummer` zaehlt die Takte des Finders: wer dieselbe Sicht zweimal bekommt,
    liest ein altes Bild und darf daraus keine Geste zaehlen.
    """

    nummer: int
    aufnahme: object             # die `Gesichtsaufnahme` des Takts (Feld, Panorama, Punkte)
    koerper: object              # der GENOMMENE `Koerper` -- der Mensch, dem Spot folgt


def skript_in(arbeitsordner):
    """Das Folgeprogramm im Projekt Beispiele des Arbeitsordners."""
    return Path(arbeitsordner) / ORDNER / DATEINAME


# ----------------------------------------------------------------- Finder


def tag_finder(tag_id=None):
    """Folgt einem AprilTag — am Rucksack, auf einem Schild, in der Hand.

    Der zuverlässigste Weg und der einzige, der heute nachweislich funktioniert:
    Peilung und Abstand kommen aus demselben Dienst wie bei der Kartenaufnahme,
    in Grad und Metern. Ohne `tag_id` das nächste sichtbare Tag.
    """
    zuletzt = {"text": ""}

    def finde(spot):
        gefunden = spot.tags(id=tag_id) if tag_id is not None else spot.tags()
        zuletzt["text"] = (f"{len(gefunden)} Tags sichtbar" if gefunden
                           else "kein Tag sichtbar")
        if not gefunden:
            return None
        tag = gefunden[0]
        return Ziel(tag.bearing, tag.distance, f"Tag {tag.id}")

    finde.befund = lambda: zuletzt["text"]
    return finde


def personen_finder(mindestsicherheit=None):
    """Folgt einem Menschen, den Spots eigene Firmware verfolgt.

    Kein eigenes Modell — der Tracker steckt im Roboter (`spot.people()`).
    Ob dieser Spot ihn hat, zeigt erst das Gerät; liefert er nichts, findet
    dieser Finder nichts, und `folge()` lässt Spot stehen.
    """
    zuletzt = {"text": ""}

    def finde(spot):
        leute = spot.people()
        if mindestsicherheit is not None:
            leute = [p for p in leute if p.likelihood >= mindestsicherheit]
        zuletzt["text"] = (f"{len(leute)} Personen gemeldet" if leute
                           else "keine Person gemeldet")
        if not leute:
            return None
        person = leute[0]
        return Ziel(person.bearing, person.distance, f"Person {person.entity_id}")

    finde.befund = lambda: zuletzt["text"]

    # Der Hinweis hängt am Finder, nicht in `folge()`: nur der Finder weiss, warum
    # er leer ausgeht. `folge()` sagt ihn einmal, wenn wirklich nichts kommt --
    # sonst stünde er auch dort, wo der Tracker tut, was er soll.
    finde.hinweis = (
        "Hinweis zu personen_finder(): er fragt Spots eigenen Personen-Tracker. "
        "Am Schul-Spot lieferte der in 560 Abfragen null Treffer — diese "
        "Robotersoftware führt keine Personen (docs/ABNAHME.md, A34 Teil 1, "
        "gemessen am 11.09.2026). Nimm tag_finder() oder gesicht_finder(), oder "
        "staffle beide mit zuerst()."
    )
    return finde


def koerper_finder(ordner=None, quellen=GESICHT_QUELLEN, tiefe_quellen=TIEFE_QUELLEN,
                   aufnahme_holen=None, koerper_holen=None):
    """Folgt einem Körper — der Hüfte, notfalls den Schultern — mit Gegenprobe aus der Tiefe.

    Gemessen am 16.09.2026 über 510 Panoramen: das Gesicht fand den Menschen in
    149 Takten, der Körper in 134 — in ANDEREN Momenten. 33-mal nur der Körper:
    die kopflosen Bilder, 1.3–2 m, aufrecht, in der Naht-Kerbe. 47-mal nur das
    Gesicht: weit weg. Deshalb stand dieser Finder in der Staffel VOR dem
    Gesicht. Seit dem 25.09.2026 sucht er mit YOLOX (`koerper.YoloxPersonen`)
    und findet auch weit weg und kopflos; das Gesicht brachte in zwei
    aufgenommenen Fahrten nichts mehr dazu, und die Vorlage nimmt ihn ALLEIN.

    Das Ziel ist die Hüftmitte (`backends/real/koerper.py`), geprüft auf
    0.6–1.3 m über dem Boden; `bild_oben` ist die Schulterlinie, nicht die
    Stirn — die Nasenregel in `folge()` hält also die Schultern im Bild, und
    dafür braucht es viel weniger Neigung als für ein Gesicht.

    `aufnahme_holen` und `koerper_holen` sind die Testtüren; ohne sie kommen
    Bilder aus `bildaufnahme` (ohne YuNet) und Körper aus `Koerpererkenner`,
    einer je Lauf, mit Spur.

    `finde.letzte()` ist die `Sicht` des letzten Takts (Bild und genommener
    Körper) — oder None, wenn er keinen nahm. Daran hängt `gesten_leser`: die
    Hand wird im Rumpf-Ausschnitt des Menschen gelesen, dem Spot folgt.
    """
    gemerkt = {}
    zuletzt = {"text": "", "nummer": 0, "sicht": None}
    erkenner = {}

    def holen_vorgabe(feld):
        from spotlab.backends.real import koerper as koerpermodul

        if "erkenner" not in erkenner:
            erkenner["erkenner"] = koerpermodul.Koerpererkenner(ordner=ordner)
        return erkenner["erkenner"].finde(feld)

    holen = koerper_holen or holen_vorgabe
    aufnahme_holen = aufnahme_holen or (
        lambda spot, gemerkt: bildaufnahme(spot, gemerkt, quellen, tiefe_quellen))

    def finde(spot):
        from spotlab.backends.real import koerper as koerpermodul

        # Die Sicht faellt ZUERST: ein Takt, der scheitert, darf kein altes Bild
        # als aktuelles stehen lassen.
        zuletzt["nummer"] += 1
        zuletzt["sicht"] = None
        mit = folgeaufnahme.aktiv()
        aufnahme = aufnahme_holen(spot, gemerkt)
        if aufnahme is None:
            zuletzt["text"] = "keine Bilder (Kamera oder Tiefe fehlt)"
            return None
        sicht_nr = mit.sicht(aufnahme, "koerper")
        with mit.zeit("koerper"):
            koerper_liste = holen(aufnahme.feld)
        with mit.zeit("koerper_probe"):
            befunde = koerpermodul.beurteile(
                koerper_liste, aufnahme.pano, aufnahme.punkte,
                aufnahme.pano.kamerahoehe(aufnahme.blick_grad), blick_grad=aufnahme.blick_grad,
            )
        # Spur oder volle Suche und das Skelett kennt nur der eingebaute Erkenner.
        eingebaut = None if koerper_holen else erkenner.get("erkenner")
        landmarken = getattr(eingebaut, "letzte_landmarken", None)
        mit.koerper(sicht_nr, koerper_liste, befunde, weg=getattr(eingebaut, "letzter_weg", None),
                    landmarken=None if landmarken is None else [landmarken])
        zuletzt["text"] = _koerperbefund(befunde)
        if getattr(eingebaut, "ohne_yolox", None):
            # Die Suche lief mit dem alten Erkenner, der viele Menschen uebersieht.
            zuletzt["text"] += " (Suche ohne YOLOX-Modell)"
        paare = []
        for b, k in zip(befunde, koerper_liste):
            if b.genommen:
                teil = "Hüfte" if b.punkt == "huefte" else "Schulter"
                paare.append((Ziel(b.bearing, b.distance, f"Körper, {teil} auf {b.height:.2f} m",
                                   bild_oben=b.bild_oben, gier=aufnahme.gier, ort=aufnahme.ort), k))
        if not paare:
            return None
        ziel = waehle_ziel([z for z, _ in paare])
        if ziel is None:
            zuletzt["text"] += ", keiner beim Merkpunkt (ein anderer Mensch?)"
            return None
        k = next(k for z, k in paare if z is ziel)
        # Die Sicht ist die des GEWAEHLTEN Menschen: an ihr liest der Gestenleser die Hand.
        zuletzt["sicht"] = Sicht(zuletzt["nummer"], aufnahme, k)
        return ziel

    finde.befund = lambda: zuletzt["text"]
    finde.letzte = lambda: zuletzt["sicht"]
    # Faellt dieser Finder aus (OpenCV fehlt, Modelle fehlen), verschluckt `zuerst()`
    # den Grund ins Protokoll -- und der Lauf saehe aus wie "niemand da". Der Hinweis
    # ist die Gegenmassnahme: `folge()` sagt ihn EINMAL, wenn wirklich nichts kommt.
    finde.hinweis = (
        "Hinweis zu koerper_finder(): er braucht OpenCV (`pip install \"spotlab[gesicht]\"`) "
        "und zwei Modelldateien aus dem OpenCV-Zoo in ~/.spotlab/modelle/ "
        "(person_detection_mediapipe und pose_estimation_mediapipe). Fehlt eines davon, "
        "findet er NIE etwas; der genaue Grund steht in `diagnose.log` des Laufs. Dazu "
        "gehört object_detection_yolox für die Suche: ohne es übersieht er viele Menschen, "
        "die gut sichtbar vor ihm stehen (`einrichten.cmd` legt alle Modelle ab)."
    )
    return finde


def gesicht_finder(modell=None, mindestscore=None, quellen=GESICHT_QUELLEN,
                   tiefe_quellen=TIEFE_QUELLEN):
    """Folgt einem Gesicht — mit Gegenprobe aus der Tiefenkamera.

    Die Kameras schauen nach unten: mit waagrechtem Körper reicht das Bild bei
    1.5 m bis 1.20 m Höhe, bei 3 m bis 1.94 m — ein stehender Mensch hat je nach
    Grösse erst ab 2.3 bis 2.8 m ein Gesicht im Bild, näher sieht Spot Beine
    (gerechnet in `backends/real/gesicht.py`, am 16.09.2026 mit 150 Takten am
    Gerät bestätigt). Deshalb hebt `folge()` die Nase (`BLICK_GRAD`), und deshalb
    gehört dieser Finder mit einem zweiten
    zusammengeschaltet — `zuerst(gesicht_finder(), tag_finder())` nimmt das
    Gesicht, solange es eines gibt, und sonst das Tag.

    Ein Kasten mit hoher Punktzahl ist noch kein Gesicht: über dieselbe
    Aufzeichnung fand der Erkenner eine Stuhllehne und ein Schienbein. Was
    nicht auf Kopfhöhe liegt, fällt hier heraus.

    Teuer: vier Bilder je Takt. Der Regler läuft dadurch langsamer, und das ist
    in Ordnung — jedes Kommando trägt eine Endzeit, Spot fährt nicht blind
    weiter, wenn der Takt einmal hängt.
    """
    gemerkt = {}
    zuletzt = {"text": ""}

    def finde(spot):
        from spotlab.backends.real import gesicht as gesichtsmodul

        mit = folgeaufnahme.aktiv()
        aufnahme = gesichtsaufnahme(spot, gemerkt, quellen, tiefe_quellen,
                                    modell, mindestscore)
        if aufnahme is None:
            zuletzt["text"] = "keine Bilder (Kamera oder Tiefe fehlt)"
            return None
        sicht_nr = mit.sicht(aufnahme, "gesicht")
        erkenner_s = [0.0]

        def kaesten_gezeitet(feld, erkenner_):
            # YuNet und Gegenprobe getrennt: `beurteile` ruft beides in einem.
            beginn = time.perf_counter()
            try:
                return gesichtsmodul.kaesten(feld, erkenner_)
            finally:
                erkenner_s[0] += time.perf_counter() - beginn

        # `beurteile` statt `gesichter`: dasselbe Ergebnis, aber mit dem Urteil je
        # Kasten. Ohne das ist „kein Gesicht" nicht von „alle verworfen" zu
        # unterscheiden -- genau die Frage, die am 16.09.2026 offen blieb.
        beginn = time.perf_counter()
        befunde = gesichtsmodul.beurteile(
            aufnahme.feld, aufnahme.pano, aufnahme.erkenner, aufnahme.punkte,
            aufnahme.pano.kamerahoehe(aufnahme.blick_grad),
            blick_grad=aufnahme.blick_grad, kaesten_holen=kaesten_gezeitet,
        )
        mit.zeit_eintragen("yunet", erkenner_s[0])
        mit.zeit_eintragen("gesicht_probe", time.perf_counter() - beginn - erkenner_s[0])
        mit.gesichter(sicht_nr, befunde)
        zuletzt["text"] = _gesichtsbefund(befunde)
        kandidaten = [_ziel_aus_befund(b, aufnahme.pano, aufnahme.gier, aufnahme.ort)
                      for b in befunde if b.genommen]
        if not kandidaten:
            return None
        ziel = waehle_ziel(kandidaten)
        if ziel is None:
            zuletzt["text"] += ", keiner beim Merkpunkt (ein anderer Mensch?)"
        return ziel

    finde.befund = lambda: zuletzt["text"]
    finde.hinweis = (
        "Hinweis zu gesicht_finder(): er braucht OpenCV (`pip install \"spotlab[gesicht]\"`) "
        "und das YuNet-Modell aus dem OpenCV-Zoo in ~/.spotlab/modelle/ "
        "(face_detection_yunet). Fehlt eines davon, findet er NIE etwas; der genaue "
        "Grund steht in `diagnose.log` des Laufs."
    )
    return finde


def _ziel_aus_befund(kopf, pano, gier=None, ort=None):
    """Ein genommener Befund als Ziel — samt der Oberkante des Kastens im Bild.

    `pano.winkel` rechnet Spalte/Zeile in Peilung und Hoehenwinkel um, koerperfest.
    Genommen wird die OBERKANTE (Zeile y), nicht die Mitte: sie laeuft zuerst aus
    dem Bild, und auf sie regelt `folge()` die Nase.
    """
    x, y, breite, _hoehe = kopf.box
    _, oben = pano.winkel(x + breite / 2.0, y)
    return Ziel(kopf.bearing, kopf.distance, f"Gesicht auf {kopf.height:.2f} m",
                bild_oben=float(oben), gier=gier, ort=ort)


def _koerperbefund(befunde):
    """Was der Körper-Erkenner in diesem Takt sah — und was die Gegenprobe damit tat."""
    import collections

    if not befunde:
        return "kein Körper vom Erkenner"
    genommen = sum(1 for b in befunde if b.genommen)
    if genommen:
        return f"{len(befunde)} Körper, {genommen} genommen"
    gruende = collections.Counter(b.grund for b in befunde if b.grund)
    liste = ", ".join(f"{anzahl}× {grund}" for grund, anzahl in sorted(gruende.items()))
    return f"{len(befunde)} Körper, alle verworfen ({liste})"


def _gesichtsbefund(befunde):
    """Was der Erkenner in diesem Takt sah — und was die Gegenprobe damit tat.

    Die drei Fälle führen zu verschiedenen Schritten: kein Kasten heisst zu
    dunkel, zu weit oder das Gesicht liegt ausserhalb der Deckung; alle
    verworfen heisst, die Geometrie stimmt nicht (`zu tief` ist der häufigste
    Fall, und dann hockt oder liegt der Mensch); genommen heisst, es lag am
    Regler oder an einer Schranke.
    """
    import collections

    if not befunde:
        return "kein Kasten vom Erkenner"
    genommen = sum(1 for b in befunde if b.genommen)
    if genommen:
        return f"{len(befunde)} Kästen, {genommen} genommen"
    gruende = collections.Counter(b.grund for b in befunde if b.grund)
    liste = ", ".join(f"{anzahl}× {grund}" for grund, anzahl in sorted(gruende.items()))
    return f"{len(befunde)} Kästen, alle verworfen ({liste})"


@dataclass(frozen=True)
class Gesichtsaufnahme:
    """Alles, was eine Gesichtsprüfung in EINEM Takt braucht."""

    feld: object              # das zusammengesetzte Panorama (Farbe; Grau bei älteren Spots)
    pano: object              # die virtuelle Kamera dazu — rechnet Spalte/Zeile in Winkel
    erkenner: object          # YuNet, einmal gebaut
    punkte: object            # Nx3 Tiefenpunkte im aufgerichteten Körperrahmen
    blick_grad: float         # der GEMESSENE Nick, nach oben positiv
    gier: float = None        # der Gierwinkel (rad) beim Bild -- fuer `Ziel.gier`
    ort: tuple = None         # (x, y) des Roboters beim Bild (odom) -- fuer `Ziel.ort`


def bildaufnahme(spot, gemerkt, quellen=GESICHT_QUELLEN, tiefe_quellen=TIEFE_QUELLEN):
    """Vier Bilder holen und daraus Panorama und Punktwolke — oder None. OHNE Erkenner.

    Die gemeinsame Grundlage von Körper- und Gesichtsfinder. Der Körper-Weg
    braucht kein YuNet; ein fehlendes Gesichtsmodell darf ihn nicht mitreissen.

    `gemerkt` ist ein Wörterbuch, das der Aufrufer hält — das Panorama wird
    einmal gebaut und dann wiederverwendet.
    """
    import numpy as np

    from spotlab.backends.real import panorama, tiefe

    # ZWEI Anfragen, nicht eine: die Kameras in Farbe, die Tiefe nicht. Ein
    # RGB-Wunsch für ein Tiefenbild wird vom Roboter abgewiesen, und `images()`
    # merkt sich das als „keine Farbe möglich" für die ganze Sitzung — die Farbe
    # wäre still weg. Farbe deshalb, weil am 16.09.2026 dasselbe Bild durch beide
    # Wege lief (390 Takte): Farbe ohne Aufhellung fand jedes echte Gesicht, das
    # Grau mit Aufhellung fand, aber sieben Phantome weniger. Ein älterer Spot
    # ohne Farbkameras fällt in `images()` von selbst auf Grau zurück, und dort
    # greift die Aufhellung in `kaesten()` weiter.
    takt = _TAKT_BILDER.get()
    schluessel = (id(spot), tuple(quellen), tuple(tiefe_quellen))
    if takt is not None and schluessel in takt:
        return takt[schluessel]
    mit = folgeaufnahme.aktiv()
    with mit.zeit("bilder"):
        kameras, tiefe_antworten = _bilder_holen(spot, quellen, tiefe_quellen)
    nach_name = {a.source.name: a for a in list(kameras) + list(tiefe_antworten)}
    grau = [nach_name[q] for q in quellen if q in nach_name]
    tiefen = [nach_name[q] for q in tiefe_quellen if q in nach_name]
    if len(grau) < 2 or not tiefen:
        return None
    with mit.zeit("panorama"):
        if "pano" not in gemerkt:
            gemerkt["pano"] = panorama.Panorama(
                panorama.kalibrierung_aus(grau), zuschnitt=panorama.ALLES
            )
        feld = gemerkt["pano"].zusammensetzen(panorama.bilder_aus(grau))
    with mit.zeit("punkte"):
        punkte = np.vstack([tiefe.punkte_aus_bild(a) for a in tiefen])
    # Der GEMESSENE Nick, nicht der befohlene: so stimmt die Rechnung auch,
    # wenn Spot an einer Rampe steht oder unsere Neigung nicht ganz umsetzt.
    # `state.pitch` ist im Bogenmass, Nase hoch NEGATIV (Projektkonvention).
    # EINE Zustandsabfrage fuer Nick und Gier: beide gehoeren zu diesem Bild.
    with mit.zeit("lage"):
        nick, gier, ort = _volle_lage(spot)
    aufnahme = Gesichtsaufnahme(feld, gemerkt["pano"], None, punkte, -math.degrees(nick),
                                gier=gier, ort=ort)
    if takt is not None:
        takt[schluessel] = aufnahme
    return aufnahme


def _bilder_holen(spot, quellen, tiefe_quellen):
    """(Kameras, Tiefe) — die zwei Anfragen GLEICHZEITIG, nicht nacheinander.

    Zwei Anfragen bleiben es (siehe `bildaufnahme`: die Tiefe nie in Farbe), aber sie
    wissen nichts voneinander: gemessen 32 ms für die Farbbilder und 89 ms für die Tiefe
    (Lauf 20260925T125326Z), nacheinander also die Summe. Die Tiefe läuft in einem
    Faden, die Farbe hier; ein Fehler dort kommt über `result()` an wie einer hier.
    """
    with ThreadPoolExecutor(max_workers=1) as bote:
        tiefe = bote.submit(spot.backend.images, list(tiefe_quellen))
        kameras = spot.backend.images(list(quellen), farbe=True)
        return kameras, tiefe.result()


def gesichtsaufnahme(spot, gemerkt, quellen=GESICHT_QUELLEN,
                     tiefe_quellen=TIEFE_QUELLEN, modell=None, mindestscore=None):
    """`bildaufnahme` plus der YuNet-Erkenner, einmal gebaut und dann wiederverwendet.

    Die gemeinsame Vorbereitung von `gesicht_finder` und der Messprobe
    (`workshop/gesichtsprobe.py`). EINE Formulierung: sonst misst die Probe
    etwas anderes, als der Folgemodus tut, und das fiele erst am Gerät auf.
    """
    from dataclasses import replace

    from spotlab.backends.real import gesicht as gesichtsmodul

    aufnahme = bildaufnahme(spot, gemerkt, quellen, tiefe_quellen)
    if aufnahme is None:
        return None
    if "erkenner" not in gemerkt:
        gemerkt["erkenner"] = gesichtsmodul.erkenner(
            aufnahme.pano.breite, aufnahme.pano.hoehe, modell,
            mindestscore or gesichtsmodul.MINDESTSCORE,
        )
    return replace(aufnahme, erkenner=gemerkt["erkenner"])


def _nick(spot):
    """Der gemessene Nickwinkel des Körpers in RAD — 0.0, wenn nicht lesbar."""
    return _lage(spot)[0]


def _lage(spot):
    """(Nick, Gier) des Körpers in RAD aus EINER Zustandsabfrage — (0.0, None), wenn nicht lesbar.

    Der Nick ohne Wert ist 0.0 (die Rechnung läuft dann flach weiter), die Gier
    ohne Wert ist None: ohne sie wird nicht nachgeführt, und das darf man wissen.
    """
    return _volle_lage(spot)[:2]


def _volle_lage(spot):
    """(Nick, Gier, Ort) aus EINER Zustandsabfrage — Ort ist (x, y) aus `state.pose` (odom).

    Wie bei `_lage`: ohne Wert ist der Nick 0.0, Gier und Ort sind None. Ohne Ort
    gibt es keinen Merkpunkt (`workshop/merkpunkt.py`), gefolgt wird wie bisher.
    """
    try:
        zustand = spot.state
    except Exception:
        return 0.0, None, None
    try:
        nick = float(zustand.pitch)
    except Exception:
        nick = 0.0
    try:
        gier = float(zustand.pose[2])
    except Exception:
        gier = None
    try:
        ort = (float(zustand.pose[0]), float(zustand.pose[1]))
    except Exception:
        ort = None
    if ort is not None and not all(_endlich(w) for w in ort):
        ort = None
    # Ein NaN rechnet sich ueberall hindurch, ohne je aufzufallen: kein Wert statt eines falschen.
    return (nick if _endlich(nick) else 0.0), (gier if _endlich(gier) else None), ort


def _endlich(wert):
    """Eine endliche Zahl? NaN, inf, None und Nicht-Zahlen sind es nicht."""
    try:
        return math.isfinite(float(wert))
    except (TypeError, ValueError):
        return False


def _gepruefter(ziel):
    """(Ziel oder None, was daran ungültig war) — ein Ziel mit NaN oder inf ist KEIN Ziel.

    Befund p09 (22.09.2026): `befehl(Ziel(0, nan))` gab Vollgas, weil jeder
    Vergleich mit NaN falsch ist — und damit lief ein Finder mit ungültigem Abstand
    am Mindestabstand vorbei. Peilung oder Abstand ungültig heisst hier: kein Ziel,
    also stehen, und es zählt nicht als gesehen (sonst hielte der Nachlauf es fest).
    Eine ungültige Oberkante oder Gier fällt nur weg: ohne sie wird die Nase nicht
    geregelt und die Peilung nicht nachgeführt, gefolgt wird trotzdem.
    """
    if ziel is None:
        return None, ""
    if not (_endlich(ziel.bearing) and _endlich(ziel.distance)):
        return None, f"Peilung {ziel.bearing}, Abstand {ziel.distance}"
    from dataclasses import replace

    weg = {feld: None for feld in ("bild_oben", "gier")
           if getattr(ziel, feld) is not None and not _endlich(getattr(ziel, feld))}
    if not weg:
        return ziel, ""
    text = ", ".join(f"{feld} {getattr(ziel, feld)}" for feld in weg)
    return replace(ziel, **weg), text


def _gier(spot):
    """Der Gierwinkel (rad) JETZT — oder None."""
    return _lage(spot)[1]


def _wickle(rad):
    """Einen Winkel auf (-pi, pi] bringen — von +170 nach -170 Grad sind +20 gedreht."""
    return (rad + math.pi) % (2.0 * math.pi) - math.pi


def nachgefuehrt(ziel, gier_jetzt):
    """Das Ziel mit der Peilung von JETZT: was Spot seit dem Bild gedreht hat, ist abgezogen.

    Ohne Gier am Ziel (Tag, Tracker) oder ohne lesbare Gier jetzt bleibt es, wie es ist.
    """
    if ziel is None or ziel.gier is None or gier_jetzt is None:
        return ziel
    from dataclasses import replace

    gedreht = math.degrees(_wickle(float(gier_jetzt) - float(ziel.gier)))
    return replace(ziel, bearing=ziel.bearing - gedreht)


def waehle_ziel(kandidaten):
    """Welcher der gesehenen Menschen ist das Ziel? Das Ziel oder None.

    In `folge()` entscheidet der Merkpunkt — er bleibt bei dem Menschen, dem Spot
    folgt, auch wenn ein anderer näher steht, und sagt None, wenn keiner dort steht,
    wo er ihn erwartet. Ausserhalb von `folge()` ist es der nächste, wie bisher.
    """
    kandidaten = list(kandidaten)
    wahl = _WAHL.get()
    if wahl is not None:
        return wahl(kandidaten)
    return min(kandidaten, key=lambda z: z.distance) if kandidaten else None


def zuerst(*finder):
    """Der erste Finder, der etwas findet, gewinnt.

    Damit lassen sich Strategien staffeln statt zu wählen: das Gesicht, solange
    es sichtbar ist, und darunter das Tag — genau die Lücke, die die Geometrie
    der Frontkameras aufmacht.

    Ein Finder, der WIRFT, hält die Staffel nicht auf: fehlt OpenCV oder das
    Gesichtsmodell, soll das Tag weiter funktionieren. Der Grund steht einmal
    im Protokoll — still übergehen wäre schlimmer als gar nicht staffeln.
    """
    gemeldet = set()

    def finde(spot):
        # Eine Staffel ist EIN Takt: alle Finder sehen dieselben Bilder (`_TAKT_BILDER`).
        marke = _TAKT_BILDER.set({})
        try:
            for nummer, einer in enumerate(finder):
                try:
                    ziel = einer(spot)
                except Exception as fehler:
                    if nummer not in gemeldet:
                        from spotlab import protokoll

                        gemeldet.add(nummer)
                        protokoll.notiere(f"Finder {nummer} faellt aus: {fehler}")
                    continue
                if ziel is not None:
                    return ziel
            return None
        finally:
            _TAKT_BILDER.reset(marke)

    # Hinweise UND Befunde der Mitglieder wandern mit: sonst verschwände
    # ausgerechnet beim Staffeln die Auskunft, warum ein Finder nichts liefert --
    # und dort ist die Frage erst recht offen, welcher der beiden schwieg.
    finde.hinweis = "\n".join(
        h for h in (getattr(einer, "hinweis", "") for einer in finder) if h
    )
    finde.befund = lambda: " · ".join(b for b in (_befund(e) for e in finder) if b)
    # Und die Sicht des Koerper-Finders, damit `gesten_leser(staffel)` geht.
    mit_sicht = [einer for einer in finder if callable(getattr(einer, "letzte", None))]
    finde.letzte = lambda: next((s for s in (e.letzte() for e in mit_sicht) if s is not None), None)
    return finde


def _befund(finder):
    """Was der Finder zuletzt gesehen hat — leer, wenn er nichts dazu sagt.

    Eine Auskunft über den Zustand darf den Zustand nie verändern und erst recht
    keinen fahrenden Roboter anhalten: ein Finder, der beim Erzählen stolpert,
    bleibt stumm statt zu werfen.
    """
    holen = getattr(finder, "befund", None)
    if holen is None:
        return ""
    try:
        return str(holen() or "")
    except Exception:
        return ""


# ------------------------------------------------------------ Handzeichen


def gesten_leser(finder, ordner=None, haende_holen=None, jeder=GESTEN_JEDER_TAKT,
                 takte=GESTEN_TAKTE):
    """Ein Leser `lies(spot) -> "halt" | "weiter" | None` für `folge(gesten=…)`.

    Er hängt am KÖRPER-Finder (oder einer Staffel, die einen enthält): gelesen
    wird die Hand im Rumpf-Ausschnitt des Menschen, dem Spot gerade folgt —
    aus dem Bild, das der Finder in diesem Takt schon geholt hat, ohne zweiten
    Kameraabruf. Gemessen am 16.09.2026 über 510 Panoramen: auf dem ganzen
    Bild fand die Handpose keine Hand, im Rumpf-Ausschnitt 31. Und nur dort
    ist die Frage sinnvoll — die Geste eines Zuschauers zählt nicht.

    Drei Regeln, alle gegen erfundene Zeichen: eine Sicht wird nur EINMAL
    gelesen (der Finder lief nicht, weil ein Tag vorher gewann → kein altes
    Bild zweimal); gelesen wird jeden `jeder`-ten Takt mit Körper, die
    übersprungenen zählen nicht; ein Takt OHNE Körper setzt die Zählung
    zurück. Ein Zeichen kommt erst nach `takte` Lesungen hintereinander, und
    dann genau einmal (`gesten.Entprellung`).

    `haende_holen(feld, ausschnitt)` ist die Testtür; ohne sie wird der
    `Handerkenner` beim ersten Lesen gebaut — fehlen die Modelle, kommt dort
    ein `SpotlabError`, und `folge()` sagt es einmal und folgt ohne Zeichen.
    """
    from spotlab.backends.real import gesten as gestenmodul

    letzte = getattr(finder, "letzte", None)
    if not callable(letzte):
        raise ValueError("gesten_leser() braucht den Körper-Finder (oder eine Staffel damit): "
                         "nur dort gibt es eine Sicht, in der die Hand zu lesen ist.")
    erkenner = {}
    stand = {"gelesen": 0, "takte": 0}
    entprellung = gestenmodul.Entprellung(takte)

    def holen_vorgabe(feld, ausschnitt):
        if "erkenner" not in erkenner:
            erkenner["erkenner"] = gestenmodul.Handerkenner(ordner=ordner)
        return erkenner["erkenner"].finde(feld, ausschnitt=ausschnitt)

    holen = haende_holen or holen_vorgabe

    def lies(spot):
        sicht = letzte()
        if sicht is None:
            entprellung.naechste(None)          # kein Koerper: von vorn
            return None
        if sicht.nummer == stand["gelesen"]:
            return None                         # dasselbe Bild schon gelesen
        stand["gelesen"] = sicht.nummer
        stand["takte"] += 1
        if stand["takte"] % max(int(jeder), 1):
            return None
        feld = sicht.aufnahme.feld
        hoehe, breite = feld.shape[:2]
        ausschnitt = gestenmodul.rumpf_ausschnitt(sicht.koerper, breite=breite, hoehe=hoehe)
        if ausschnitt is None:
            return entprellung.naechste(None)
        return entprellung.naechste(gestenmodul.geste_der_haende(holen(feld, ausschnitt)))

    return lies


# ---------------------------------------------------------------- Schranken


def _lage_im_gitter(spot):
    """(x, y, Gier in RAD) des Körpers im Rahmen „vision" — dem Rahmen des Hindernisgitters.

    NICHT `spot.state.pose`: die ist „odom". Am echten Spot kommt das Gitter im
    Rahmen „vision" (`backends/real/wahrnehmung.py::gitter_aus`), und die beiden
    Rahmen driften auseinander — mit der odom-Lage prüft die Schranke einen Strahl
    NEBEN dem Weg (Befund p16, 22.09.2026: Kiste 0.9 m voraus, Rahmen 0.6 m
    auseinander, die Schranke gab frei). Im Trockenlauf und in den Sims sind beide
    gleich, deshalb fiel es dort nie auf. Dieselbe Rechnung wie `spot.look()`.
    Wirft, wenn der Rahmenbaum keine Lage in „vision" hat — die Schranke macht
    daraus „nicht lesbar", also Stehen.
    """
    from bosdyn.client.frame_helpers import BODY_FRAME_NAME, VISION_FRAME_NAME, get_a_tform_b

    lage = get_a_tform_b(spot.backend.frame_tree_snapshot(), VISION_FRAME_NAME, BODY_FRAME_NAME)
    if lage is None:
        raise SpotlabError("kein Rahmen vision/body für das Hindernisgitter")
    q = lage.rotation
    gier = math.atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z))
    return float(lage.x), float(lage.y), gier


def frei_voraus(spot, meter=FREIRAUM_M):
    """(darf fahren, Grund). Fail-closed: kein Gitter heisst kein Vorwärts.

    Die Lage kommt aus dem Rahmen des Gitters (`_lage_im_gitter`), nicht aus
    `spot.state.pose` — siehe dort.
    """
    try:
        gitter = spot.obstacles()
        x, y, gier = _lage_im_gitter(spot)
        frei = gitter.free_distance(x, y, math.degrees(gier))
    except Exception as fehler:
        return False, f"Hindernisgitter nicht lesbar ({fehler})"
    if not frei >= meter:                 # auch NaN heisst: nicht frei
        return False, f"nur {frei:.1f} m frei voraus"
    return True, ""


def kopfraum_frei(spot, meter=KOPFRAUM_M, quellen=("frontleft_depth", "frontright_depth")):
    """(darf fahren, Grund) — hängt etwas über dem Weg? Fail-closed.

    Das Hindernisgitter ist eine BODENkarte; eine Tischplatte in 75 cm Höhe
    steht nicht darin. Genau dort ist der Explorer am 07.09.2026 hineingefahren.
    """
    from spotlab.backends.base import Capability
    from spotlab.backends.real import tiefe

    backend = getattr(spot, "backend", None)
    if backend is None or not (backend.capabilities() & Capability.DEPTH_CAMERAS):
        return True, ""                      # kein Tiefensinn: die Schranke gibt es nicht
    try:
        punkte = tiefe.ueberhang_aus_bildern(backend.images(list(quellen)))
        weite = tiefe.kopfraum(punkte)
    except Exception as fehler:
        return False, f"Tiefenbild nicht lesbar ({fehler})"
    if weite is not None and weite <= meter:
        return False, f"Überhang {weite:.2f} m voraus"
    return True, ""


def zone_voraus(spot, raum, strecke=ZONE_VORAUS_M):
    """(darf fahren, Grund) — liegt eine eingezeichnete Sperrzone davor?

    Nur mit einem Raum, der seine Karte kennt, UND einer Verortung. Fehlt eines
    davon, gibt es die Schranke nicht — und `folge()` sagt das einmal, statt
    Sicherheit vorzutäuschen.
    """
    from spotlab.welt import kollision
    from spotlab.welt import raum as raummodul

    if raum is None or not raum.sperrzonen:
        return True, ""
    lage = spot.map_pose()
    if lage is None:
        return False, "nicht auf der Karte verortet"
    im_raum = raummodul.aus_karte(raum, lage[0], lage[1], lage[2])
    if im_raum is None:
        return False, "der Raum kennt seine Karte nicht"
    name = kollision.zone_voraus(raum, im_raum, strecke)
    if not name:
        return True, ""
    # Der Grund steht dabei: „Sperrzone glasfront voraus" sagt einem Menschen
    # weniger als „…(Glasfront, kein Sensor sieht sie)".
    zone = next((z for z in raum.sperrzonen if z.name == name), None)
    grund = f" ({zone.grund})" if zone is not None and zone.grund else ""
    return False, f"Sperrzone {name}{grund} voraus"


# ------------------------------------------------------------------ Regler


def tempo_deckel(abstand):
    """Das Höchsttempo bei diesem Abstand: MAX_TEMPO_M_S nah, bis MAX_TEMPO_WEIT_M_S weit weg."""
    anteil = (float(abstand) - WEIT_AB_M) / (WEIT_VOLL_M - WEIT_AB_M)
    anteil = min(1.0, max(0.0, anteil))
    return MAX_TEMPO_M_S + anteil * (MAX_TEMPO_WEIT_M_S - MAX_TEMPO_M_S)


def vorausschau_m(vx):
    """So viel weiter voraus als sonst prüfen die Schranken bei diesem Tempo (0 bis MAX_TEMPO_M_S)."""
    return max(0.0, float(vx) - MAX_TEMPO_M_S) * VORAUS_JE_TEMPO_S


def befehl(ziel, wunsch=WUNSCH_ABSTAND_M, mindest=MIN_ABSTAND_M, toleranz=TOLERANZ_M,
           takt_s=None, weg_tempo=0.0):
    """(vx, wz) aus Peilung und Abstand — ohne Roboter prüfbar.

    `weg_tempo` ist, wie schnell sich der Mensch entfernt (m/s, auf Spot zu negativ,
    aus dem Merkpunkt): es kommt zum Tempo dazu, damit Spot Schritt hält, statt
    hinterherzuhinken — und kommt der Mensch näher, bremst es. Gedeckelt wird nach
    Abstand (`tempo_deckel`): nah wie bisher 0.5 m/s, weit weg bis 1.0.

    Rückwärts gibt es nicht: nach hinten sieht Spot nichts. Ist der Mensch zu
    nah, bleibt er stehen und dreht sich höchstens mit.

    `takt_s` ist die Zeit, die Spot bis zum nächsten Blick blind dreht. Wer 0.6 s
    nicht hinschaut, darf in der Zeit nicht weiter drehen, als das Ziel entfernt
    ist — sonst liegt es danach auf der anderen Seite, und er dreht zurück.

    Eine Peilung oder ein Abstand, die keine endliche Zahl sind (NaN, inf), heissen
    STEHEN: (0.0, 0.0). Mit NaN ist jeder Vergleich falsch, und ohne diese Zeile
    wurde aus `Ziel(0, nan)` Vollgas (p09, 22.09.2026).
    """
    if not (_endlich(ziel.bearing) and _endlich(ziel.distance)):
        return 0.0, 0.0
    drehrate = min(MAX_DREHRATE_GRAD, abs(LENKUNG * ziel.bearing))
    if takt_s:
        drehrate = min(drehrate, ANTEIL_JE_TAKT * abs(ziel.bearing) / float(takt_s))
    if abs(ziel.bearing) < PEILUNG_TOTBAND_GRAD:
        drehrate = 0.0                       # Totband: um null nicht zappeln
    wz = math.radians(math.copysign(drehrate, ziel.bearing)) if drehrate else 0.0
    if abs(ziel.bearing) > SCHWENK_GRAD:
        return 0.0, wz                       # erst die Nase hin, dann gehen
    fehler = ziel.distance - wunsch
    if fehler <= toleranz or ziel.distance <= mindest:
        return 0.0, wz
    weg = float(weg_tempo) if _endlich(weg_tempo) else 0.0
    return max(0.0, min(tempo_deckel(ziel.distance), ANNAEHERUNG * fehler + weg)), wz


def folge(spot, finder=None, raum=None, melde=print, jetzt=time.monotonic,
          schlaf=time.sleep, takt_s=TAKT_S, laeuft=None, lauf_dir=None,
          kopfraum_takt_s=KOPFRAUM_TAKT_S, blick_grad=BLICK_GRAD, nachlauf_s=NACHLAUF_S,
          gesten=None, licht=None, aufnahme=None, halten_s=merkpunkt.HALTEN_S):
    """Die Schleife: Ziel suchen, Abstand halten, bei jeder Schranke stehen bleiben.

    DER MERKPUNKT (27.09.2026, `workshop/merkpunkt.py`): trägt das Ziel seinen Ort
    (`Ziel.ort`, der Körper- und der Gesichtsfinder tun es), merkt sich Spot den
    Menschen als Punkt im Raum. Sieht er ihn nicht, gilt der Punkt `halten_s` lang
    weiter — Peilung und Abstand rechnen sich aus Spots eigener Fahrt, und läuft der
    Mensch seitlich weg, zeigt der Punkt eine Sekunde in seine Laufrichtung voraus.
    Blind FAHREN darf Spot nur den Nachlauf lang (`nachlauf_s`), danach dreht er nur
    noch mit (Zustand `haelt`), und ist der Punkt abgelaufen, steht er und sucht.
    Sieht der Finder mehrere Menschen, nimmt Spot den beim Punkt (`waehle_ziel`),
    nicht den nächsten. Ein Ziel ohne Ort (Tag) hält wie bisher den Nachlauf.

    `aufnahme=True` schreibt je Takt mit, was Spot sah und tat
    (`workshop/folgeaufnahme.py`: Panorama, Tiefe, jeder Körper und jedes
    Gesicht mit Urteil, Ziel, Befehl, Zeiten je Schritt) nach `<lauf>/folgen/`,
    in den Lauf von `lauf_dir` oder des Schreibers; eine `Folgeaufnahme` geht
    auch. Sie bremst keinen Takt, ein Schreibfehler wird einmal gesagt.

    `gesten` ist ein Leser `gesten(spot) -> "halt" | "weiter" | None`
    (`gesten_leser`). Die offene Hand hält Spot an — er steht, dreht nicht
    mit, hält aber die Nase auf den Menschen; der Daumen hoch lässt ihn
    weitergehen. Ein Zeichen ist KEIN Fahrbefehl: es nimmt nur weg oder gibt
    zurück, was das Folgen ohnehin tut — ohne Ziel steht er trotzdem, und jede
    Schranke gilt nach einem „weiter" wie vorher. Fehlen die Handmodelle
    (`SpotlabError` beim ersten Lesen), sagt er es einmal und folgt ohne
    Zeichen; ein stolpernder Leser wird einmal gemeldet und weiter gefragt.
    Jedes gezählte Zeichen steht als Ereignis `geste` in der Aufzeichnung.

    `licht` sind die LEDs am Kopf: gelb sucht, blau folgt, rot heisst „per
    Handzeichen angehalten". Das ist die Rückmeldung für den Menschen DAVOR —
    ohne sie sieht niemand, ob sein Zeichen angekommen ist, sondern nur einen
    stehenden Roboter, und der steht aus vielen Gründen. `licht=False` schaltet
    sie ab, `None` baut sie selbst (und lässt sie weg, wo es keine gibt). Ein
    Fehler am Licht hält den Lauf nie an: es wird einmal gesagt und weiter
    gefolgt. Und das Licht verlangsamt keinen Takt: `Statuslicht` schickt über
    einen Boten, und am Ende hält Spot ZUERST an, dann gehen die LEDs aus.

    `blick_grad` hebt die Nase während der Fahrt, damit die Kameras höher
    schauen — positiv, in Grad. Damit kommt ein stehendes Gesicht schon auf
    Folgeabstand ins Bild statt erst ab zweieinhalb Metern. Der Preis: der Boden
    dicht vor den Füssen fällt aus dem Blickfeld, und das ist genau der Bereich,
    in dem die Hindernisschranke prüft. Die Vorgabe ist `BLICK_GRAD` (15 seit dem
    16.09.2026, siehe dort); `blick_grad=0` ist der alte, flache Weg.

    Auch im STEHEN bleibt die Neigung: sonst legt Spot die Nase ab, sobald er im
    Wunschabstand ist, verliert das Gesicht und pendelt zwischen Suchen und
    Fahren. Ein Kommando mit Tempo null hält die Lage; es verfällt wie jedes
    andere nach rund einer Sekunde.

    WENN NICHTS KOMMT, sagt er es — wiederholt, unterschieden und aufgeschrieben.
    Ein stehender Spot sieht aus wie ein hängendes Programm, deshalb meldet die
    Schleife die Stille alle `STILLE_TAKT_S`, trennt „noch kein Ziel" von „Ziel
    verloren", gibt den `hinweis` des Finders einmal aus und schreibt das
    Ereignis `kein_ziel` in die Aufzeichnung.

    Testbar ohne Roboter: `spot` braucht `walk` und `stop`, dazu was der Finder
    und die Schranken abfragen. Am Ende hält Spot immer.
    """
    blick_grad = max(0.0, min(MAX_BLICK_GRAD, float(blick_grad)))
    if blick_grad and not getattr(getattr(spot, "backend", None), "neigt_beim_gehen", False):
        melde("Dieses Backend neigt sich beim Gehen nicht — der Blickwinkel bleibt flach.")
        blick_grad = 0.0
    neigung = blick_grad        # geregelt, sobald ein Gesicht seine Oberkante meldet
    nick = -neigung             # Projektkonvention: Nase hoch ist negativ
    finder = finder or tag_finder()
    if laeuft is None:
        if lauf_dir is None:
            raise ValueError("folge() braucht `lauf_dir` oder `laeuft`.")
        stopp = Path(lauf_dir) / STOPP_DATEI

        def laeuft():
            return not stopp.exists()

    # VOR dem ersten Befehl: ohne Ablage gibt es keine Aufnahme, und das soll man
    # wissen, bevor der Roboter losgeht -- nicht nach dem Lauf.
    aufnahme = _aufnahme_fuer(spot, aufnahme, lauf_dir)
    mit = aufnahme if aufnahme else folgeaufnahme.aktiv()
    aufnahme_gemeldet = False

    def aufnahme_melden():
        """Einen Schreibfehler der Aufnahme EINMAL sagen -- er haelt nie den Roboter an."""
        nonlocal aufnahme_gemeldet
        if aufnahme and aufnahme.fehler and not aufnahme_gemeldet:
            aufnahme_gemeldet = True
            melde(f"Die Folge-Aufnahme schreibt nicht ({aufnahme.letzter_fehler}) — "
                  f"Spot folgt weiter, die Aufnahme ist lückenhaft.")

    zuletzt_gesehen = jetzt()
    je_gesehen = False              # hatte er ueberhaupt je ein Ziel?
    stille_gemeldet = None          # wann zuletzt ueber die Stille berichtet wurde
    hinweis_gesagt = False
    schreibfehler_gemeldet = False
    letzter_grund = ""
    kopfraum = (True, "")
    kopfraum_geprueft = None
    faehrt = False
    takt_beginn = None          # wann der letzte Takt begann: so lange dreht Spot blind
    letztes_ziel = None         # fuer den Nachlauf: das zuletzt ECHT gesehene Ziel
    merk = merkpunkt.Merkpunkt(halten_s=halten_s)
    angehalten = False          # per Handzeichen -- bis zum Daumen hoch
    gesten_stolpern_gemeldet = False
    licht_stolpern_gemeldet = False
    ungueltig_gemeldet = False  # ein Finder mit NaN/inf -- einmal gesagt, nicht je Takt
    if licht is None:
        from spotlab.api.signals import Statuslicht

        licht = Statuslicht(spot)

    def licht_melden(ausnahme=None):
        """Einen Fehler am Licht EINMAL sagen -- geworfen oder vom Licht gezaehlt."""
        nonlocal licht_stolpern_gemeldet
        if licht_stolpern_gemeldet:
            return
        if ausnahme is not None:
            grund = f"{type(ausnahme).__name__}: {ausnahme}"
        elif getattr(licht, "fehler", 0):
            grund = str(getattr(licht, "letzter_fehler", "") or "Fehler ohne Text")
        else:
            return
        licht_stolpern_gemeldet = True
        melde(f"Das Licht am Kopf geht nicht ({grund}) — Spot folgt weiter, nur ohne Farbe.")

    def zeige(farbe):
        """Die LEDs sind eine Beigabe: ein Fehler daran haelt nie den Regler an.

        `Statuslicht` wirft nicht, es ZAEHLT (`fehler`, `letzter_fehler`) -- bis zum
        22.09.2026 wartete dieser Zweig auf eine Ausnahme, die nie kam, und ein
        kaputtes Licht blieb stumm (p07). Ein selbstgebautes Licht darf auch werfen.
        `setze` blockiert nicht: die Anfragen an den Roboter gehen ueber einen Boten.
        """
        if not licht:
            return
        try:
            licht.setze(farbe)
        except Exception as fehler:
            licht_melden(fehler)
            return
        licht_melden()
    gier_vorher = None          # die Gier beim letzten Befehl: so viel hat er seither gedreht
    seitlich_gedreht = 0.0      # Grad gedreht, seit das Ziel zuletzt VOR ihm war (Kreissperre)
    drehsperre = False
    ziel_gemeldet = False       # ob der letzte Takt ein Ziel hatte (fuer die Zeile `weg`)

    stapel = contextlib.ExitStack()
    try:
        if aufnahme:
            # Finder und Bildaufnahme schreiben ueber `folgeaufnahme.aktiv()` mit.
            stapel.enter_context(aufnahme.aktiviert())
        while laeuft():
            nun = jetzt()
            takt_dauer = max(takt_s, nun - takt_beginn) if takt_beginn is not None else takt_s
            takt_beginn = nun
            mit.takt_beginnt()
            wahl_marke = _WAHL.set(lambda kandidaten, t=nun: merk.waehle(t, kandidaten))
            try:
                roh = _sicher(finder, spot)
            finally:
                _WAHL.reset(wahl_marke)
            ziel, ungueltig = _gepruefter(roh)
            if ungueltig and not ungueltig_gemeldet:
                ungueltig_gemeldet = True
                was = ("Spot behandelt das als „kein Ziel“ und bleibt stehen" if ziel is None
                       else "der Wert fällt weg, gefolgt wird ohne ihn")
                melde(f"{getattr(roh, 'name', 'Ziel')}: ungültige Zahl vom Finder ({ungueltig}) "
                      f"— {was}. Den Finder prüfen.")
            echt = ziel is not None
            if echt:
                merk.aufnehmen(nun, ziel)      # ohne Ort (Tag) vergisst er den Punkt

            if gesten is not None:
                # Direkt nach dem Finder: der Leser nimmt dessen Bild aus DIESEM Takt.
                geste = None
                try:
                    with mit.zeit("gesten"):
                        geste = gesten(spot)
                except SpotlabError as fehler:
                    gesten = None
                    melde(f"Gesten aus — {fehler} Spot folgt ohne Gesten weiter.")
                except Exception as fehler:
                    if not gesten_stolpern_gemeldet:
                        gesten_stolpern_gemeldet = True
                        melde(f"Der Gestenleser stolpert ({type(fehler).__name__}: {fehler}) "
                              f"— Spot folgt weiter, das Zeichen kommt vielleicht später an.")
                if geste is not None:
                    mit.geste(geste)
                    angehalten, text = _geste_wirkt(geste, angehalten)
                    melde(text)
                    fehlschlag = _notiere_geste(spot, geste, angehalten)
                    if fehlschlag and not schreibfehler_gemeldet:
                        schreibfehler_gemeldet = True
                        melde(f"Die Geste liess sich nicht aufzeichnen: {fehlschlag}")
            if not echt and letztes_ziel is not None:
                if merk.aktiv(nun):
                    # Der Merkpunkt haelt ihn fest; wo er steht, rechnet unten
                    # `merk.ziel` aus Spots eigener Lage -- alle Schranken gelten.
                    ziel = letztes_ziel
                elif letztes_ziel.ort is None and nun - zuletzt_gesehen < nachlauf_s:
                    # Nachlauf fuer Ziele ohne Ort (Tag): aus dem letzten Ziel weiter.
                    ziel = letztes_ziel
            if ziel is None:
                zeige(LICHT_ANGEHALTEN if angehalten else LICHT_SUCHT)
                if faehrt:
                    with mit.zeit("stop"):
                        spot.stop()
                    faehrt = False
                if ziel_gemeldet:
                    # EINMAL "weg", nicht jeden leeren Takt -- die Lehre der 135 world_objects.
                    ziel_gemeldet = False
                    fehlschlag = _notiere_ziel(spot, None)
                    if fehlschlag and not schreibfehler_gemeldet:
                        schreibfehler_gemeldet = True
                        melde(f"Das Ziel liess sich nicht aufzeichnen: {fehlschlag}")
                # Ohne Ziel gibt es nichts, dem er nachdrehen koennte: die Sperre faellt.
                seitlich_gedreht, drehsperre, gier_vorher = 0.0, False, None
                if blick_grad:
                    # SUCHHALTUNG: die Neigung muss VOR dem ersten Ziel da sein.
                    # Bis zum 16.09.2026 kam sie nur mit einem Fahrbefehl, und den
                    # gab es nur mit Ziel -- mit flacher Nase sah Spot keinen
                    # aufrecht stehenden Menschen und fand deshalb nie eines
                    # (drei Laeufe, null Fahrbefehle, Nick null). Tempo null:
                    # er steht, das Kommando verfaellt wie jedes andere.
                    with mit.zeit("walk"):
                        spot.walk(vx=0.0, vy=0.0, wz=0.0, stop=False, nick_grad=nick)
                mit.befehl(0.0, 0.0, nick if blick_grad else 0.0, angehalten=angehalten)
                nun = jetzt()
                seit = nun - zuletzt_gesehen
                faellig = stille_gemeldet is None or nun - stille_gemeldet >= STILLE_TAKT_S
                if seit >= VERLOREN_S and faellig:
                    stille_gemeldet = nun
                    befund = _befund(finder)
                    melde(_stille(je_gesehen, seit) + (f"  ({befund})" if befund else ""))
                    if not hinweis_gesagt:
                        hinweis_gesagt = True
                        hinweis = getattr(finder, "hinweis", "")
                        if hinweis:
                            melde(hinweis)
                    fehlschlag = _notiere_stille(spot, seit, je_gesehen, befund)
                    if fehlschlag and not schreibfehler_gemeldet:
                        schreibfehler_gemeldet = True
                        melde(f"Die Stille liess sich nicht aufzeichnen: {fehlschlag}")
                mit.takt_endet("angehalten" if angehalten else "sucht")
                aufnahme_melden()
                schlaf(_rest(takt_s, takt_beginn, jetzt))
                continue

            if echt:
                if stille_gemeldet is not None:
                    # „wieder da" nur, wenn er wirklich schon einmal da war.
                    melde(f"{ziel.name} {'wieder da' if je_gesehen else 'gefunden'}.")
                # Nur ein ECHTES Ziel zaehlt als gesehen -- ein gehaltenes
                # verlaengerte sonst seinen eigenen Nachlauf, und er hielte nie.
                zuletzt_gesehen, stille_gemeldet = jetzt(), None
                je_gesehen = True
                letztes_ziel = ziel
                if blick_grad and ziel.bild_oben is not None:
                    # Nur auf ECHTE Kaesten regeln: ein gehaltenes Ziel ist kein gesehenes.
                    neigung = _neigung_nach(neigung, ziel.bild_oben)
                    nick = -neigung
            # NACHFUEHREN: das Bild ist beim Befehl einen halben Takt alt, und der
            # vorige Befehl lief die ganze Zeit weiter. Abgezogen wird, was Spot seit
            # dem Bild GEMESSEN gedreht hat -- auch im Nachlauf, sonst drehte er blind
            # dem alten Winkel nach (17.09.2026: 35 Drehsinn-Wechsel in 100 s).
            with mit.zeit("gier"):
                _, gier_jetzt, ort_jetzt = (_volle_lage(spot) if ziel.gier is not None
                                            else (0.0, None, None))
            weg_tempo = 0.0
            gemerkt = (ziel.ort is not None and merk.aktiv(nun) and gier_jetzt is not None
                       and ort_jetzt is not None)
            if gemerkt:
                # Aus dem Punkt im Raum: Drehung UND Fahrt seit dem Bild sind heraus.
                ziel_jetzt = merk.ziel(nun, ort_jetzt, gier_jetzt, ziel)
                weg_tempo = merk.weg_tempo(ort_jetzt)
            else:
                ziel_jetzt = nachgefuehrt(ziel, gier_jetzt)
            # Blind FAHREN nur den Nachlauf lang; danach dreht er nur noch mit.
            nur_drehen = not echt and nun - zuletzt_gesehen >= nachlauf_s
            mit.ziel(ziel, ziel_jetzt, echt=echt)
            mit.merkpunkt(merk.bericht(nun))
            # KREISSPERRE: seit das Ziel zuletzt vor ihm war, so viel gedreht?
            if abs(ziel_jetzt.bearing) <= SCHWENK_GRAD:
                seitlich_gedreht, drehsperre = 0.0, False
            elif gier_jetzt is not None and gier_vorher is not None:
                seitlich_gedreht += abs(math.degrees(_wickle(gier_jetzt - gier_vorher)))
                if seitlich_gedreht >= MAX_SUCHDREHUNG_GRAD and not drehsperre:
                    drehsperre = True
                    melde(f"Spot hat sich {seitlich_gedreht:.0f}° gedreht, und das Ziel blieb "
                          f"seitlich — das ist kein Mensch. Er dreht nicht weiter, bis etwas "
                          f"vor ihm ist.")
            gier_vorher = gier_jetzt
            vx, wz = befehl(ziel_jetzt, takt_s=takt_dauer, weg_tempo=weg_tempo)
            if nur_drehen:
                vx = 0.0
            if drehsperre:
                vx, wz = 0.0, 0.0
            if (blick_grad and ziel.bild_oben is not None
                    and neigung >= MAX_BLICK_GRAD - 1e-9
                    and ziel.bild_oben > SOLL_OBEN_GRAD + ZU_HOCH_GRAD):
                # Die Nase kann nicht hoeher, und das Gesicht laeuft trotzdem
                # oben raus: so nah, wie er noch sehen kann -- nicht naeher.
                # Mitdrehen darf er weiter.
                vx = 0.0
            if angehalten:
                # Halt heisst STEHEN, nicht nur nicht vorwaerts. Die Nase bleibt
                # auf dem Menschen (geregelt oben), damit er den Daumen sieht.
                vx, wz = 0.0, 0.0
            # Jeder Takt mit Ziel steht im Lauf: WAS der Finder lieferte, wie es nachgefuehrt
            # wurde und was daraus befohlen wird. Ohne diese Zeile war am 17.09.2026 aus 169
            # walk-Befehlen nicht zu sagen, ob ein Mensch bei +60 Grad stand oder ein Phantom.
            zeige(LICHT_ANGEHALTEN if angehalten else LICHT_FOLGT)
            ziel_gemeldet = True
            fehlschlag = _notiere_ziel(spot, ziel, ziel_jetzt=ziel_jetzt, echt=echt, vx=vx, wz=wz,
                                       takt_s=takt_dauer, gesperrt=drehsperre)
            if fehlschlag and not schreibfehler_gemeldet:
                schreibfehler_gemeldet = True
                melde(f"Das Ziel liess sich nicht aufzeichnen: {fehlschlag}")

            schranke = ""
            if vx > 0.0:
                # Schneller als MAX_TEMPO_M_S: erst weiter voraus pruefen; reicht der
                # Platz nicht, das alte Tempo mit den alten Strecken -- erst dann stehen.
                versuche = [vx, MAX_TEMPO_M_S] if vx > MAX_TEMPO_M_S else [vx]
                verworfen = ""              # warum das schnellere Tempo nicht ging
                for versuch in versuche:
                    mehr = vorausschau_m(versuch)
                    if mehr:
                        # Jeden Takt frisch: ein Kopfraum von vor einer Sekunde reicht bei
                        # 1 m/s nicht mehr.
                        with mit.zeit("kopfraum"):
                            kopf = kopfraum_frei(spot, meter=KOPFRAUM_M + mehr)
                    else:
                        if (kopfraum_geprueft is None
                                or jetzt() - kopfraum_geprueft >= kopfraum_takt_s):
                            with mit.zeit("kopfraum"):
                                kopfraum = kopfraum_frei(spot)
                            kopfraum_geprueft = jetzt()
                        kopf = kopfraum
                    with mit.zeit("gitter"):
                        frei = frei_voraus(spot, meter=FREIRAUM_M + mehr)
                    with mit.zeit("zone"):
                        zone = zone_voraus(spot, raum, strecke=ZONE_VORAUS_M + mehr)
                    grund = next((g for darf, g in (frei, kopf, zone) if not darf), "")
                    if not grund:
                        if versuch < vx:
                            schranke = f"langsamer: {verworfen}"
                        vx = versuch
                        letzter_grund = ""
                        break
                    verworfen = grund
                else:
                    vx = 0.0
                    schranke = grund
                    if grund != letzter_grund:
                        melde(f"Stehen geblieben: {grund}.")
                        letzter_grund = grund

            if (vx, wz) == (0.0, 0.0) and not blick_grad:
                if faehrt:
                    with mit.zeit("stop"):
                        spot.stop()
                    faehrt = False
            else:
                # Mit Neigung auch bei Tempo null: das haelt die Nase oben.
                with mit.zeit("walk"):
                    spot.walk(vx=vx, vy=0.0, wz=wz, stop=False, nick_grad=nick)
                faehrt = True
            mit.befehl(vx, wz, nick if blick_grad else 0.0, schranke=schranke,
                       gesperrt=drehsperre, angehalten=angehalten)
            mit.takt_endet("angehalten" if angehalten else "gesperrt" if drehsperre
                           else "folgt" if echt else "haelt" if nur_drehen else "nachlauf")
            aufnahme_melden()
            schlaf(_rest(takt_s, takt_beginn, jetzt))
    finally:
        try:
            # ZUERST anhalten, DANN das Licht: bis zum 22.09.2026 stand `licht.aus()`
            # davor, und bei einem langsamen AV-Dienst fuhr Spot mit dem letzten Befehl
            # weiter, bis dessen Endzeit ablief -- 3.0 s zu spaet gemessen (p08).
            # `fahren.fahre` macht es seit jeher so herum.
            spot.stop()
        finally:
            if licht:
                try:
                    licht.aus()           # wartet hoechstens kurz auf den Boten
                except Exception:
                    pass                  # die LEDs erloeschen ohnehin mit der Frist
        if licht:
            licht_melden()                # ein Fehler aus dem letzten Takt kommt auch noch an
        stapel.close()
        if aufnahme:
            # NACH dem Anhalten: das Warten auf die Platte darf keinen Fahrbefehl verlaengern.
            bericht = aufnahme.schliessen()
            aufnahme_melden()
            lauf = Path(bericht["ordner"]).parent
            melde(f"Folge-Aufnahme: {bericht['takte']} Takte, {bericht['sichten']} Bilder in "
                  f"{bericht['ordner']}. Das Video dazu: "
                  f'python -m spotlab.workshop.folgenfilm "{lauf}"')
        melde("Folgen beendet.")


def _aufnahme_fuer(spot, aufnahme, lauf_dir):
    """Die `Folgeaufnahme` für diesen Lauf — oder None. Wirft, wenn True keine Ablage findet.

    Abgelegt wird im Lauf-Verzeichnis (`lauf_dir`, sonst das des Schreibers),
    gestempelt mit der Laufzeit des Schreibers: `t` hat dann dieselbe Basis wie
    `ereignisse.jsonl`, und das Video findet zu jedem Ereignis sein Bild.
    """
    if not aufnahme:
        return None
    if aufnahme is not True:
        return aufnahme
    recorder = getattr(spot, "recorder", None)
    ablage = lauf_dir if lauf_dir is not None else getattr(recorder, "dir", None)
    if ablage is None:
        raise ValueError("folge(aufnahme=True) braucht `lauf_dir` oder einen Lauf mit Aufzeichnung "
                         "— sonst gibt es keinen Ort für die Aufnahme.")
    uhr = getattr(recorder, "zeitmarke", None)
    return folgeaufnahme.Folgeaufnahme(ablage, uhr=uhr if callable(uhr) else None)


def _stille(je_gesehen, seit_s):
    """Was Spot sagt, während er wartet — und der Unterschied ist die Sache selbst.

    Am 16.09.2026 stand er 28 Sekunden lang, weil `personen_finder()` auf diesem
    Roboter nie etwas liefert. „Ziel verloren" wäre dabei eine falsche Auskunft
    gewesen: verloren hat er nichts, er hatte nie eines. Genau diese beiden Fälle
    verlangen verschiedene Schritte — einmal näher herangehen, einmal den Finder
    wechseln.
    """
    if je_gesehen:
        return f"Ziel verloren, seit {seit_s:.0f} s — Spot wartet."
    return f"Noch kein Ziel nach {seit_s:.0f} s — Spot wartet."


def _notiere_stille(spot, seit_s, je_gesehen, befund=""):
    """Die Stille in die Aufzeichnung — EINE Zeile statt 135 gleicher Abfragen.

    Am 16.09.2026 liess sich nur deshalb klären, was los war, weil
    `ereignisse.jsonl` 135 erfolglose `world_objects` enthielt — die musste man
    erst zählen.

    Gibt den FEHLERTEXT zurück, wenn das Schreiben scheitert, statt ihn zu
    verschlucken. Genau das war hier schon einmal falsch: die Art `kein_ziel`
    fehlte in der Erlaubnisliste (`record/events.py`), `event()` warf, ein
    `except Exception: pass` schluckte es — und in keinem einzigen Lauf stand
    eine Zeile, während die Tests grün blieben, weil ihre Attrappe jede Art
    annahm. Anhalten darf ein Schreiber den Roboter trotzdem nie: ohne Eintrag
    fährt man weiter, ohne Regler nicht. Also melden statt werfen, und der
    Aufrufer sagt es einmal.
    """
    recorder = getattr(spot, "recorder", None)
    if recorder is None:
        return ""
    try:
        recorder.event("kein_ziel", seit_s=round(float(seit_s), 1),
                       je_gesehen=bool(je_gesehen), befund=str(befund))
    except Exception as fehler:
        return f"{type(fehler).__name__}: {fehler}"
    return ""


def _geste_wirkt(geste, angehalten):
    """(angehalten danach, Meldung) -- ein Zeichen nimmt oder gibt nur, was das Folgen tut.

    Ein Zeichen, das nichts aendert, wird trotzdem gesagt: wer die Hand hebt,
    will wissen, ob Spot sie gesehen hat.
    """
    from spotlab.backends.real.gesten import HALT, WEITER

    if geste == HALT:
        if angehalten:
            return True, "Offene Hand gesehen — Spot steht schon."
        return True, "Geste: offene Hand — Halt. Spot steht, bis er einen Daumen hoch sieht."
    if geste == WEITER:
        if angehalten:
            return False, "Geste: Daumen hoch — Spot geht weiter."
        return False, "Daumen hoch gesehen — Spot war nicht angehalten."
    return angehalten, f"Unbekannte Geste „{geste}“ — nichts geändert."


def _notiere_ziel(spot, ziel, ziel_jetzt=None, echt=True, vx=0.0, wz=0.0, takt_s=None,
                  gesperrt=False):
    """Je Takt mit Ziel eine Zeile `ziel`; `ziel=None` heisst einmal „weg". Fehlertext statt werfen."""
    recorder = getattr(spot, "recorder", None)
    if recorder is None:
        return ""
    try:
        if ziel is None:
            recorder.event("ziel", finder=None, weg=True)
        else:
            jetzt_ = ziel_jetzt if ziel_jetzt is not None else ziel
            recorder.event(
                "ziel", finder=str(ziel.name), peilung=round(float(ziel.bearing), 1),
                peilung_jetzt=round(float(jetzt_.bearing), 1),
                abstand=round(float(ziel.distance), 2),
                bild_oben=None if ziel.bild_oben is None else round(float(ziel.bild_oben), 1),
                echt=bool(echt), vx=round(float(vx), 3), wz_grad=round(math.degrees(float(wz)), 1),
                takt_s=None if takt_s is None else round(float(takt_s), 3), gesperrt=bool(gesperrt),
            )
    except Exception as fehler:
        return f"{type(fehler).__name__}: {fehler}"
    return ""


def _notiere_geste(spot, geste, angehalten):
    """Das Zeichen in die Aufzeichnung -- Fehlertext zurueck statt werfen, wie `_notiere_stille`."""
    recorder = getattr(spot, "recorder", None)
    if recorder is None:
        return ""
    try:
        recorder.event("geste", geste=str(geste), angehalten=bool(angehalten))
    except Exception as fehler:
        return f"{type(fehler).__name__}: {fehler}"
    return ""


def _neigung_nach(neigung, bild_oben, soll=SOLL_OBEN_GRAD, totband=TOTBAND_GRAD,
                  schritt=NICK_SCHRITT_GRAD, unten=NICK_MIN_GRAD, oben=MAX_BLICK_GRAD):
    """Die Neigung des naechsten Takts aus der Oberkante des Kastens — rein rechenbar.

    Liegt die Oberkante ueber dem Soll, hebt sich die Nase, sonst senkt sie sich —
    hoechstens `schritt` je Takt (zwei Regelkreise, Drehen und Nicken, sollen
    nicht gegeneinander schwingen), und innerhalb des Totbands gar nicht.
    """
    fehler = float(bild_oben) - soll
    if abs(fehler) < totband:
        return neigung
    aenderung = max(-schritt, min(schritt, fehler))
    return max(unten, min(oben, neigung + aenderung))


def _rest(takt_s, takt_beginn, jetzt):
    """Was vom Takt noch übrig ist — null, wenn die Arbeit länger war als der Takt.

    Gemessen am 16.09.2026: ein Gesichts-Takt kostet Bildabrufe ~100 ms, YuNet
    85 ms, Gegenprobe 107 ms, RPCs 50–150 ms — und dann schlief die Schleife
    UNBEDINGT noch 200 ms obendrauf. Beim Tag (0.05 s Arbeit) ist der Schlaf das
    Taktmass, und das bleibt er; beim Gesicht war er reine Blindzeit.
    """
    return max(0.0, float(takt_s) - (jetzt() - takt_beginn))


def _sicher(finder, spot):
    """Ein Finder, der wirft, darf den Lauf nicht beenden — er findet dann nichts."""
    try:
        return finder(spot)
    except Exception:
        return None
