"""spotlab — den Spot programmieren, ohne vorher SDK-Betriebsmechanik zu lernen."""

import contextlib
import os
import sys
from pathlib import Path

__version__ = "0.2.0b6"

ENV_BACKEND = "SPOTLAB_BACKEND"

# Obergrenze, nicht Vorgabe. Gesetzt von allem, was ohne Aufsicht startet —
# heute vom MCP-Server, wenn ein Agent ein Skript startet.
ENV_NUR_TROCKEN = "SPOTLAB_NUR_TROCKEN"
# Raum und Startpose des Uebungsraums. Die GUI reicht damit durch, was auf
# dem BILDSCHIRM steht, statt sich auf die Konfiguration zu verlassen: die
# bekam den Raum erst beim Klick in die Zeichnung, und wer nur startete, fuhr
# in gar keinem Raum -- Start (0, 0), quer durch die Waende. Und ein Laptop
# ohne eingerichteten Spot hat ueberhaupt keine Konfiguration.
ENV_RAUM = "SPOTLAB_RAUM"
ENV_RAUM_START = "SPOTLAB_RAUM_START"
ENV_KARTE = "SPOTLAB_KARTE"          # die Karte fuer den Navigationslauf (Tab „Karten")

# EINMAL beim Import eingefroren, nicht bei jedem Aufruf frisch gelesen.
# `os.environ.pop("SPOTLAB_NUR_TROCKEN")` in Zeile eins eines Skripts hätte die
# Obergrenze sonst aufgehoben — und genau solche Skripte schreibt der Agent,
# für den die Schranke gedacht ist.
NUR_TROCKEN = os.environ.get(ENV_NUR_TROCKEN) == "1"

NUR_TROCKEN_MELDUNG = (
    "Dieser Lauf wurde ohne Roboter gestartet und darf keinen anfordern. "
    "Starte das Programm selbst im Fenster, wenn der Spot fahren soll."
)

# Backends, die gar keinen Roboter erreichen können: kein Netzclient, kein
# Lease, kein Not-Aus-Endpunkt. Nur diese laufen unter `SPOTLAB_NUR_TROCKEN`.
#
# ERLAUBNISLISTE, keine Sperrliste. Ein neues Backend ist gesperrt, bis jemand
# es hier einträgt — und wer es einträgt, hat die Frage beantwortet, ob es den
# Spot bewegen kann. Andersherum wäre jedes künftige Backend versehentlich frei.
OHNE_ROBOTER = ("dryrun", "sim", "mujoco", "physics")


@contextlib.contextmanager
def connect(
    backend=None, runs_dir=None, script=None, take=False, config_path=None,
    nickname=None, raum=None, nur_lesen=False,
):
    """Verbindet, zeichnet auf und baut am Ende garantiert sauber ab.

    Die Motoren gehen dabei NICHT an — `spot.power_on()` ist eine eigene Zeile,
    die jemand geschrieben haben muss.

    `nur_lesen=True` verbindet OHNE Lease und ohne Not-Aus-Endpunkt: fragen,
    während ein Mensch mit dem Tablet fährt. Ein solcher Lauf kann den Roboter
    nicht bewegen — nicht, weil das Programm es unterlässt, sondern weil die
    Fähigkeit fehlt. Das gilt nur am echten Roboter; die Trockenläufe und Sims
    halten ohnehin nie ein Lease, dort ändert die Angabe nichts.
    """
    from spotlab import protokoll
    from spotlab.api.spot import Spot
    from spotlab.config import Limits, load_config
    from spotlab.errors import ConfigMissing, LeaseLost, SpotlabError
    from spotlab.record.run import RunRecorder
    from spotlab.record.sampler import StateSampler

    try:
        cfg = load_config(config_path) if config_path else load_config()
    except ConfigMissing:
        cfg = None

    art = backend or os.environ.get(ENV_BACKEND) or (cfg.default_backend if cfg else "dryrun")

    # Die Schranke steht VOR dem RunRecorder: sonst entstünde ein leeres
    # Lauf-Verzeichnis für einen Lauf, den es nie gab.
    #
    # SPOTLAB_BACKEND allein genügt hier nicht — die Zeile darüber liest
    # `backend or os.environ.get(...)`, ein explizites backend="real" im Skript
    # überschreibt die Variable also. Abgewiesen statt stillschweigend
    # heruntergestuft: ein Skript, das glaubt, es fahre den echten Spot,
    # meldet sonst Unsinn und niemand merkt es.
    # `sim` steht hier neben `dryrun`, weil die Schranke „darf den echten Spot
    # nicht bewegen" heisst — nicht „darf sich nicht bewegen". Beide haben
    # keinen Netzclient und kein Lease; sie können gar keinen Roboter erreichen.
    # Eine ERLAUBNISLISTE, keine Sperrliste: ein künftiges Backend ist gesperrt,
    # bis jemand es hier ausdrücklich einträgt.
    if NUR_TROCKEN and art not in OHNE_ROBOTER:
        raise SpotlabError(NUR_TROCKEN_MELDUNG)

    # Ein unbekannter Name ist ein Fehler, keine Wahl. Bis zum 23.09.2026 fiel
    # jeder Name, der nicht genau stimmte (`"Sim"`, `"mujoko"`, `"trocken"`),
    # in den letzten Zweig unten -- und der verbindet mit dem ECHTEN Spot.
    # Nach der Schranke (die sagt unter SPOTLAB_NUR_TROCKEN das Wichtigere) und
    # VOR dem RunRecorder, aus demselben Grund wie sie.
    _pruefe_backend(art, backend)

    grenzen = cfg.limits if cfg else Limits()
    spitzname = nickname or (cfg.nickname if cfg else "")

    skript = Path(script) if script else _skript_pfad()
    ziel = Path(runs_dir) if runs_dir else _runs_verzeichnis(skript)
    recorder = RunRecorder(ziel, skript, backend=art, nickname=spitzname)
    # Ab hier landen Diagnosezeilen neben der Aufzeichnung. Ohne Ziel schreibt
    # protokoll.notiere() nichts — ein Import von spotlab legt keine Datei an.
    protokoll.setze_ziel(recorder.dir)

    # EIN Fang fuer jeden Aufbau, nicht einer je Backend: bis zum 23.09.2026
    # hatten nur Physik und Roboter einen. Ein Tippfehler im Raumnamen, ein
    # fehlendes spotsim oder Strg-C beim Laden der Puppe liessen den Lauf fuer
    # immer auf „läuft“ stehen -- ohne Grund, und die GUI hielt ihn fuer lebend.
    try:
        roher_roboter, unten = _baue_backend(
            art, recorder, cfg, grenzen, raum=raum, take=take, nur_lesen=nur_lesen,
        )
    except BaseException as fehler:
        _aufbau_gescheitert(recorder, fehler)
        raise

    # Abtaster vor dem Spot: die Fassade braucht ihn, um im Messfenster die Rate
    # zu heben.
    abtaster = StateSampler(unten, recorder)
    spot = Spot(
        unten,
        recorder=recorder,
        limits=grenzen,
        robot=roher_roboter,
        workspace=(cfg.workspace if cfg else None),
        active_map=(cfg.active_map if cfg else None),
        sampler=abtaster,
    )
    abtaster.start()

    ergebnis, fehlertext = "ok", None
    try:
        yield spot
    except KeyboardInterrupt:
        if abtaster.stopp_ausgeloest:
            ergebnis, fehlertext = "abgebrochen", "Vom Benutzer gestoppt (Stopp-Knopf)"
            _stopp_ohne_traceback(skript)
        else:
            ergebnis, fehlertext = "abgebrochen", "Vom Benutzer abgebrochen (Ctrl-C)"
        raise
    except LeaseLost as fehler:
        ergebnis, fehlertext = "lease_verloren", str(fehler)
        raise
    except SpotlabError as fehler:
        ergebnis, fehlertext = "fehler", str(fehler)
        raise
    except SystemExit as fehler:
        # `sys.exit(0)` (und `sys.exit()`) ist ein ordentliches Ende, das ein
        # Programm selbst gewählt hat -- etwa „Akku unter 95 %, heute nur
        # stehen". Bis zum 23.09.2026 stand so ein Lauf als Fehler da.
        if fehler.code not in (0, None):
            ergebnis, fehlertext = "fehler", f"Programm beendet mit sys.exit({fehler.code!r})"
        raise
    except BaseException as fehler:
        ergebnis, fehlertext = "fehler", f"{type(fehler).__name__}: {fehler}"
        raise
    finally:
        # Verschachtelt, nicht hintereinander: `abtaster.stop()` stand hier
        # ungeschützt VOR `spot.close()`. Wirft es — oder unterbricht Strg-C es
        # genau dort —, baute die Sitzung nie ab: Motoren an, Lease gehalten,
        # Not-Aus-Endpunkt registriert, und der Lauf blieb in lauf.json auf
        # „läuft" stehen. Der Abtaster ist der unwichtigste der drei Schritte
        # und stand am gefährlichsten Platz.
        # Zuerst die Markierung: ab hier schweigt der Abtaster, und ohne sie
        # gälte der Lauf für den NOT-AUS-Knopf schon als tot, obwohl der Spot
        # noch unter Strom steht.
        recorder.abbau_beginnt()
        try:
            abtaster.stop()
        finally:
            try:
                spot.close()
            finally:
                # Vor `finish()`: der Bericht gehört in dasselbe `lauf.json`,
                # und `finish()` schreibt es zum letzten Mal.
                #
                # Eigener try-Block, weil er im Abbaupfad steht: eine kaputte
                # Kennlinie darf einen Lauf nicht offen lassen. Lieber ein
                # Lauf ohne Bericht als einer, der für immer auf „läuft" steht.
                try:
                    if hasattr(unten, "bericht"):
                        recorder.set_robot_info(sim=unten.bericht())
                except Exception as fehler:
                    protokoll.notiere("Sim-Bericht nicht geschrieben", fehler)
                recorder.finish(ergebnis, fehlertext)
                protokoll.setze_ziel(None)


def _baue_backend(art, recorder, cfg, grenzen, raum=None, take=False, nur_lesen=False):
    """(roher Roboter oder None, Backend) -- und das `verbunden`-Ereignis.

    Wirft, wenn der Aufbau scheitert; den Lauf beendet dann `connect()`.
    """
    from spotlab.errors import ConfigMissing

    if art == "dryrun":
        from spotlab.backends.dryrun import DryRunBackend

        unten = DryRunBackend(recorder)
        recorder.event("verbunden", backend="dryrun")
        return None, unten

    if art in ("sim", "mujoco", "physics"):
        # `mujoco` ist der 2D-Sim mit einem 3D-Koerper (backends/mujoco.py):
        # dieselben Kommandos, dieselbe Gangkennlinie, dieselbe Antwort — dazu
        # Kameras, Tiefengitter und Kollision an der Mesh-Geometrie. Er braucht
        # das Extra `spotlab[sim]` und `spotsim` aus matura-spot; fehlt eines,
        # sagt der Fehler, was zu tun ist.
        from spotlab.backends.sim import SimBackend
        from spotlab.config import startpose_aus
        from spotlab.welt.raum import raum_laden

        # Reihenfolge: Argument vor Umgebung vor Konfiguration. Ein Skript, das
        # seinen Raum nennt, soll nicht davon abhaengen, was zuletzt in der GUI
        # stand; die GUI wiederum soll nicht davon abhaengen, was zuletzt in der
        # Konfiguration gelandet ist.
        name = raum or os.environ.get(ENV_RAUM) or (cfg.raum if cfg else "")
        gewaehlt = (raum_laden(name, workspace=cfg.workspace if cfg else None)
                    if name else None)
        roher_start = os.environ.get(ENV_RAUM_START) or (cfg.raum_start if cfg else "")
        start = startpose_aus(roher_start)
        if gewaehlt is not None and start is None:
            start = gewaehlt.start

        if art == "physics":
            from spotlab.backends.physics import PhysicsBackend

            unten = PhysicsBackend(recorder=recorder, raum=gewaehlt, start=start,
                                   ansicht_ziel=recorder.dir / "ansicht.jpg")
        elif art == "mujoco":
            from spotlab.backends.mujoco import MujocoBackend

            unten = MujocoBackend(
                recorder, raum=gewaehlt, start=start, treppen=grenzen.treppen,
                ansicht_ziel=recorder.dir / "ansicht.jpg",
            )
        else:
            unten = SimBackend(recorder, raum=gewaehlt, start=start, treppen=grenzen.treppen)
        # Der Hinweis gehört in die Aufzeichnung, nicht nur in den Docstring:
        # wer den Lauf später ansieht, muss sehen, dass hier nichts erprobt ist.
        # Dasselbe fuer den Treppengang: die Puppe spielt auf Stufen den ebenen
        # Gang, und der Lauf sagt es (Stufe 13, Wahl C des Autors).
        zusatz = {"treppengang": unten.treppengang()} if unten.treppengang() else {}
        recorder.event(
            "verbunden", backend=art, raum=name or None,
            hinweis=unten.hinweis_zur_gueltigkeit(), **zusatz,
        )
        return None, unten

    # Nur noch "real": jeder andere Name ist in `_pruefe_backend` abgewiesen,
    # bevor es einen RunRecorder gab.
    from spotlab.backends.real import RealSpot

    if cfg is None:
        raise ConfigMissing("Keine Konfiguration. Einrichten mit `spotlab login`.")
    # Zwei Einstiege, nicht ein Argument im selben Aufbau: der Lease-Erwerb
    # steht in `connect`, und wer nur liest, kommt gar nicht erst daran vorbei
    # (backends/real/session.py).
    unten = (
        RealSpot.nur_lesen(cfg, recorder=recorder) if nur_lesen
        else RealSpot.connect(cfg, recorder=recorder, take=take)
    )
    return unten.robot, unten


def _aufbau_gescheitert(recorder, fehler):
    """Ein Lauf, dessen Backend nie zustande kam: Grund in `lauf.json`, Protokollziel weg.

    Derselbe Text wie im Lauf selbst: eine SpotlabError sagt schon alles, bei
    allem anderen gehört der Klassenname dazu. Wirft nie über den Fehler hinweg,
    den der Aufrufer gleich weiterreicht -- der ist die Nachricht.
    """
    from spotlab import protokoll
    from spotlab.errors import SpotlabError

    if isinstance(fehler, KeyboardInterrupt):
        ergebnis, text = "abgebrochen", "Beim Verbinden abgebrochen (Ctrl-C)"
    elif isinstance(fehler, SpotlabError):
        ergebnis, text = "fehler", str(fehler)
    else:
        ergebnis, text = "fehler", f"{type(fehler).__name__}: {fehler}"
    try:
        recorder.finish(ergebnis, text)
    except Exception as folgefehler:
        protokoll.notiere("Lauf nach gescheitertem Aufbau nicht abgeschlossen", folgefehler)
    finally:
        protokoll.setze_ziel(None)


def _pruefe_backend(art, argument):
    """Wirft SpotlabError, wenn `art` kein Backend ist -- mit den gültigen Namen.

    Eine ERLAUBNISLISTE (`config.BACKENDS`), kein Raten: `"Sim"` ist nicht
    `"sim"`. Wer den Namen stillschweigend korrigierte, müsste auch
    entscheiden, was `"rael"` heissen soll.
    """
    from spotlab.config import BACKENDS
    from spotlab.errors import SpotlabError

    if art in BACKENDS:
        return
    if argument:
        quelle = f"connect(backend={art!r})"
    elif os.environ.get(ENV_BACKEND):
        quelle = f"{ENV_BACKEND}={art!r}"
    else:
        quelle = f"default_backend={art!r}"
    raise SpotlabError(
        f"{quelle}: ein Backend {art!r} gibt es nicht. Gültig sind „dryrun“, „sim“, "
        "„mujoco“, „physics“ und „real“ -- genau so, kleingeschrieben."
    )


def _stopp_ohne_traceback(skript):
    """Der Stopp-Knopf ist kein Fehler: eine Zeile statt eines Tracebacks.

    Playtest 04.10.2026: nach „Stopp" stand im Editor ein langer Traceback bis
    `KeyboardInterrupt`, im Übungsfenster unten nur „KeyboardInterrupt" -- beides
    sieht aus wie ein Absturz. Die Zeile nennt dafür, wo das Programm stand.

    Der Abbruch selbst bleibt unverändert: Python merkt sich den unbehandelten
    KeyboardInterrupt VOR dem Hook und endet weiter als Strg-C (0xC000013A),
    woran die GUI erkennt, dass kein Fehler zu melden ist.
    """
    import traceback

    vorher = sys.excepthook
    eigene = os.path.normcase(str(skript)) if skript else None

    def haken(art, wert, spur):
        if not issubclass(art, KeyboardInterrupt):
            return vorher(art, wert, spur)
        zeile = None
        for rahmen, nummer in traceback.walk_tb(spur):
            if eigene and os.path.normcase(rahmen.f_code.co_filename) == eigene:
                zeile = nummer
        if zeile is not None:
            text = f"■ Vom Benutzer gestoppt (in {skript.name}, Zeile {zeile})."
        else:
            text = "■ Vom Benutzer gestoppt."
        try:
            print(text, file=sys.stderr, flush=True)
        except Exception:
            # Ein Terminal ohne UTF-8 (Start aus VS Code, Stopp aus der GUI):
            # dann lieber der alte Traceback als gar nichts.
            vorher(art, wert, spur)

    sys.excepthook = haken


def _skript_pfad():
    haupt = sys.argv[0] if sys.argv else ""
    pfad = Path(haupt).resolve() if haupt else None
    return pfad if pfad and pfad.suffix == ".py" and pfad.exists() else None


def _runs_verzeichnis(skript):
    wurzel = skript.parent if skript else Path.cwd()
    return wurzel / "runs"
